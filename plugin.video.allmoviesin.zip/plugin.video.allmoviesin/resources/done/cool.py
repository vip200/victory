# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header,get_vidcloud
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[1]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    progress=' Cloud '
    response,ck = cloudflare_request('http://coolseries.site/video/search.php?keywords=%s&video-id='%(clean_name(original_title,1).replace(' ','+')+'+s%se%s'%(season_n,episode_n)))

  
    regex='<div class="pm-video-thumb">(.+?)<span class="overlay"></span>'
    m=re.compile(regex,re.DOTALL).findall(response)
 
    for items in m:
        if stop_all==1:
            break
        progress=' Items '
        regex='<a href="(.+?)" title="Watch (.+?)">'
        m2=re.compile(regex).findall(items)

     
        if (clean_name(original_title,1)+' S%sE%s'%(season_n,episode_n)).lower() in m2[0][1].lower():
            x=requests.get(m2[0][0],headers=ck[1],cookies=ck[0]).content
            
            regex=' <div class="on-episode-loading">.+?<a href="(.+?)"'
            m3=re.compile(regex,re.DOTALL).findall(x)
           
           

            ck2=ck[1]
            ck2['Referer']=m2[0][0]
            response = requests.get(m3[0], headers=ck2, cookies=ck[0]).content
            regex='IFRAME  src="(.+?)"'
            m4=re.compile(regex).findall(response)
            for initems in m4:
                res=''
                if stop_all==1:
                    break
                progress=' initems '
                if 'keeload.com' in initems:
                    ck2=ck[1]
                    ck2['Referer']=m3[0]
                    y=requests.get(initems,headers=ck2,cookies=ck[0]).content
                    regex='sources.+?\[(.+?)\]'
                    match=re.compile(regex,re.DOTALL).findall(y)
                    if len(match)>0:
                        try:
                            j_m=json.loads('['+match[0]+']')
                            
                            for it_lk in j_m:
                                res=it_lk['label']
                                lk=it_lk['file']
                                res=res.replace('HD','720')
                                all_links.append((original_title,lk,'Direct',res))
                                global_var=all_links
                        except:
                            continue
                    else:
                        regex='<IFRAME SRC="(.+?)"'
                        m4=re.compile(regex).findall(y)
                       
                        name1,match_s,res2,check=server_data(m4[0],original_title)
                        
                        if check:
                          
                            all_links.append((name1,m4[0],match_s,res))
                            global_var=all_links
                else:
                    initems=initems.replace('opendl.co','openload.co')
                    name1,match_s,res2,check=server_data(initems,original_title)
                    res=res.replace('HD','720')
                    if res=='':
                        res=res2
                    
                    if check:
                      
                        all_links.append((name1,initems,match_s,res))
                        global_var=all_links
            break

    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links

    
