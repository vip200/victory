# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,cloudflare_request,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[31]


def resolve_flix(link,action,season,episode,original_title):
  
        global global_var,stop_all
        all_links=[]
        
        x=requests.get(link).content
        
        if action=='getEpisodeEmb':
          regex='<a href="(.+?)" class="season.+?>%s</'%season
          match=re.compile(regex).findall(x)
        
          
          x=requests.get(match[0]).content
          
          regex='<h5 class="episode-title"><a href="(.+?)episode/%s"'%episode
          match=re.compile(regex).findall(x)
          
          link=match[0]+'episode/'+episode
          x=requests.get(match[0]+'episode/'+episode).content
        token=re.findall("var tok    = '(.+?)'",x)[0]
        lid=re.findall('elid = "(.+?)"',x)[0]


        import base64
        elid = urllib.quote(base64.encodestring(str(int(time.time()))).strip())

        headers = {
            #'Host': 'flixanity.mobi',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': link,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Authorization': 'Bearer false',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = [
          ('action', action),
          ('idEl', lid),
          ('token', token),
          ('nopop', ''),
          ('elid',elid),
        ]
        
        try:
            response2 = requests.post('https://www.flixanity.site/ajax/gonlflhyad.php', headers=headers, data=data).json()
        except:
                return []
     

        all_links=[]

        for links in response2:
     
          if stop_all==1:
            break
          server=response2[links]['type']

          regex='SRC="(.+?)"'
          match=re.compile(regex,re.IGNORECASE).findall(response2[links]['embed'])
          
          src=match[0]
        
          if 'openload.co' in server or 'streamango' in server:
              
              
              nam1,srv,res,check=server_data(src,original_title)
              
              if check:
                all_links.append((nam1.replace("%20"," "),src,srv,res))
          else:
            if '1080' in server:
              res='1080'
            elif '720' in server:
              res='720'
            elif '480' in server:
              res='480'
            elif '360' in server:
              res='360'
            else:
              res='720'
            nam1=original_title.replace('%20',' ')
            srv=server
            if 'loadvid.online'  in src:
                 ids2=src.split('/')
                 id2=ids2[len(ids2)-1]
                
                 y=requests.get(domain_s+'loadvid.online/player?fid=%s&page=embed'%id2).json()
                 regex='player.updateSrc\((.+?)\)'
                 match3=re.compile(regex).findall(y['html'])
                 data=json.loads(match3[0])
                 for items in data:
                   all_links.append((items['name'],items['src'],'Direct',items['label'].replace('HD','720')))
                   global_var=all_links
            else:
              all_links.append((nam1,src,srv,res))
              global_var=all_links
        return all_links
def resolve_hdo(url,action,season,episode,original_title):
    global global_var,stop_all
    ids=url.split('-')
    id=ids[len(ids)-1]
    all_links=[]
    url='http://hdo.to/ajax/movie/episodes/'+id
    x,cook=cloudflare_request(url,headers=base_header)

    #x=requests.get(url).content
   
    x=x.replace("\\","")
    if action=='getEpisodeEmb':
      regex_pre='<li class="ep-item"(.+?)</li'
      match=re.compile(regex_pre).findall(x)
      x=''
      for ep in match:
        if 'Episode '+episode in ep:
          x=x+' '+ep
          
      regex='data-server=".+?" data-id="(.+?)"'
    else:
      regex='data-server=".+?" data-id="(.+?)"'
    
    match=re.compile(regex).findall(x)
    
    for eid in match:
      if stop_all==1:
            break
      url=domain_s+'hdo.to/ajax/movie/get_embed/'+eid
      x=requests.get(url,headers=cook[1],cookies=cook[0]).json()
  
        
      if x['status']==True:
        if 'loadvid.online'  in x['src']:
             ids2=x['src'].split('/')
             id2=ids2[len(ids2)-1]
            
             y=requests.get('https://loadvid.online/player?fid=%s&page=embed'%id2,headers=cook[1],cookies=cook[0]).json()
             regex='player.updateSrc\((.+?)\)'
             match3=re.compile(regex).findall(y['html'])
             data=json.loads(match3[0])
             for items in data:
               all_links.append((items['name'],items['src'],'Direct',items['label'].replace('HD','720')))
               global_var=all_links
        else:
            name1,match_s,res,check=server_data(x['src'],original_title)
            
            if check:
              all_links.append((name1.replace("%20"," "),x['src'],match_s,res))
      
      url=domain_s+'hdo.to/ajax/movie/token?eid=%s&mid=%s'%(eid,id)
      
      x=requests.get(url,headers=cook[1],cookies=cook[0]).content
      regex="_x='(.+?)', _y='(.+?)'"
      
      match=re.compile(regex).findall(x)
      for x,y in match:
        if stop_all==1:
            break
        url=domain_s+'hdo.to/ajax/movie/get_sources/%s?x=%s&y=%s'%(eid,x,y)
        
        x=requests.get(url,headers=cook[1],cookies=cook[0]).content
        if len(x)>5:
         x=json.loads(x)
         if 'playlist' in x:
             for item in  x['playlist'][0]['sources']:
                   if stop_all==1:
                    break
                
                   if 'tracks' in x['playlist'][0]:
                     if len(x['playlist'][0]['tracks'])>0:
                      if 'file' in x['playlist'][0]['tracks'][0]:
                        nam1_a=x['playlist'][0]['tracks'][0]['file'].split('/')
                     elif 'file' in item:
                      nam1_a=item['file'].split('/')
                   elif 'file' in item:
                      nam1_a=item['file'].split('/')
                   
                      
                      nam1=nam1_a[len(nam1_a)-1].replace('.srt','')
                      if '1080' in nam1:
                          res='1080'
                      elif '720' in nam1:
                          res='720'
                      elif '480' in nam1:
                          res='480'
                      elif '360' in nam1:
                          res='360'
                      else:
                          res='720'
                    
                      if 'loadvid.online'  in item['file']:
                         ids2=item['file'].split('/')
                         id2=ids2[len(ids2)-1]
                        
                         y=requests.get('https://loadvid.online/player?fid=%s&page=embed'%id2,headers=cook[1],cookies=cook[0]).json()
                         regex='player.updateSrc\((.+?)\)'
                         match3=re.compile(regex).findall(y['html'])
                         data=json.loads(match3[0])
                         for items in data:
                           all_links.append((items['name'],items['src'],'Direct',items['label'].replace('HD','720')))
                           global_var=all_links
                      else:
                          all_links.append((nam1.replace("%20"," "),item['file'],'VIP',res))
         else:
           
           if 'loadvid.online' not in x['src']:
            name1,match_s,res,check=server_data(x['src'],original_title)
            
            if check:
              all_links.append((name1.replace("%20"," "),x['src'],match_s,res))
              global_var=all_links
           else:
           
           
             ids2=x['src'].split('/')
             id2=ids2[len(ids2)-1]
            
             y=requests.get('https://loadvid.online/player?fid=%s&page=embed'%id2,headers=cook[1],cookies=cook[0]).json()
             regex='player.updateSrc\((.+?)\)'
             match3=re.compile(regex).findall(y['html'])
             data=json.loads(match3[0])
             for items in data:
               all_links.append((items['name'],items['src'],'Direct',items['label']))
               global_var=all_links
    return all_links


def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
       
        title=original_title

        if tv_movie=='movie':
           
         
          
       
          action='getMovieEmb'
          url='http://212.227.203.133/api_v2/code/main/movie_search_all_servers_v2.php?server=hdo_movies&q=%s&year=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'),show_original_year)
        else:
          action='getEpisodeEmb'
          url='http://212.227.203.133/api_v2/code/main/movie_search_all_servers_series_v2.php?server=is_series&q=%s&season=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'),season)
        
        headers={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.0; S16 Build/NRD90M)',
                'Host': '212.227.203.133',
                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'utf8'}
        progress='requests'
        x=requests.get(url,headers=headers).json()
       
        links=[]
        links2=[]
        count=0
        for item in x:
          
          progress='Links-'+str(count)
          count+=1
          if stop_all==1:
            break
          if action=='getEpisodeEmb' and 'flixanity' not in item['url']:
            show_original_year=item['title_with_year']
      
          if  clean_name(original_title,1).lower() in item['title_with_year'].lower() and show_original_year in item['title_with_year']:
             
             if 'flixanity' in item['url']:
               links=resolve_flix(item['url'].replace('mobi','io'),action,season,episode,original_title)
               try:
                links=resolve_flix(item['url'].replace('mobi','io'),action,season,episode,original_title)
               except:
                pass
               
             if 'hdo.' in item['url']:
               try:
                links2=resolve_hdo(item['url'],action,season,episode_n,original_title)
               except:
                 pass
               
        mergedlist = []
        mergedlist.extend(links)
        mergedlist.extend(links2)
        global_var=mergedlist
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var
        