# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv','rd']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[88]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    rd_domains=requests.get('https://api.real-debrid.com/rest/1.0/hosts/domains').json()
    import cfscrape
    all_links=[]
    base_link = 'http://invictus.ws/'
    User_Agent='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0'
    start_url = "%s/?s=%s" % (base_link, clean_name(original_title,1).replace(' ','+').lower())
    if tv_movie=='tv':
        season_url = "0%s"%season if len(season)<2 else season
        episode_url = "0%s"%episode if len(episode)<2 else episode
        sea_epi ='s%se%s'%(season_url,episode_url)
        
        start_url = "%s/?s=%s+%s" % (base_link, clean_name(original_title,1).replace(' ','+').lower(),sea_epi)
            
    search_id = (clean_name(original_title,1).lower()) 
    headers = {'User_Agent':User_Agent}
    scraper = cfscrape.create_scraper()
    OPEN = scraper.get(start_url,headers=headers).content
    
    content = re.compile('<h2><a href="(.+?)"',re.DOTALL).findall(OPEN)
    print start_url
    for url in content:
                       
        headers = {'User_Agent':User_Agent}
        
        links = scraper.get(url,headers=headers).content   
        LINK = re.compile('href="([^"]+)" rel="nofollow"',re.DOTALL).findall(links)
        count = 0             
        for url in LINK:
            if '.rar' not in url:
                if '.srt' not in url:
                    if '1080' in url:
                        res = '1080p'
                    elif '720' in url:
                        res = '720p'
                    elif 'HDTV' in url:
                        res = 'HD'
                    else:
                        res = "SD"

                    host = url.split('//')[1].replace('www.','')
                    host = host.split('/')[0].lower()

                    
                    
                    if host in rd_domains:
                        name1,match_s,res,check=server_data(url,original_title)
                        
                          
                        if check :
                            if '.rar' not in name1:
                                all_links.append((name1,url,match_s,res))
                                global_var=all_links
    return global_var