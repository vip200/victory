import requests,re,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0


from vidtodo import VidToDoResolver

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[68]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
   
    all_links=[]
    if tv_movie=='movie':
      headers = {
        #'Host': 'watchfilms.me',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
      }   
      html=requests.get(domain_s+"watchfilms.me/all",headers=headers,verify=False).content
      regex='<a href="(.+?)" title="(.+?)"'
      match=re.compile(regex).findall(html)

      for link,name in match:
       
        if stop_all==1:
          break
        if name.lower().strip()==original_title.lower().replace('%20',' ').replace('3a',':').strip():
       
         yy=requests.get(domain_s+"watchfilms.me"+link,headers=headers).content
         regex='<li class="playlist_entr.+?" id="(.+?)"'
         match2=re.compile(regex).findall(yy)
         for id in match2:
            if stop_all==1:
               break
            data={'d':"embed",'id':id}

            response = requests.post(domain_s+'watchfilms.me/api', data=data).content
            regex='<a href="(.+?)"'
            match_l=re.compile(regex).findall(response)
            match_l[0]=match_l[0]#.replace("vidtodo.com","vidtudu.com")
            
           
            
            if 1:
                
                headers={#'Host': 'vidtudu.com',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Accept-Encoding': 'utf8',
                        'Referer': domain_s+"watchfilms.me"+link,

                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1'}
            
                f_link=match_l[0]
                name1,match_s,res,check=server_data(f_link,original_title,direct='yes',c_head=headers)
             

                
                if check:
                 
                  if match_s=='vidtodo.com':
                    f_link=VidToDoResolver(f_link,c_head=headers)[1]
                  if  f_link:
                    
                      all_links.append((name1.replace("%20"," "),f_link,match_s,res))
                    
                      global_var=all_links
    else:
              headers = {
                'Host': 'newepisodes.co',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
              }   
              html=requests.get(domain_s+"newepisodes.co/all",headers=headers).content
              regex='<a href="//newepisodes.co(.+?)">(.+?)<'
              match=re.compile(regex).findall(html)
              
              for link,name in match:
                if stop_all==1:
                    break
                if name.lower().strip()==original_title.lower().replace('%20',' ').replace('3a',':'):
   
                 yy=requests.get(domain_s+"newepisodes.co"+link,headers=headers).content
                 regex_pre='<div data-type="show" class="list-item  season_%s">(.+?)</a>'%season
                 match_pre=re.compile(regex_pre,re.DOTALL).findall(yy)
             
                 for data in match_pre:
                   
                  
                   regex_in='<a href="(.+?)".+?<span class="mini".+?S%sE%s	'%(season,episode)
                   match_in=re.compile(regex_in,re.DOTALL).findall(data)
                   if len(match_in)>0:
                    break
                   
            
                 yy=requests.get("http:"+match_in[0],headers=headers).content
                 
                 regex='<li class="playlist_entr.+?" id="(.+?)"'
                 match2=re.compile(regex).findall(yy)
                 for id in match2:
                    if stop_all==1:
                        break
                    data={'d':"embed",'id':id}

                    response = requests.post(domain_s+'newepisodes.co/api', data=data).content
                    regex='<a href="(.+?)"'
                    match_l=re.compile(regex).findall(response)
                    match_l[0]=match_l[0].replace("vidtodo.com","vidtod.me")
                    
                    
                    
                    if 1:
                   
                        
                        headers={#'Host': 'vidtudu.com',
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Accept-Encoding': 'utf8',
                                'Referer': domain_s+"newepisodes.co"+link,

                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1'}
                    
                        
                        name1,match_s,res,check=server_data(match_l[0],original_title,direct='yes',c_head=headers)

                        f_link=match_l[0]
                        if check:
                          if match_s=='vidtodo.com':
                                f_link=VidToDoResolver(f_link,c_head=headers)[1]
                        
                          if  f_link:    
                              all_links.append((name1.replace("%20"," "),match_l[0],match_s,res))
                           
                              global_var=all_links
    return all_links
