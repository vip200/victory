# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[52]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    
    imdb_id=""
    progress='requests'
    if season!=None and season!="%20":
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    else:
     
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    try:
        imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
    except:
        return 0
  

  
    headers = {
        #'Host': 'putlocker.ninja',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        #'Referer': domain_s+'putlocker.ninja/tv-show/watch-the-flash-2014-season-4-episode-13-online-free.html',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    
    
    if tv_movie=='movie':
        lk=domain_s+'putlocker.ninja/embed/'+imdb_id+'/'
       
    else:
       lk=domain_s+'putlocker.ninja/embed/'+imdb_id+'/'+season+'-'+episode+'/'
       
  
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': lk,
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    }

    params = (
        ('i', imdb_id),
    )
    progress='requests2'
    #response = requests.get('https://putlocker.ninja/fix_mov.php', headers=headers, params=params).content
    response = requests.get(lk, headers=headers).content
   
    regex='<iframe src="(.+?)"'
    progress='Regex'
    match=re.compile(regex).findall(response)
    count=0
    for links in match:
        if stop_all==1:
            break
        progress='Check-'+str(count)
        count+=1
        name1,match_s,res,check=server_data(links,original_title)
                        
        if check:
            all_links.append((name1,links,match_s,res))
            global_var=all_links
        else:
            progress='requests-'+str(count)
            if 'http' not in links:
                links='https:'+links
            yy=requests.get(links).content
            if 1:#try:
                regex='og:title" content="(.+?)"'
                progress='Regex-'+str(count)
                match=re.compile(regex).findall(yy)
                regex_l='//(.+?)/'
                progress='Regex2-'+str(count)
                match_l=re.compile(regex_l).findall(links)
                if len(match)>0:
                    info=(PTN.parse(match[0]))
                    nam=match[0]
                    if 'resolution' in info:
                      res=info['resolution']
                    else:
                      res=' '
                else:
                    nam=original_title
                    res=' '
                all_links.append((nam,links,match_l[0],res))
                global_var=all_links
            #except Exception as e:
            #  print e
            #  pass
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    