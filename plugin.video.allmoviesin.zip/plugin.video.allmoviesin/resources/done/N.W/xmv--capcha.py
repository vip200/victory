# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
rating=['SSS','7M/s']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[79]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all

        all_links=[]
        if tv_movie=='movie':
          url = domain_s+'xmovies8.cool/movies/search?s='+clean_name(original_title,1)+'+'+show_original_year
        else:
          url = domain_s+'xmovies8.cool/movies/search?s=%s+season+%s'%(clean_name(original_title,1),season)

        r ,cook= cloudflare_request(url)
        
        regex='<div class="row">.+?href="(.+?)">.+?title="(.+?)"'
        match=re.compile(regex).findall(r)
        print match
        for link,name_in in match:
          if stop_all==1:
                    break
          check=False
          if tv_movie=='movie':
             if show_original_year in name_in:
               check=True
          else:
             check=True
          if clean_name(original_title,1).lower() in name_in.lower() and check:
            x,cook=cloudflare_request(link+'watching.html')
            if tv_movie=='tv':
               regex_pre='<div class="ep_link full">(.+?)</div>'
               match_pre=re.compile(regex_pre,re.DOTALL).findall(x)
             
               regex='a href="(.+?)" class=.+?red-border">Episode %s<'%episode
               
               match2=re.compile(regex).findall(match_pre[0])
              
               x,cook=cloudflare_request(match2[0]+'watching.html')
               regex='div class="ep_link full"> <a href=.+?>Episode %s<'%episode
               match33=re.compile(regex,re.DOTALL).findall(x)[0]
               id = re.findall(r'>Episode %s<.+?episode_id=(.+?)"'%episode, x)[0]
            else:
               match33=link+'watching.html'
               id = re.findall(r'episode_id=(.+?)"', x)[0]
            
            
           
            regex='<option value=.+?>(.+?)</option>'
            match_s=re.compile(regex).findall(x)
          
            for server in match_s:
            
             
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': match33+'&s='+server.lower(),
                    'Origin': 'https://xmovies8.pl',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }

                params = (
                    ('s', server.lower()),
                    ('id', id),
                )

                r = requests.get('https://xmovies8.pl/ajax/movie/load_player_v4', headers=headers, params=params).content
               
                
               
                
                url = json.loads(r)['value']
                
                

             
                if (url.startswith('//')):
                    url = 'https:' + url

                url = url + '&_=%s' % int(time.time())
                r = requests.get(url, headers=headers).content
           
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
                    'Referer': link+'watching.html',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Origin': domain_s+'xmovies8.cool'
                }
                
                #r ,cook= cloudflare_request(url, headers=headers)
         
                headers = '|' + urllib.urlencode(headers)
           
                source = str(json.loads(r)['playlist'][0]['file']) + headers
             
                
                if 'qlt=1080' in url:
                  res='1080'
                elif 'qlt=720' in url:
                  res='720'
                
                elif 'qlt=480' in url:
                  res='480'
                else:
                  res='HD'
                all_links.append((original_title.replace("%20"," "),source,'Direct',res))
                global_var=all_links
        return all_links
            