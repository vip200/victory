# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
        
    global link_onitube
    all_links=[]
    if tv_movie=='tv':
      search_string=clean_name(original_title,1).replace(' ','+')+'+'+'s'+season_n+'e'+episode_n
    else:
      search_string=clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    url=domain_s+'www.onitube.com/search/videos?search_query='+search_string
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    

    req = urllib2.Request(url, headers=headers)
    filedescriptor = urllib2.urlopen(req)
    html = filedescriptor.read()
    
   
    
    regex='<a href="%swww.onitube.com/video/(.+?)/.+?title="(.+?)".+?"hd-text-icon">(.+?)<'%domain_s
    match=re.compile(regex,re.DOTALL).findall(html)

    for link,name,quality in match:
       ok=0
       if tv_movie=='tv':
        show_original_year=name
        if clean_name(original_title,1).lower() in name.lower() and 's'+season_n+'e'+episode_n in name.lower():
         ok=1
       else:
         if clean_name(original_title,1).lower() in name.lower() and show_original_year in name:
           ok=1
       if ok==1:
       
            if "1080" in quality:
              res="1080"
            elif "720" in quality:
              res="720"
            elif "480" in quality:
              res="480"
            elif "hd" in quality.lower():
              res="HD"
            else:
             res=' '
             
            
            match_s='Direct'
            name1=clean_name(original_title,1)
            
            f_link=domain_s+'ont-assets-1.finalservers.net/mp4sd.php?id='+link
           
            
            all_links.append((name1,f_link,match_s,res))
            global_var=all_links
    return global_var
    