# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[6]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
   
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    
    search_string=clean_name(original_title,1)
    
    url='https://openloadmovieshd.com/?s='+search_string.replace(' ','+')
    progress='requests'
    p = requests.get(url,headers=headers).content   
    regex='<div class="post-thumbnail">.+?<a href="(.+?)".+?"entry-title".+?rel="bookmark">(.+?)<'
    progress='Regex'
    m=re.compile(regex,re.DOTALL).findall(p)
    count=0
    for link,title in m:
       
        if search_string.lower() in title.lower() and show_original_year in title:
            progress='requests2'
            y = requests.get(link,headers=headers).content   
            regex='iframe src="(.+?)"'
            progress='Regex2-'+str(count)
            m2=re.compile(regex,re.DOTALL).findall(y)[0]
            progress='Check-'+str(count)
            count+=1
            nam1,srv,res,check=server_data(m2,original_title)
                      
            if check:
                    all_links.append((nam1.replace("%20"," "),m2,srv,res))
                    global_var=all_links
                    
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var