import requests
import unjuice,time
global progress
progress=''
import urllib2,base64
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
global global_var,stop_all#global
global_var=[]
stop_all=0
type=['movie','tv']
from general import clean_name,check_link,server_data,replaceHTMLCodes,cloudflare_request,all_colors,domain_s
color=all_colors[38]
def get_da_source(url,original_title):
            global global_var,stop_all
            User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'
            all_links=[]
            headers={'User-Agent':User_Agent}
            OPEN,cook = cloudflare_request(url)
            holder = re.compile('class="btn-watch-area".+?href="(.+?)">',re.DOTALL).findall(OPEN)[0]
            links,cook = cloudflare_request(holder)
            Regex = re.compile('class="metaframe rptss" src="(.+?)"',re.DOTALL).findall(links)
            count = 0
       
            for link in Regex:
               try:
                #self.sources.append({'source': host,'quality': rez,'scraper': self.name,'url': link,'direct': False})
                print link
                if 'movie4u' in link:
                  link=requests.get(link,headers=cook[1],cookies=cook[0]).url
                
                name1,match_s,res,check=server_data(link,original_title)
                print check
                if check:   
                   all_links.append((name1,link,match_s,res))
                   global_var=all_links
               except:
                pass
            return all_links
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):#M4U
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    all_links=''
    base_link = 'http://movie4u.live'
    requests.packages.urllib3.disable_warnings()
    User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'
    if tv_movie=='movie':
        
        search_id = clean_name(original_title,1).lower()
        start_url = '%s/?s=%s' %(base_link,search_id.replace(' ','+'))
        
        headers={'User-Agent':User_Agent}
        progress='Cloud'
        html,cook = cloudflare_request(start_url)
        regex_pre='<article>(.+?)</article>'
        progress='Regex'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
        count=0
        for items in match_pre:
            progress='Links-'+str(count)
            count+=1
            if stop_all==1:
                    break
            match = re.compile('<div class="title">.+?href="(.+?)">(.+?)</a>.+?class="year">(.+?)</span>',re.DOTALL).findall(items)
            for url,name,date in match:
                if stop_all==1:
                    break
                name=name.replace('<u>','').replace('</u>','')
                if ' 20' in name:
                    name = name.split(' 20')[0]
                elif ' 19' in name:
                    name = name.split(' 19')[0]
                else: name = name
                    
                if not clean_name(original_title,1).lower() == clean_name(name,1).lower().lower():
                    continue
                if not show_original_year in date:
                    continue
             
                all_links=get_da_source(url,original_title)
    else:
            search_id = clean_name(original_title,1).lower()
            start_url = '%s/?s=%s+season+%s' %(base_link,search_id.replace(' ','+'),season)
        
            headers = {'User_Agent':User_Agent}
            progress='Cloud2'
            html,cook = cloudflare_request(start_url)
           
            regex_pre='<article>(.+?)</article>'
            progress='Regex2'
            match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
            count=0
            for items in match_pre:
                progress='Links2-'+str(count)
                count+=1
                if stop_all==1:
                    break
                progress='Regex-'+str(count)
                Regex = re.compile('class="title".+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(items)
                
                for item_url,name in Regex:
                    progress='Links2-'+str(count)
                    if stop_all==1:
                        break
                    name=name.replace('<u>','').replace('</u>','').replace('0','')
               
                    if not clean_name(original_title,1).lower() in clean_name(name,1).lower():
                        continue
                  
                    season_chk = 'season %s' %(season)

                    if not season_chk.lower() in clean_name(name,1).lower(): 
                        continue
             
                    headers = {'User_Agent':User_Agent}
                    content,cook = cloudflare_request(item_url)

                    epi_link='%sx%s/' % (season,episode)
                        
                    match=re.compile('class="imagen"><a href="(.+?)">').findall(content)
                    
                    for ep_url in match:
                        if not epi_link in ep_url:
                            continue
                        movie_link = ep_url
                        
                        #error_log(self.name + ' PassUrl',movie_link)
                        all_links=get_da_source(ep_url,original_title)
                
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links