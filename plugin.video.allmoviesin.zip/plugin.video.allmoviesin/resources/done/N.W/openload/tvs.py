# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[90]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    import cfscrape
    all_links=[]

    base_link = 'http://openloadtvstream.me/'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    search_id = clean_name(original_title.lower(),1)
    start_url = '%s?s=%s' %(base_link,search_id.replace(' ','+'))


    
    progress='requests'
    html,cook = cloudflare_request(start_url)
   
    regex='<article>(.+?)</article>'
    progress='Regex'
    match_pre=re.compile(regex,re.DOTALL).findall(html)
    count=0
    for items in match_pre:
        
        progress='Links-'+str(count)
        count+=1
        progress='Regex-'+str(count)
        if tv_movie=='movie':
            
          match = re.compile('href="(.+?)".+?alt="(.+?)".+?class="year">(.+?)</span>',re.DOTALL).findall(items)
        else:
          match = re.compile('href="(.+?)".+?alt="(.+?)".+?class="(.+?)"',re.DOTALL).findall(items)
    
        for item_url,name,yrs in match:
            print item_url
            progress='Links2-'+str(count)
            if stop_all==1:
                        break
            if clean_name(search_id,1).lower() in clean_name(name,1).lower().replace('&#8217;',"'"):
                
                check=False
                if tv_movie=='movie':
                  if show_original_year in yrs:                                                           
                    check=True
                else:
               
                    if yrs=='tvshows':
                      if clean_name(original_title,1).lower()==name.lower():
                        check=True
                
                if check:
                    progress='requests2-'+str(count)
                    if tv_movie=='tv':
                        
                        x=requests.get(item_url,headers=cook[1],cookies=cook[0]).content
                        regex="div class='numerando'>%s - %s</div>.+?<div class='episodiotitle'>.+?<a href='(.+?)'"%(season,episode)
                        match=re.compile(regex,re.DOTALL).findall(x)
                       
                        if len(match)==0:
                          continue
                        item_url=match[0]
                    
                    OPEN = requests.get(item_url,headers=cook[1],cookies=cook[0]).content
                    
                    if 1:
                      progress='Regex2-'+str(count)
                      match2=re.compile(' postid-(.+?)"').findall(OPEN)
                      print match2
                      if len (match2)>0:
                          
                          data = [
                              ('action', 'doo_player_ajax'),
                              ('post', match2[0]),
                              ('nume', '1'),
                              ('type', tv_movie)
                          ]
                          progress='requests3-'+str(count)
                          x=requests.post('https://openloadtvstream.me/wp-admin/admin-ajax.php',data=data,headers=cook[1],cookies=cook[0]).content
                          progress='Regex3-'+str(count)
                          final_url = re.compile("src='(.+?)'").findall(x)[0]
                          progress='Check-'+str(count)
                          print final_url
                          name1,match_s,res,check=server_data(final_url,original_title)
                                
                    
                          if check :
                                all_links.append((name1.replace('  &gt;&gt;&gt; tvmoviestream.me &lt;&lt;&lt;',''),final_url,match_s,res))
                                global_var=all_links
                    else:
                        for altlink in match2:
                            if stop_all==1:
                                break
                            progress='requests4-'+str(count)
                            r = requests.get(altlink,headers=cook[1],cookies=cook[0],allow_redirects=False)
                            final_url = r.headers['location']
                            progress='Check2-'+str(count)
                            name1,match_s,res,check=server_data(final_url,original_title)
                                
                         
                            if check :
                                all_links.append((name1.replace('   &gt;&gt;&gt; tvmoviestream.me &lt;&lt;&lt;',''),final_url,match_s,res))
                                global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var