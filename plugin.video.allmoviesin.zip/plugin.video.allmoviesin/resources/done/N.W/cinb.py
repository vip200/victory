import requests,re
import unjuice

global global_var,stop_all#global
global_var=[]

stop_all=0
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s

type=['movie','tv']
import urllib2,urllib,logging
color=all_colors[12]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    '''
    sUrl=domain_s+'www.cinebloom.com/search?q='+(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}

    
    html= requests.get(sUrl,headers=headers).content 

   
    regex='meta itemprop="url" content="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)

    for link1 in match:
    '''
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    if 1:
       
        link1='https://www2.cinebloom.net/searching?q='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
        y=requests.get(link1,headers=headers).content 
        regex='"http://schema.org/Movie".+?a href="(.+?)".+?itemprop="name">(.+?)<'
        match2=re.compile(regex,re.DOTALL).findall(y)
      
        for links1,name_in in match2:
           if stop_all==1:
                        break
           check=False
           
           
           if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in name_in:
                check=True
             
           if check:
               z=requests.get(links1,headers=headers).content 
               if tv_movie=='movie':
               
                   regex='div class="embed-details"><a href="(.+?)"'
                   m=re.compile(regex).findall(z)
               else:
                    regex='<span class="title">Season %s</span>(.+?)</tr>'%season_o
                    m_pre=re.compile(regex,re.DOTALL).findall(z)
                    regex='<h5>EP %s:</h5>(.+?)</div>'%episode_o
                    m_pre2=re.compile(regex,re.DOTALL).findall(m_pre[0])
                    regex='<a href="(.+?)"'
                    m=re.compile(regex,re.DOTALL).findall(m_pre2[0])
               for links in m:
                try:
                    if stop_all==1:
                            break
                   
                    
                    
                   
                    if 'spider' in links:
                        links = replaceHTMLCodes(links)
                        #cj = requests.get(link1,headers=headers).cookies
                        import cookielib
                        import urllib2

                        cookies = cookielib.LWPCookieJar()
                        handlers = [
                            urllib2.HTTPHandler(),
                            urllib2.HTTPSHandler(),
                            urllib2.HTTPCookieProcessor(cookies)
                            ]
                        opener = urllib2.build_opener(*handlers)
                        opener.addheaders = [('User-agent',  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0')]
                        
                        req = urllib2.Request(link1)
                        a=opener.open(req)
                        ck={}
                        for cookie in cookies:
                           ck[cookie.name]= cookie.value
                        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                                   'Referer': link1}
                        headers['Cookie'] = urllib.urlencode(ck)
                        r = requests.get(links, headers=headers).content
                        
                        link = re.findall('iframe.+?src="(.+?)"',r)
                        if len(link)>0:
                          link=link[0]
                        else:
                          link=''
                    else:
                       
                        link = requests.get(links, headers=headers,timeout=5,stream=True).url
                        #r = requests.get(links, headers=headers).content
                        #link = re.findall('iframe.+?src="(.+?)"',r)[0]
               
                    nam1,srv,res,check=server_data(link,original_title)
                  
                    if check:
                      all_links.append((nam1.replace("%20"," ").replace('[cinebloom.com]-',''),link,srv,res))      
                      global_var=all_links
                except:
                   print links
                   pass
    return all_links

