# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[102]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    #import cfscrape
    all_links=[]
    base_link = 'http://myputlocker.me'
    search_link = '/%s-s%s-e%s'
    url = base_link + search_link % (clean_name(original_title,1).replace(' ','-'),season,episode)
    progress='Cloud'
    print url
    r ,cook= cloudflare_request(url)
    if 'Watch it here' in r:
        regex='Watch it here.+?<a href="(.+?)"'
        m=re.compile(regex,re.DOTALL).findall(r)[0]
        if 'http' not in m:
            m='http:'+m
        print m
        r=requests.get(m,headers=cook[1],cookies=cook[0]).content
    progress='Regex'
    match = re.compile("data-src='(.+?)'").findall(r)
    count=0
    for url in match:
        
        if stop_all==1:
              break
        if 'http' not in url:
           url='http:'+url
        progress='Check-'+str(count)
        count+=1
        name1,match_s,res,check=server_data(url,original_title)
                        
                          
        if check :
            all_links.append((name1,url,match_s,res))
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var