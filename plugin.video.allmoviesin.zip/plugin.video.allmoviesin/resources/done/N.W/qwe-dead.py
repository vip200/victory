# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache
from urlparse import urljoin

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[68]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all


    all_links=[]
    x=requests.get('https://qwermovies.net/search?search='+clean_name(original_title,1).replace(' ','+'),headers=base_header).content
    regex="<div class='col-md-.+?'><a href=\'(.+?)\' onclick=.+?<figcaption>(.+?)</figcaption"
    match=re.compile(regex).findall(x)
    for link,name in match:
        if stop_all==1:
                    break
        if clean_name(original_title,1).lower()==name.lower():
           
            y=requests.get(link,headers=base_header).content
            if tv_movie=='tv':
                
                regex='<li class="list-group-item"><a id="changeMN" href="(.+?)"> Season %s <'%season
                
                match_tv=re.compile(regex).findall(y)[0]
                
                y=requests.get(urljoin(link, match_tv),headers=base_header).content
            if tv_movie=='tv':
                regex=' <div class="pages"> <p class="ispo"> Server 1 </p>(.+?)</div'
                match_ee=re.compile(regex,re.DOTALL).findall(y)[0]
                
                regex='<a id="(.+?)".+?>%s </a>'%episode_n
                ep_id=re.compile(regex).findall(match_ee)[0]
            regex='function change(.+?)</script>'
            match_pre=re.compile(regex,re.DOTALL).findall(y)[0]
            if tv_movie=='tv':
                
                
                
                regex='case %s:.+?rc= (.+?)\[(.+?)\](?:\n|;)'%ep_id
                match_ep=re.compile(regex,re.DOTALL).findall(match_pre)
                regex='var %s=\[(.+?)\]'%match_ep[0][0]
                match_ep1=re.compile(regex).findall(match_pre)
                regex='"(.+?)"'
                match_ep2=re.compile(regex).findall(match_ep1[0])
                match_2=[]
                match_2.append(match_ep2[int(match_ep[0][1])])
                
            else:
                regex='var .+?"(.+?)"'
                match_2=re.compile(regex).findall(match_pre)
            
            for items in match_2:
                if stop_all==1:
                    break
                links_in=items.decode('unicode_escape')
               
                name1,match_s,res,check=server_data(links_in,original_title)
                        
                          
                if check :
                    all_links.append((name1,links_in,match_s,res))
                    global_var=all_links
    return global_var