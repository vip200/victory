# -*- coding: utf-8 -*-
import requests,re,PTN,logging
import unjuice,time,os
try:
 import xbmcaddon,xbmc
 Addon = xbmcaddon.Addon()


 user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
except Exception as e:

  user_dataDir=os.path.join(os.getcwd(),'done','cache_f')
  pass
global global_var,stop_all,color#global
global_var=[]
stop_all=0



from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,base64,json
color=all_colors[0]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,color

    all_links=[]
    if tv_movie=='tv':
      url='http://1movies.biz/movies/search?s='+(clean_name(original_title,1).replace("Marvel's ",'')+'+season+'+season)
    else:
      url='http://1movies.biz/movies/search?s='+(clean_name(original_title,1)+'+'+show_original_year)
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        #'Host': '1movies.biz',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    import cfscrape
    scraper = cfscrape.create_scraper()
    html=scraper.get(url,headers=headers).content
    
    regex='<div class="item_movie">.+?href="(.+?)" title="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
    for link,name in match:
        if stop_all==1:
            break
        check=False
        if tv_movie=='tv':
          if 'Season '+season in name:
            check=True
        else:
          if show_original_year in name:
            check=True

        if clean_name(original_title,1).lower().replace("marvel's ",'') in name.lower().replace('&#039;',"'") and check:
            x=scraper.get(link,headers=headers).content
            if tv_movie=='tv':
                regex='<a href=".+?episode_id=(.+?)" class="">Episode %s</a>'%episode
      
                id=re.compile(regex).findall(x)[0]
            else:
                regex='load_player\((.+?)\);'
                id=re.compile(regex).findall(x)[0]
            headers1 = {
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.5',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                #'Host': '1movies.biz',
                'Pragma': 'no-cache',
                'Referer': link,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                'X-Requested-With': 'XMLHttpRequest',
            }
            url='http://1movies.biz/ajax/movie/load_player_v3?id='+id
            x=scraper.get(url,headers=headers1).json()
            headers = {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            #'Host': 'play.1movies.biz',
            'Origin': 'http://1movies.biz',
            'Pragma': 'no-cache',
            'Referer': link,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            }

            y=scraper.get('http:'+x['value'],headers=headers).json()
            if 'playlist' not in y:
                url='http://1movies.biz/ajax/movie/load_player_v3?retry=2&id='+id
                x=scraper.get(url,headers=headers1).json()
                y=scraper.get('http:'+x['value'],headers=headers).json() 
            url=y['playlist'][0]['file']
            
            
            name1=original_title
            res=' '
         
            if 'tracks' in y:
               if len(y['tracks'])>0:
                 if 'file' in y['tracks'][0]:
                  names=y['tracks'][0]['file'].split('/')
                  name1=names[len(names)-1].replace('.vtt','')
                  if '1080' in name1:
                      res='1080'
                  elif '720' in name1:
                      res='720'
                  elif '480' in name1:
                      res='480'
                  elif '360' in name1:
                      res='360'
                  else:
                      res='HD'
                      

            new_file=url
            if '.m3u8' in url:
              responce,cook=cloudflare_request(url)
              
              subfixs=url.rsplit('/', 1)[1]
             
              subflix=url.replace(subfixs,'')
            
              regex='URI="(.+?)"'
              match=re.compile(regex).findall(responce)
            
              responce,cook=cloudflare_request(match[0])
              f_data=responce.replace("BYTERANGE",'TARGETDURATION')
              f_data=f_data.replace("seg-",subflix+'seg-')
              new_file=os.path.join(user_dataDir ,'new.m3u8')
              try:
                xbmcvfs.delete(new_file)
              except:
               pass
              
              with open(new_file, "w+") as text_file:
                    text_file.write(f_data)
            all_links.append((name1,new_file,'Direct',res))
            global_var=all_links
    return global_var