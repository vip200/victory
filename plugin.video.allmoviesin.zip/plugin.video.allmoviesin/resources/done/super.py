# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,get_vidcloud
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[96]
def get_direct(link):
    headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
                
            }
    print link
    x=requests.get(link,headers=headers).content
    regex='<a href="(.+?)"'
    match=re.compile(regex).findall(x)
    id=urlparse.parse_qs(urlparse.urlparse(match[0]).query)['id'][0]
   
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': link,
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('id', id),
    )

    response = requests.get('https://vidcloud.icu/streaming.php', headers=headers, params=params).content
    
    regex="sources:\[\{file: '(.+?)'"
    match=re.compile(regex).findall(response)

    regex='<iframe id="embedvideo" src="(.+?)"'
    match2=re.compile(regex).findall(response)
    m_final=match+match2
   
    return m_final
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        all_links=[]
        url='http://supermobileandroid.com/moviedata/movies/viewnamenew/%s/20/0.json'%clean_name(original_title,1)
        headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
                
            }
        html=requests.get(url,headers=headers).json()
        for items in html['movie']:
            if stop_all==1:
                    break
            
            if clean_name(original_title,1).lower()  in items['Movie']['name'].lower() and show_original_year==items['Movie']['published']:
                link=items['Movie']['url']
                
                if 'mov1.wallapk.space' in link:
                  f_link=[]
                  try:
                   f_link=get_direct(link)
                  except:
                    pass
                  for link_in in f_link:
                    
                    if 'rapidvideo' in link_in:
                        name1,match_s,res,check=server_data(link_in,original_title)
                        
                        if check :
                            all_links.append((name1,link_in,match_s,res))
                            global_var=all_links
                    else:
                        if 'http://error.com' not in link_in:
                            all_links.append((clean_name(original_title,1),link_in,'Direct',' '))
                            global_var=all_links
                else:
                    if 'vidcloud' in link:
                        lks,hdr=get_vidcloud(link)
                            
                        for f_link in lks:
                            name1,match_s,res,check=server_data(f_link,original_title)
                           
                            if check :
                                head=urllib.urlencode(hdr)
                                f_link=f_link+"|"+head
                                all_links.append((name1,f_link,match_s,res))
                                global_var=all_links
                    else:
                        name1,match_s,res,check=server_data(link,original_title)
                           
                        if check :
                           
                            all_links.append((name1,link,match_s,res))
                            global_var=all_links
                link=items['Movie']['url2']
                
                if len(link)>0:
                   if 'vidcloud' in link:
                        lks,hdr=get_vidcloud(link)
                            
                        for f_link in lks:
                            name1,match_s,res,check=server_data(f_link,original_title)
                           
                            if check :
                                head=urllib.urlencode(hdr)
                                f_link=f_link+"|"+head
                                all_links.append((name1,f_link,match_s,res))
                                global_var=all_links
                   else:
                        name1,match_s,res,check=server_data(link,original_title)
                           
                        if check :
                           
                            all_links.append((name1,link,match_s,res))
                            global_var=all_links
        return global_var
        