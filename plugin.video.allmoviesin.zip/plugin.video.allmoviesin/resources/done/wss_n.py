# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global progress
progress=''
global_var=[]
stop_all=0

rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[105]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
   
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('keyword', clean_name(original_title,1)),
        ('id', '-1'),
    )

    response = requests.get('https://www4.watchseries.fm/ajax-search.html', headers=headers, params=params).json()
    ans= response['content']
    regex='<a href="(.+?)" class="ss-title">(.+?)<'
    m=re.compile(regex).findall(ans)
    t_test=clean_name(original_title,1).lower()+' - Season '+season
    
    for lk,title in m:
       
       
        if title.lower().replace(' ','')==t_test.lower().replace(' ',''):
            n_lk='https://www5.watchseries.fm'+lk+'-episode-'+episode
           
            x=requests.get(n_lk,headers=base_header).content
            regex='iframe src="(.+?)"'
            url=re.compile(regex).findall(x)[0]
   
            if stop_all==1:
                    break
            if 'http' not in url:
                url = 'http:' + url
            if 'vidcloud.icu' in url:
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': n_lk,
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }
                progress='requests2'
                x=requests.get(url,headers=headers).content
               
                regex="sources.+?file: '(.+?)'"
                
                url=re.compile(regex).findall(x)
                
                if len(url)>0:
                  url=url[0]
                else:
                  regex='player.setup.+?file: "(.+?)"'
                
                  url=re.compile(regex,re.DOTALL).findall(x)[0]
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': 'https://vidcloud.icu/',
                    'Origin': 'https://vidcloud.icu',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }
                head=urllib.urlencode(headers)
                     #ht=requests.get(url,headers=headers).content

                url=url+"|"+head
                all_links.append((original_title,url,'Direct',' '))
                global_var=all_links
            else:
                progress='Check'
                name1,match_s,res,check=server_data(url,original_title)
                            
                              
                if check :
                    all_links.append((name1,url,match_s,res))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
            