# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[100]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    base_link = 'https://hdm.to'
    
    url = '%s/%s/' % (base_link,clean_name(original_title,1).replace(' ','-'))

    r,cook = cloudflare_request(url)
 
    match = re.compile('<iframe.+?src="(.+?)"').findall(r)

    for url in match:
        if stop_all==1:
             break
        if 'hdm.to/src' in url:
            n_url=url.split('v=')[1]
            n_url=n_url.replace("lsd.to/", "hls.lsd.to/vod/")+"/playlist.m3u8"
        name1,match_s,res,check=server_data(n_url,original_title)
                        
                          
        if check :
            all_links.append((name1,n_url,'Direct',res))
            global_var=all_links
    return global_var