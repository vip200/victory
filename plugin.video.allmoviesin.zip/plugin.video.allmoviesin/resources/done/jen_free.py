# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,os
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header,Addon
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[5]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    dataPath = os.path.dirname(os.path.realpath(__file__))
    mypath=os.path.join(dataPath,'cache_f')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    if allow_debrid:
        return []
    
    all_links=[]
    progress='DB'
    tmdb_cacheFile = os.path.join(mypath, 'jen_db.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("SELECT * FROM tmdb_data WHERE name like '%{0}%'".format(clean_name(original_title,1).replace('.',' ').replace("'","%27").lower()))
   
    
    match4 = dbcur_tmdb.fetchall()

    count=0
    for eng_name,link,year,type,num in match4:
        progress='Links-'+str(count)
        count+=1
        if type!='free':
            continue
        names=link.split('/')
        name1=names[len(names)-1]
        if '2160' in name1:
              res='2160'
        elif '4k' in name1.lower():
              res='2160'
        elif '1080' in name1:
              res='1080'
        elif '720' in name1:
              res='720'
        elif '480' in name1:
              res='480'
        elif '360' in name1:
              res='360'
        else:
              res='720'
        if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
            check=True
        else:
            check=False
        
        if check==False:
            name1,match_s,res,check=server_data(link,original_title)
            if '2160' in name1:
                  res='2160'
            elif '4k' in name1.lower():
                  res='2160'
            elif '1080' in name1:
                  res='1080'
            elif '720' in name1:
                  res='720'
            elif '480' in name1:
                  res='480'
            elif '360' in name1:
                  res='360'
            else:
                  res='720'
              
        all_links.append((name1,link,match_s,res))
        global_var=all_links
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    
    return all_links
