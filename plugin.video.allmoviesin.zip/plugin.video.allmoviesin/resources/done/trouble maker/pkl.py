# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[104]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    import cfscrape
    scraper = cfscrape.create_scraper()
    all_links=[]
    base_link = 'https://www0.putlocker.onl'
    tv_link = '/show/%s/season/%s/episode/%s'
    movie_link = '/movie/%s'
 
    if tv_movie=='movie':
        url = base_link + movie_link % (clean_name(original_title,1).replace(' ','-'))+'/watching.html'
    else:
        url = base_link + tv_link % (clean_name(original_title,1).replace(' ','-'),season,episode)
    print url
    exit()
    r = scraper.get(url).content


    
    match = re.compile('<IFRAME.+?SRC="(.+?)"').findall(r)
  
    for link in match:
        if 'http' not in link:
            link='http:'+link
        if stop_all==1:
                    break
    
        name1,match_s,res,check=server_data(link,original_title)
                        
                          
        if check and 'upvid.co/' not in link:
            all_links.append((name1,link,match_s,res))
            global_var=all_links
    return global_var