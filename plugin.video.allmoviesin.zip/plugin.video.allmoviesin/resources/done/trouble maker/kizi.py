# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[35]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    if tv_movie=='tv':
      url=domain_s+'www.kizi.video/search.php?keywords='+clean_name(original_title,1).replace(' ','+')+'+s'+season_n+'e'+episode_n
    else:
      url=domain_s+'www.kizi.video/search.php?keywords='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    #'Host': 'www.kizi.video',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    html=requests.get(url,headers=headers).content
    regex='<div class="pm-video-thumb">.+?<a href="(.+?)" title="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)

    
    for link,title in match:
       check=False
     
       if tv_movie=='movie':
         if clean_name(original_title,1).lower() in title.lower().replace(':','') and show_original_year in title:
           check=True
       else:
         if clean_name(original_title,1).lower() in title.lower().replace(':','') and ('s%se%s'%(season_n,episode_n) in title.lower() or 'season %s episode %s'%(season_n,episode_n) in title.lower()):
           check=True

       if check:
         
         x=requests.get(link.replace('watch.php','view.php'),headers=headers).content
  
         regex='<iframe src="(.+?)"'
         match2=re.compile(regex).findall(x)
         y=requests.get(match2[0],headers=headers).content

         regex='file:"(.+?)"'
         match_l=re.compile(regex).findall(y)
         for links in match_l:
           all_links.append((original_title,links,'Direct',' '))
           global_var=all_links
           
         x=requests.get(link.replace('watch.php','download.php'),headers=headers).content
         regex='<iframe.+?src="(.+?)"'
         match3=re.compile(regex).findall(x)

         resolvable=resolveurl.HostedMediaFile(match3[0]).valid_url()
         name1,match_s,res,check=server_data(match3[0],original_title)
         
         if check and resolvable:
            all_links.append((name1,match3[0],match_s,res))
            global_var=all_links
    return global_var
    