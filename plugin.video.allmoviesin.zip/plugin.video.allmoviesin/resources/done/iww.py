# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[105]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    search_id =clean_name(original_title,1)
    
    base_link = 'https://www.iwannawatch.is'
    search = '/wp-admin/admin-ajax.php?action=bunyad_live_search&query='
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))
    headers=base_header
    OPEN = requests.get(start_url,headers=headers).content

    Regex = re.compile('<li>.+?<a href="(.+?)".+?title="(.+?)".+?<a href=.+?>(.+?)<',re.DOTALL).findall(OPEN)

    for item_url,name,release in Regex:

        if '(' in name:

            release=release.split('(')[-1].split(')')[0]

            name=name.split('(')[0]

          

            if not show_original_year == release:

                continue

        if search_id.lower() in name.lower().strip():
            print item_url
            OPEN = requests.get(item_url,headers=headers,timeout=20).content

            quality_r = re.compile('<div class="cf">.+?class="quality">(.+?)</td>',re.DOTALL).findall(OPEN)

            for quality in quality_r:

                if "1080" in quality:
                  o_res="1080"
                elif "720" in quality:
                  o_res="720"
                elif "480" in quality:
                   o_res="480"
                else:
                   o_res=' '



           

            OPEN = requests.get(item_url,headers=headers).content

            Regex = re.compile('li class=.+?data-href="(.+?)"',re.DOTALL).findall(OPEN)

            for link in Regex:

                if 'http' not in link:

                    link = 'http:'+link

                name2,match_s,res,check=server_data(link,original_title)
                if res==' ':
                  res=o_res
                
                if check:

                    all_links.append((name2,link,match_s,res))
                    
                    global_var=all_links
    return all_links
                 
