# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
rating=['SSS','7M/s']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['tv','movie']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
import urllib2,urllib,logging,base64,json
color=all_colors[79]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        all_links=[]
        if tv_movie=='movie':
          url = 'https://www.mkvcage.net/search?q='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
        else:
          url = 'https://www.mkvcage.net/search?q='+clean_name(original_title,1).replace(' ','+')+'+'+'s'+season_n+'e'+episode_n
        progress='requests'
        x=requests.get(url,headers=base_header).content
        regex="<article class='post hentry'.+?<a href='(.+?)'.+?title='(.+?)'"
        progress='Regex'
        m=re.compile(regex,re.DOTALL).findall(x)
        for link,title in m:
            if clean_name(original_title,1).lower() in title.lower():
           
                if 'dubbed' in link:
                    continue
                progress='requests2'
                y=requests.get(link,headers=base_header).content
                regex='<span style="font-size: x-large;".+?<a href="(.+?)" target="_blank">(.+?)<'
                progress='Regex2'
                n_pre=re.compile(regex,re.DOTALL).findall(y)
                for lk,ty in n_pre:
                    if 'download' in ty.lower():
                        n=lk
                        break
                progress='requests3'
                z=requests.get(n,headers=base_header).content
                regex='<input type="hidden" name="(.+?)" value="(.+?)"'
                progress='Regex3'
                n1=re.compile(regex).findall(z)
                progress='requests4'
                new_link = requests.get(n, headers=base_header).url
                data = {
                  n1[0][0]: n1[0][1]
                }

                
               

                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    #'Referer': 'https://www.linkprotector.org/view/gNpgYGB6hN2mjwqp2hEK',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }

               
                progress='requests4'
                response = requests.post(new_link, headers=headers, data=data).content
                
                regex='href="(.+?)"'
                progress='Regex4'
                l=re.compile(regex).findall(response)
                count=0
                for links in l:
                    if 'openload' in links or 'uptobox' in links or 'uptostream' in links or 'rapidvideo' in links or 'streamango' in links:
                        progress='Check-'+str(count)
                        count+=1
                        name1,match_s,res,check=server_data(links,original_title)
                            
                        
                        if check :
                              all_links.append((name1,links,match_s,res))
                              global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var
        