# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','subs']

import urllib2,urllib,logging,base64,json
color=all_colors[16]
def decrypt(url):
    from base64 import b64decode
    ''' decrypt the given encrypted code '''
    html=requests.get(url).content
    

    regex="var ysmm = '(.+?)'"
    match=re.compile(regex).findall(html)
    if len(match)>0:
        
        ysmm = match[0]
      
        #ysmm='Y=jMkDyNM3GUUD1MYwzIJWiNYx2UZmmNOkTVcDyMMi2Rh20Yd6HIAT6MLiyN9G0Nd33McTuZdymMljkYZvWU9G3bZpWZV1kLLzmV'
        code=(ysmm.decode('utf-8'))

        zeros, ones = '', ''

        for num, letter in enumerate(code):
            if num % 2 == 0: zeros += code[num]
            else: ones = code[num] + ones

        key = zeros + ones
 
        u=list((key))
 
        m=0
        while m <(len(u)-1):
          if u[m].isnumeric():
              R=m+1
              while R< (len(u)-1): 
                if u[R].isnumeric():
                     
                  S =(int(u[m]) ^ int(u[R]))


                  if ((S) < 10):

                    u[m] = unicode(S)
                  m = R
                  R = len(u)
                R=R+1
          m=m+1
        t3="".join(u)

        key = (t3).decode('base64')

        key=key[(len(t3)-(len(t3)-16)):]
 
        key=key[:((len(key)-16))]
    else:
      from unshort import unshorten
 
     
      unshortened_uri, status = unshorten(url,type='shst')

      if unshortened_uri==url:
        unshortened_uri, status = unshorten(url,type='shst')
      key=unshortened_uri
     
    if 'motheregarded.info' in key:
        regex='dp_href=(.+?)&dp_lp'
        m=re.compile(regex).findall(key)
        if len(m)>0:
            return urllib.unquote_plus(m[0])
    return key
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        all_links=[]
        all_l=[]
        dub='no'
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Host': 'seretnow.me',
            'Pragma': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }

        all_links=[]
        url='http://seretnow.me/?s='+urllib.quote_plus(name)
        progress='requests'
        x=requests.get(url,headers=headers).content
        progress='Regex'
        regex='<a href="(.+?)" rel="bookmark" title="(.+?)">'
        match=re.compile(regex).findall(x)
        count=0
        for link,name_in in match:
          progress='Links-'+str(count)
          count+=1
          if stop_all==1:
               break
          if dub=='yes':
            if 'מדובב' in name_in:
              cn=True
            else:
              cn=False
          else:
             cn=True
          name_fix='$$$'+name_in.split('/')[0].strip()

          if '$$$'+name+' לצפייה ' in name_fix and cn==True:
            progress='requests-'+str(count)
            y=requests.get(link).content
            regex2='<a href="(.+?)" target="_blank" rel=".+?">(.+?)<'
            match2=re.compile(regex2).findall(y)
            if len(match2)==0:
               regex2='a href="(.+?)" target="_blank">(.+?)<'
               match2=re.compile(regex2).findall(y)

            
            
            for links,server in match2:
                progress='Links2-'+str(count)
                if stop_all==1:
                    break
                quality=' '
              
                
                try:
                    links=decrypt(links)
                except:
                    pass
               
                if 'ecleneue.com' in links:
                  
                   
                    regex='&dest=(.+?)$'
                    m=re.compile(regex).findall(links)
                  
                    if len(m)>0:
                        links=m[0]
               
                if links not in all_l:
                    all_l.append(links)
                    progress='Check-'+str(count)
                    name1,match_s,res,check=server_data(links,original_title)
                    
                    if check:
                        all_links.append((name_in,links,match_s,res))
                        
                        global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links