
import requests,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors

type=['tv']
import urllib2,urllib,logging,base64,json
color=all_colors[13]
def decode_link(code):
    import js2py
    from js2py.internals import seval
    code=code.decode('base64')
    code_d='FileID=(\'%s\').replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26)});'%code
   
    result=seval.eval_js_vm(code_d)
    #FileID=atob(FileID).replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26)});
    '''
    d_code=list(code)
    fileid=''
  
    for c in d_code:
      if not c.isdigit():
          c=ord(c)

          if (c <= ord("Z")):
            temp=90
          else:
            temp=122
   
          temp2=c + 13
          c=temp2

          if ((temp) >=temp2 ):
           c=c
          else:  
           c=c - 26

          fileid=fileid+chr(c)
      else:
        fileid=fileid+str(c)
    '''
    
    return domain_s+'openload.co/embed/'+result
def refresh_second_link(x,url):
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'X-Requested-With': 'XMLHttpRequest',
        'X-MicrosoftAjax': 'Delta=true',
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'TE': 'Trailers',
    }
    
    regex='id="__VIEWSTATE" value="(.+?)"'
    v_s=re.compile(regex).findall(x)[0]
    
    regex='id="__EVENTVALIDATION" value="(.+?)"'
    e_v=re.compile(regex).findall(x)[0]
    
    regex='id="__VIEWSTATEGENERATOR" value="(.+?)"'
    v_g=re.compile(regex).findall(x)[0]
    
    data = {
      'ctl00$ctl11': 'ctl00$MainContentHolder$UpdatePanel1|ctl00$MainContentHolder$RefreshLinkButton',
      '__EVENTTARGET': '',
      '__EVENTARGUMENT': '',
      '__LASTFOCUS': '',
      '__VIEWSTATE': v_s,
      '__VIEWSTATEGENERATOR': v_g,
      '__EVENTVALIDATION': e_v,
      'ctl00$SearchTextBox': '',
      'ctl00$AutoCompleteExtenderValueHiddenField': '',
      'ctl00$MainContentHolder$ReportDropDown': '0',
      'hiddenInputToUpdateATBuffer_CommonToolkitScripts': '1',
      '__ASYNCPOST': 'true',
      'ctl00$MainContentHolder$RefreshLinkButton': 'Refresh Link'
    }

    response = requests.post(url, headers=headers, data=data).content

    return  response

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
        headers = {
            #'Host': 'www12.tvzion.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': '*/*',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            #'Referer': domain_s+'www12.tvzion.com/watch-tv-series-online/keyword-streamable/arrow-0/1',
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json; charset=utf-8',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = {'prefixText':original_title.replace("%20"," ").replace("%27","'"),'count':'100'}
        progress=' Cloud '
        response,cook=cloudflare_request('http://www12.tvzion.com/WebServices/WebService.asmx/GetShowCompletionList?'+urllib.urlencode(data),headers=headers)
        
        progress='Regex'
        regex='<string>(.+?)</string>'
        match=re.compile(regex).findall(response)
        #response=json.loads(match)
        res={'results':[]}
        
        for result in (match):
          progress=' Results '
          info=(PTN.parse(json.loads(result)['First']))
          if 'title' not in info:
          
            
              title=json.loads(result)['First']
          else:
                title=info['title']
          if original_title.replace("%27","'").replace("%20"," ").lower() in title.lower():

            if tv_movie=='tv':
              
                res['results'].append(json.loads(result))
            else:
              if str(info['year'])==str(year):
                  res['results'].append(json.loads(result))
        
        if len(res['results'])>0:
            data = {'ShowID':res['results'][0]['Second']}
           
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'TE': 'Trailers',
            }

          

            #response = requests.get('https://www12.tvzion.com/WebServices/WebService.asmx/GetUrl', headers=headers, params=params, cookies=cookies)
            progress=' cloud2 '
            y,cook=cloudflare_request('http://www12.tvzion.com/WebServices/WebService.asmx/GetUrl?'+urllib.urlencode(data),headers=headers)
           
            regex='<strin.+?>(.+?)</string>'
            match2=re.compile(regex,re.DOTALL).findall(y)
          
            progress=' cloud3 '
           
            z,cook=cloudflare_request(match2[0].replace(" ","").replace("https:","http:"),headers=headers)
            
           
            regex='<a itemprop="url" href="(.+?)"'
            match=re.compile(regex).findall(z)
            
            zy=0
            count=0
            for links in match:
                progress=' Links - '+str(count)
                count+=1
                if stop_all==1:
                    break
                if tv_movie=='tv':
                  pr_tv=(zy*100)/len(match)
                  zy=zy+1
                 
                  
                  if 'season-%s-episode-%s-'%(str(season),str(episode)) in links:
                     
                     zz,cook=cloudflare_request(links.replace("https:","http:"),headers=headers)
                   
                     regex_in="var FileID = '(.+?)'"
                     match_in=re.compile(regex_in).findall(zz)
                   
                     
                     f_link=decode_link(match_in[0])
                 
                     name1,match_s,res,check=server_data(f_link,original_title)
                    
                     if check:
                          all_links.append((name1.replace("%20"," "),f_link,match_s,res))
                    
                          global_var=all_links
                     
                     refresh_second_link(zz,links)
                     regex="this.page.identifier = '(.+?)'"
                     m=re.compile(regex).findall(zz)
                     cookies = {
                            'UserRefreshedLink_'+m[0]: '1',
                           
                        }
                    
                     headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': links,
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                     }  
                     progress=' Req - '+str(count)
                     zz = requests.get(links, headers=cook[1], cookies=cook[0]).content
                   
                     regex_in="var FileID = '(.+?)'"
                     match_in=re.compile(regex_in).findall(zz)
                    
                     f_link=decode_link(match_in[0])
                 
                     name1,match_s,res,check=server_data(f_link,original_title)
                    
                     if check:
                          all_links.append((name1.replace("%20"," "),f_link,match_s,res))
                    
                          global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    