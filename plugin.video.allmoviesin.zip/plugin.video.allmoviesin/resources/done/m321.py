import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[87]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    User_Agent="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    base_link = 'https://321movies.org'
    mock_ID = clean_name(original_title.lower(),1).replace(' ','-')

    if tv_movie=='movie':
      loop_url = ['online-free','for-free','online-free-movies','free','']
    else:
      loop_url = ['%s/episodes/%s-%sx%s/' %(base_link,clean_name(original_title.lower(),1).replace(' ','-'),season,episode)]



    

    
    
    for attempt in loop_url:
        if stop_all==1:
             break
        if tv_movie=='movie':
          movie_url = '%s/film/watch-%s-%s/' %(base_link,mock_ID.replace(' ','-'),attempt)
          if movie_url.endswith('-'):
            movie_url=movie_url.replace('watch-','')[:-1]
        else:
          movie_url=attempt
        
        
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': movie_url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        html =requests.get(movie_url,headers=headers).content
   
        match = re.compile('name="title" value="(.+?)"',re.DOTALL).findall(html)
        
  
        
        for item_title in match:
            if stop_all==1:
                    break
            print item_title
            if tv_movie=='movie':
              if not clean_name(original_title.lower(),1) == clean_name(item_title.lower(),1) :
                continue
            
            if tv_movie=='movie':
              Regex = re.compile('</iframe>.+?class="metaframe rptss" src="(.+?)"',re.DOTALL).findall(html)
            else:
              Regex = re.compile('class="metaframe rptss" src="(.+?)"').findall(html)
            count = 0
            
            for link in Regex: 
                if stop_all==1:
                    break
                print link
                host = link.split('//')[1].replace('www.','')
                host = host.split('/')[0].split('.')[0].title()
                name2,match_s,res,check=server_data(link,original_title)
                
                if check and 'waaw.tv' not in link:
                    all_links.append((name2,link,match_s,res))
                        
                    global_var=all_links
    return global_var