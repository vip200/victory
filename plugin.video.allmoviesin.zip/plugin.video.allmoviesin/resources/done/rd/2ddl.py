# -*- coding: utf-8 -*-
import requests,re,PTN,urlparse,Addon
import unjuice,time,dom_parser,HTMLParser
global progress
progress=''
global global_var,stop_all,color#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,local
type=['tv','movie','rd']

import urllib2,urllib,logging,base64,json

  


color=all_colors[81]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    start_time=time.time()
    progress='Start'
    rd_sources=Addon.getSetting("rdsource")
    allow_debrid = rd_sources == "true" 
    logging.warning('allow_debrid:'+str(allow_debrid))
    all_links=[]
    if not allow_debrid:
      return []
    progress='Rd ok'
    if tv_movie=='tv':
        search_url=clean_name(original_title,1).replace(' ','+')+'+s%se%s'%(season_n,episode_n)
    else:
        search_url=clean_name(original_title,1)+'+'+show_original_year
    print search_url
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('phrase', search_url),
        ('pindex', '1'),
        ('content', 'true'),
        ('type', 'Simple'),
        ('rand', '0.3513088495757427'),
    )

    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'search.rlsbb.ru:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }

    url = 'http://rlsbb.ru/'+search_url.replace(' ','-')
    print url
    progress='CLD'
    x,tk=cloudflare_request('http://search.rlsbb.ru/Home/GetPost')
    response = requests.get('http://search.rlsbb.ru/Home/GetPost',headers=tk[1],cookies=tk[0], params=params).json()
    
    
    

   
    count=0
    for items in response['results']:
        
        progress='items:'+str(count)
        count+=1
        if stop_all==1:
                break
            
        r='http://%s/'%items['domain']+items['post_name']
        logging.warning(r)
        r = requests.get(r,headers=tk[1],cookies=tk[0]).content
        
        regex='<ul class="commentList">(.+?)<div class="commentNavigation">'
        m=re.compile(regex,re.DOTALL).findall(r)
        if len(m)==0:
            continue
        regex='<a href="(.+?)" rel='
        items_o=re.compile(regex).findall(m[0])
        all_l=[]
        
        
        for link in items_o:
            progress='link:'
            if stop_all==1:
                break
            
            if link in all_l:
                continue
            all_l.append(all_l)
               
            host = link.replace("\\", "")
            host2 = host.strip('"')
            host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
          
            if host not in rd_domains:
                continue
            if '.iso' in link or '.rar' in link or '.zip' in link:
                continue
            names=link.split('/')
            name1=names[len(names)-1]
            if '1080' in name1:
                  res='1080'
            elif '720' in name1:
                  res='720'
            elif '480' in name1:
                  res='480'
            elif '360' in name1:
                  res='360'
            else:
                  res='720'
      
            #name1,match_s,res,check=server_data(link,original_title,direct='rd')
            if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                check1=True
            else:
                check1=False
            if local:
                check=True
                name1,match_s,res,check=server_data(link,original_title)
            else:
                
                name1,match_s,res,check=server_data(link,original_title)
            progress='Check Links:'
            if check and check1:
                all_links.append((name1.replace("%20"," ").replace(".mkv","").replace(".html",""),link,match_s,res))
                global_var=all_links
           
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    