# -*- coding: utf-8 -*-
import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header,res_q


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['movie','tv','subs']
def utf8_urlencode(params):
    import urllib as u
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in params.items():
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, long, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return u.urlencode(params.items()).decode('utf-8')
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        all_links=[]
        start_time=time.time()
        headers = {
            'authority': 'telegramovies.ml',
            'pragma': 'no-cache',
            'cache-control': 'no-cache',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'x-requested-with': 'XMLHttpRequest',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'referer': 'https://telegramovies.ml/',
            'accept-encoding': 'utf-8',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            
        }

        params = (
            ('term', name),
        )
        
        response = requests.get('https://telegramovies.ml/search', headers=headers, params=params)
        
        response=response.json()
        for items in response:
            if stop_all==1:
                break
           
            if name.decode('utf-8') in items:
               

                if tv_movie=='tv' and ('ע%s פ%s'%(season,episode)).decode('utf-8') not in items and ('עונה %s פרק %s'%(season,episode)).decode('utf-8') not in items:
                    continue
                if tv_movie=='movie' and 'פרק'.decode('utf-8') in items:
                    continue
                params = (
                    ('term', items),
                )
                
                response_ur = requests.get('https://telegramovies.ml/select', headers=headers, params=params).url
                x=requests.get(response_ur,headers=base_header).content
                regex='source src="(.+?)"'
                mm=re.compile(regex).findall(x)[0]
                try_head = requests.get(mm,headers=base_header, stream=True,verify=False,timeout=15)
                f_size2='0'
                if 'Content-Length' in try_head.headers:
                   if int(try_head.headers['Content-Length'])>(1024*1024):
                    f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                
                res=res_q(items)
                if f_size2!='0':
                  s_name='Direct'+' - '+f_size2
                else :
                    s_name='Direct'
                        
                all_links.append((items,mm,s_name,res))
                    
                global_var=all_links
                    

        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links