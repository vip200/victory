# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[70]
def get_tw_source(movie_link,name):
        global global_var,stop_all

        all_links=[]
        if 1:#try:
            html,cook = cloudflare_request(movie_link)
            links = re.compile('data-video="(.+?)"',re.DOTALL).findall(html)
            count = 0 
            for link in links:
                if stop_all==1:
                    break
                if 'vidnode.net' in link or 'vidcloud' in link:
                    if not 'load.php' in link:
                        continue
                    link = 'http:'+link
                
                    headers = {
                        #'Host': 'vidnode.net',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }
                    if 'vidcloud' in link:
                        headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': 'https://ww4.gowatchseries.co/',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                        }
                    page = requests.get(link.replace('load.php','streaming.php'),headers=headers).content
                    try:
                        grab = re.compile("file: '(.+?)',label: '(.+?)'",re.DOTALL).findall(page)
                   
                        grab2=re.compile('file:"(.+?)".+?label: \'(.+?)\'',re.DOTALL).findall(page)
                
                        name1=clean_name(name,1)
                        for end_link,rez in grab2:
                            if stop_all==1:
                                break
                            links_name=end_link.split('/')
                            name1=links_name[len(links_name)-1].replace('.mp4','').replace('.mkv','').replace('.avi','')
                            if clean_name(name,1).replace(" ",".") not in name1:
                                    name1=clean_name(name,1)
                      
                        all_links_in=[]
                        for end_link,rez in (grab+grab2):
                          if stop_all==1:
                            break
                          if end_link not in all_links_in:
                            all_links_in.append(end_link)
                           
                            if '1080' in rez:
                                res = '1080'
                            elif '720' in rez:
                                res= '720'
                            elif '480' in rez:
                                res= '480'
                            elif '360' in rez:
                                res= '360'
                            else: res = ' '
                            if res == ' ':
                                if '1080' in end_link:
                                    res = '1080'
                                elif '720' in end_link:
                                    res= '720'
                                elif '480' in end_link:
                                    res= '480'
                                elif '360' in end_link:
                                    res= '360'
                                else: res = ' '
                            count +=1
                            headers = {
                                'Host': 'cdn1.mload.stream',
                                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
                                'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Referer': 'http://vidnode.net/',
                                
                                'Connection': 'keep-alive',
                                'Pragma': 'no-cache',
                                'Cache-Control': 'no-cache',
                            }
                            head=urllib.urlencode(headers)
                            name1,match_s,res,check=server_data(end_link,name)
                            end_link=end_link+"|"+head
                            
                            
                            
                            
                            if check:
                                all_links.append((name1,end_link,match_s,res))
                                global_var=all_links
                    except Exception as e:
           
                        pass
                        # vid_url = re.compile("sources.+?file: '(.+?)'",re.DOTALL).findall(page)[0]
                        # vid_url = 'http:'+vid_url
                        # #count +=1
                        # self.sources.append({'source': 'GoogleLink','quality': '720p','scraper': self.name,'url': vid_url,'direct': True})
                elif 'openload' in link:
                    try:
                        chk = requests.get(link).content
                        rez = re.compile('"description" content="(.+?)"',re.DOTALL).findall(chk)[0]
                        if '1080' in rez:
                            res='1080p'
                        elif '720' in rez:
                            res='720p'
                        else:
                            res ='DVD'
                    except: res = 'DVD'
                    count +=1
                   
                    name1,match_s,res,check=server_data(link,name)
                    
                    if check :
                        all_links.append((name1,link,match_s,rez))
                        global_var=all_links
                        
                   
                elif 'streamango.com' in link:
                    get_res=requests.get(link).content
                    try:
                        rez = re.compile('{type:"video/mp4".+?height:(.+?),',re.DOTALL).findall(get_res)[0]
                        count +=1
                    
                        name1,match_s,res,check=server_data(link,name)
                        if check:
                            all_links.append((name1,link,match_s,rez))
                            global_var=all_links
                    except:
                        pass
                else:
                    
                    count +=1
                   
                    
                    name1,match_s,res,check=server_data(link,name)
                    
                    if check :
                        all_links.append((name1,link,match_s,res))
                        global_var=all_links
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global stop_all,progress
    User_Agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'
    progress='Start'
    start_time=time.time()
    year=show_original_year
    base_link = domain_s+'ww2.gowatchseries.co'
   
    scrape = (original_title.lower())
    start_url = '%s/search.html?keyword=%s' %(base_link,scrape)

    progress='Cloud'
    html,cook = cloudflare_request(start_url)
    progress='Regex'
    thumbs = re.compile('<ul class="listing items">(.+?)</ul> ',re.DOTALL).findall(html)
    thumb = re.compile('href="(.+?)".+?alt="(.+?)"',re.DOTALL).findall(str(thumbs)) 

    if tv_movie=='movie':
      for link,link_title in thumb:
        if stop_all==1:
                    break
        if clean_name(original_title,1).lower() in clean_name(link_title,1).lower() and show_original_year in link_title:
        
          
            page_link = base_link+link
            progress='Cloud2'
            holdpage,cook = cloudflare_request(page_link,timeout=5)
            progress='Regex2'
            datecheck = re.compile('<span>Release: </span>(.+?)</li>',re.DOTALL).findall(holdpage)[0]
            if year in datecheck:
                movie_link = re.compile('<li class="child_episode".+?href="(.+?)"',re.DOTALL).findall(holdpage)[0]
                movie_link = base_link + movie_link
            
                get_tw_source(movie_link,original_title)
    else:
        count=0
        for link,link_title in thumb:
                progress='Links-'+str(count)
                count+=1
                if stop_all==1:
                    break
                if clean_name(original_title,1).lower() in clean_name(link_title,1).lower():
                    season_chk = '-season-%s' %season
       
                    if season_chk in link:
                        page_link = base_link + link
             
                        progress='Cloud-'+str(count)
                        holdpage,cook = cloudflare_request(page_link,timeout=5)
                        series_links = re.compile('<li class="child_episode".+?href="(.+?)"',re.DOTALL).findall(holdpage)
                        for movie_link in series_links:
                            if stop_all==1:
                                break
                            episode_chk = '-episode-%sBOLLOX' %episode
                            spoof_link = movie_link + 'BOLLOX'
                            if episode_chk in spoof_link:
                                movie_link = base_link + movie_link
                            
                                get_tw_source(movie_link,original_title)
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))