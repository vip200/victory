# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header,get_vidcloud
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[1]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
        search_title=clean_name(original_title,1).replace(' ','-')+'-season-'+season
    else:
        search_title=clean_name(original_title,1).replace(' ','-')
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Origin': 'https://www9.cmovieshd.bz',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }

    params = (
        ('link_web', 'https://www9.cmovieshd.bz/'),
    )
    progress=' requests '
    response = requests.get('https://api.ocloud.stream/cmovieshd//movie/search/'+search_title, headers=headers, params=params).content
    regex='<div class="ml-item">.+?<a href="(.+?)".+?title="(.+?)"'
    progress='Regex'
    m=re.compile(regex,re.DOTALL).findall(response)
    count=0
    for link,title in m:
        progress=' Links - '+str(count)
        count+=1
        add_s=''
        if '(' in title:
            title=title.split('(')[0].strip()
        if title.lower()!=clean_name(original_title,1).lower() and tv_movie=='movie':
            continue
        if tv_movie=='tv':
            logging.warning( (clean_name(original_title,1).lower()+' -Season '+season).lower())
            logging.warning(title.lower().strip())
            if (clean_name(original_title,1).lower()+' -Season '+season).lower().replace(' ','')!=title.lower().strip().replace(' ',''):
                continue
        if tv_movie=='tv':
            add_s='?ep='+episode
        y=requests.get(link+'/watching.html'+add_s,headers=headers).content
        regex='<div class="pa-main anime_muti_link">(.+?)</ul>'
        m2=re.compile(regex,re.DOTALL).findall(y)[0]
        
        regex='data-video="(.+?)"'
        m3=re.compile(regex,re.DOTALL).findall(m2)
        logging.warning(link)
       
        for links in m3:
            progress=' Links2 - '+str(count)
            if 'http' not in links:
                links='https:'+links
            lks=[links]
            logging.warning(lks)
            if 'vidcloud' in links:
                lks,hdr=get_vidcloud(links)
                
            for f_link in lks:
                
                if '.vtt' in f_link:
                    continue
                name2,match_s,res,check=server_data(f_link,original_title)
               
                if check:
                    head=urllib.urlencode(hdr)
                    f_link=f_link+"|"+head
                    all_links.append((name2,f_link,match_s,res))
                    
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links

    
