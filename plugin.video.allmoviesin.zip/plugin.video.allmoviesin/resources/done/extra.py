import requests
import unjuice,time

import urllib2,base64,logging
global global_var,stop_all#global
global_var=[]
global progress
progress=''
type=['movie']
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,cloudflare_request
color=all_colors[21]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    try:
      import resolveurl
    except:
      import resolveurl_temp as resolveurl
    sUrl='http://extramovies.wiki/?s='+(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}

    progress='requests'
    html,cook= cloudflare_request(sUrl)

    progress='Regex'
    match = re.compile('class="thumbnail">.+?href="(.+?)" title="(.+?)".+?class="rdate">(.+?)</span>.+?</article>',re.DOTALL).findall(html) # Regex info on results page
    count=0
    for item_url, name ,release in match:
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
             break
        if stop_all==1:
                break
        release = release.strip()
        if show_original_year == release:
            if show_original_year in release:
                rez = item_url
                if '1080' in rez:
                    res = '1080p'
                elif '720' in rez:
                    res = '720p'
                else: 
                    res = 'DVD'
                progress='requests-'+str(count)
                OPEN = requests.get(item_url,headers=cook[1],cookies=cook[0],timeout=10).content
                
                Regex = re.compile('href="/download.php.+?link=(.+?)(?:&|")',re.DOTALL).findall(OPEN)
                
                count = 0
                for link in Regex:
                    progress='Links2-'+str(count)
                    if stop_all==1:
                        break
                    if stop_all==1:
                        break
                    try:
                        link = base64.b64decode(link)
                    except:pass
                    
                    if not resolveurl.HostedMediaFile(link).valid_url(): 
                        continue
                    
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    
                    if 1:
                        count +=1
                        if 'drive.google.com' in link and 'view' not in link and 'preview' not in link and 'id=' in link:
                            regex='id=(.+?)\&'
                            match=re.compile(regex).findall(link)
                            id=match[0]
                            link='https://drive.google.com/file/d/'+id+'/view'
                        progress='Check-'+str(count)
                        nam1,srv,res,check=server_data(link,original_title)
                        
                        if check:
                          
                          all_links.append((nam1.replace("%20"," "),link,srv,res))
                          global_var=all_links
                        
                        
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links

