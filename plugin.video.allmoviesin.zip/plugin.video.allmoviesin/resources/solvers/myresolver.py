# -*- coding: utf-8 -*-
from open import getMediaLinkForGuest
from open_new import getMediaLinkForGuest_new
from thevideo import getMediaLinkForGuest_thevid,getMediaLinkForGuest_vshare,getMediaLinkForGuest_vidlox,getMediaLinkForGuest_vidup
from vidtodo import VidToDoResolver,__get_vidto
def resolve_req(url):

    headers = {
        'Pragma': 'no-cache',
        'Origin': 'http://reqlinks.net',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': url,
    }
    x=requests.get(url,headers=headers).content
    

    regex='name="_method" value="POST"/>.+?_csrfToken".+?value="(.+?)".+?"ad_form_data" value="(.+?)".+?"_Token\[fields\]".+?value="(.+?)".+?"_Token\[unlocked\]".+?value="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)
    csrtoken,ad_form_data,Token_fields,Token_unlocked=match[0]

    xbmc.sleep(5100)
    cookies = {
        
        'csrfToken': csrtoken,
        
    }

    headers = {
        'Pragma': 'no-cache',
        'Origin': 'http://reqlinks.net',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.79 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': url,
    }

    data = [
      ('_method', 'POST'),
      ('_csrfToken', csrtoken),
      ('ad_form_data', str(ad_form_data.strip())),
      ('_Token[fields]', Token_fields),
      ('_Token[unlocked]', Token_unlocked),
    ]

    response = requests.post('http://reqlinks.net/links/go', headers=headers, cookies=cookies, data=data).json()
    
   
    return (response['url'])

def get_upfile_det(url):
    name=''
  
    html,cook=cloudflare.request(url)
    regex='<title>(.+?)</title>.+?<input type="hidden" value="(.+?)" name="hash">'
    match=re.compile(regex,re.DOTALL).findall(html)

    for name,link in match:
      id=url.split('/')[-1]
      id=id.replace('.html','').replace('.htm','')
      
      playlink='http://down.upfile.co.il/downloadnew/file/%s/%s'%(id,link)
    return name,playlink
def resolve_flashx(url):
    from flashx import __getMediaLinkForGuest
    link=__getMediaLinkForGuest(url)

    return link[1]
def resolve_vidshare(url):
    headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        
    }
    html=requests.get(url,headers=headers).content
    regex='source src="(.+?)"'
    match=re.compile(regex).findall(html)[0]
    return match
    
def resolve_goun(url):
    from jsunpack import unpack
    headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        
    }
    html=requests.get(url,headers=headers).content
    regex="javascript'>(.+?)<"
    match=re.compile(regex).findall(html)
    result=unpack(match[0])
    regex='file: "(.+?)"'
    match=re.compile(regex).findall(result)
    return match[0]
def streamango_decode(encoded, code):
        #from https://github.com/jsergio123/script.module.urlresolver
        _0x59b81a = ""
        k = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
        k = k[::-1]

        count = 0

        for index in range(0, len(encoded) - 1):
            while count <= len(encoded) - 1:
                _0x4a2f3a = k.index(encoded[count])
                count += 1
                _0x29d5bf = k.index(encoded[count])
                count += 1
                _0x3b6833 = k.index(encoded[count])
                count += 1
                _0x426d70 = k.index(encoded[count])
                count += 1

                _0x2e4782 = ((_0x4a2f3a << 2) | (_0x29d5bf >> 4))
                _0x2c0540 = (((_0x29d5bf & 15) << 4) | (_0x3b6833 >> 2))
                _0x5a46ef = ((_0x3b6833 & 3) << 6) | _0x426d70
                _0x2e4782 = _0x2e4782 ^ code

                _0x59b81a = str(_0x59b81a) + chr(_0x2e4782)

                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x2c0540)
                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x5a46ef)

        return _0x59b81a
def resolve_rd(url):
    host = url.split('//')[1].replace('www.','')
    
    debrid = host.split('/')[0].lower()
    
    debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()]
    all_resolve=[]
    for key in debrid_resolvers:
      all_resolve.append(key.name)
    
    if 'Real-Debrid' not in all_resolve and 'MegaDebrid' not in all_resolve:
       
       xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")
   
    if len(debrid_resolvers) == 0:

        debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True,include_universal=False) if 'rapidgator.net' in resolver.domains]

    debrid_resolver = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()][0]
 
    debrid_resolver.login()
    _host, _media_id = debrid_resolver.get_host_and_id(url)

    stream_url = debrid_resolver.get_media_url(_host, _media_id)

    return stream_url
def resolve_streamango(url):
        api_call=False
        headers = {
        'Pragma': 'no-cache',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.9',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        }   

        sHtmlContent= requests.get(url,headers=headers).content
        regex="\"video/mp4\",src:d\('(.+?)',(.+?)\)"
        match=re.compile(regex).findall(sHtmlContent)
        code1,code2=match[0]
        #r1 = re.search("srces\.push\({type:\"video/mp4\",src:d\('([^']+)',(\d+)", sHtmlContent)

        if (match):
            api_call = streamango_decode(code1, int(code2))
            api_call = 'http:' + api_call
       
 
            return api_call
            
def my_resolver(url):
     url=url.strip()
     if '$$$' in url:
       url=url.split('$$$')[0]
     if 'upfile' in url or 'www.upf.co.il' in url:
        name2,url=get_upfile_det(url)
     if 'sratim-il.com' in url:
            regex_t='/(.+?).mp4'
            match_t=re.compile(regex_t).findall(url)
            headers={'Accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                    'Accept-Language':'en-US,en;q=0.5',
                    'Cache-Control':'no-cache',
                    'Connection':'keep-alive',
                    'Host':'server2.sratim-il.com',
                    'Pragma':'no-cache',

                    'Referer':'http://www.sratim-il.cf/newsite/%s/'%match_t[0],
                    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; W…) Gecko/20100101 Firefox/59.0'}
            head=urllib.urlencode(headers)

            url=url+"|"+head
     if 'streamango' in url:
        url=resolve_streamango(url)
        
     if 'vidup' in url:
        url=getMediaLinkForGuest_vidup(url)[1]
     if 'vidlox' in url:
       url=getMediaLinkForGuest_vidlox(url)[1]
    
     if '://vidtod' in url and rd_sources=='false':
       
       url=VidToDoResolver(url)[1]

     if 'thevideo' in url and rd_sources=='false':
        url=getMediaLinkForGuest_thevid(url)[1]

     if 'vshare' in url and rd_sources=='false':
   
        url=getMediaLinkForGuest_vshare(url)[1]
        
       

     if  rd_sources=='true':
       import resolveurl
     elif 'uptobox' not in url and 'vidtod' not in url and 'thevideo' not in url and 'vshare' not in url and 'vidlox' not in url and 'vidup' not in url:
       import resolveurl
     
     if  rd_sources=='true' :
        try:
          url=resolve_rd(url)
        except Exception as e:
          logging.warning(e)
          pass
        #resolvable=resolveurl.HostedMediaFile(url, include_disabled=True,include_universal=True).valid_url()
        resolvable=False
     elif 'streamango' not in url and 'uptobox' not in url and 'vidtod' not in url and 'thevideo' not in url  and 'vshare' not in url and 'vidlox' not in url and 'vidup' not in url and '-Sdarot' not in description:
       resolvable=resolveurl.HostedMediaFile(url).valid_url()
       
       
     else:
       resolvable=False
     if 'googleusercontent' in url:
       resolvable=False
     if ('openload' in url or 'oload.stream' in url)  and rd_sources=='false':
             
        url=getMediaLinkForGuest(url)
        resolvable=False
     if resolvable:
         hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
         link = hmf.resolve()
         return link
     else:
       return url
def decrypt(url):
    from base64 import b64decode
    ''' decrypt the given encrypted code '''
    html=requests.get(url).content
    

    regex="var ysmm = '(.+?)'"
    match=re.compile(regex).findall(html)
    if len(match)>0:
        
        ysmm = match[0]
      
        #ysmm='Y=jMkDyNM3GUUD1MYwzIJWiNYx2UZmmNOkTVcDyMMi2Rh20Yd6HIAT6MLiyN9G0Nd33McTuZdymMljkYZvWU9G3bZpWZV1kLLzmV'
        code=(ysmm.decode('utf-8'))

        zeros, ones = '', ''

        for num, letter in enumerate(code):
            if num % 2 == 0: zeros += code[num]
            else: ones = code[num] + ones

        key = zeros + ones
 
        u=list((key))
 
        m=0
        while m <(len(u)-1):
          if u[m].isnumeric():
              R=m+1
              while R< (len(u)-1): 
                if u[R].isnumeric():
                     
                  S =(int(u[m]) ^ int(u[R]))


                  if ((S) < 10):

                    u[m] = unicode(S)
                  m = R
                  R = len(u)
                R=R+1
          m=m+1
        t3="".join(u)

        key = (t3).decode('base64')

        key=key[(len(t3)-(len(t3)-16)):]
 
        key=key[:((len(key)-16))]
    else:
      from unshort import unshorten
 
     
      unshortened_uri, status = unshorten(url,type='shst')

      if unshortened_uri==url:
        unshortened_uri, status = unshorten(url,type='shst')
      key=unshortened_uri
     
   
    return key
def resolve_uptobox(url):
    import requests

    if 'uptostream' not in url:
        x=requests.get(url).content
        regex='<a href="https://uptostream.com/(.+?)"'
        match=re.compile(regex).findall(x)

      
        url=domain_s+'uptostream.com/'+match[0]
    
    

    cookies = {
        #'__cfduid': 'd0dfe3eedd616e0f275edcea08cdb6e521520582950',
        'video': '55srlypu0c08',
    }

    headers = {
        'Host': 'uptostream.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    response = requests.get(url, headers=headers, cookies=cookies).content
    regex='var sources = (.+?);'
    match=re.compile(regex).findall(response)
    if len(match)==0:
      regex="sources = JSON.parse\('(.+?)'"
      match=re.compile(regex).findall(response)
    links=json.loads(match[0])
    quality=[]
    links2=[]
    for data in links:
      quality.append(data['label'])
      links2.append(data['src'])
    
    ret = xbmcgui.Dialog().select("בחר איכות", quality)
    if ret!=-1:
        f_link=links2[ret]
    else:
      sys.exit()
    return f_link
def get_solved(url):
     if 'letsupload' in url:
         headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://letsupload.co/search.html',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
         }
         regex='https://letsupload.co/(.+?)/'
         m=re.compile(regex).findall(url)[0]
         
         u='https://letsupload.co/plugins/mediaplayer/site/_embed.php?u=%s&w=1920&h=1080'%m
         
         ur2=requests.get(u, headers=headers).content
         regex='file: "(.+?)"'
         match=re.compile(regex).findall(ur2)
         if len (match)==0:
            regex='<embed.+?src="(.+?)"'
            url=re.compile(regex,re.DOTALL).findall(ur2)[0]
         else:
            url=match[0]
         
     if 'vcstream.to' in url:
                ids=url.split('/')
                id=ids[len(ids)-1]
                
                yy=requests.get('https://vcstream.to/player?fid=%s&page=embed'%id).json()
            
                if 'player.updateSrc' in yy['html']:
                  regex='player.updateSrc\((.+?)\)'
                  match=json.loads(re.compile(regex).findall(yy['html'])[0])
                elif 'sources' in yy['html']:
                  regex='sources:(.+?)]'
                  match=json.loads(re.compile(regex).findall(yy['html'])[0]+']')
                all_q=[]
                all_links=[]
                for items in match:
                  all_q.append(items['name']+' - '+items['label'])
                  all_links.append(items['src'])
                if len (all_q)==1:
                      url=all_links[0]
                      name=all_q[0].split(' - ')[0]
                else:
                    ret=xbmcgui.Dialog().select("בחר סוג", all_q)
                    if ret==-1:
                        sys.exit()
                    else:
                      url=all_links[ret]
                      name=all_q[ret].split(' - ')[0]
                      
     if '-REQ-' in description:
       url=resolve_req(url)
       
     if '-Sdarot' in description:
       url_data=json.loads(url)
    
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
     
     if '-SN-' in description or '-Sno-' in description:
        url=decrypt(url)
     if 'flashx' in url:
        url=resolve_flashx(url)
     if 'streamango' in url:
        url=resolve_streamango(url)
        
     if 'vidup' in url:
        url=getMediaLinkForGuest_vidup(url)[1]
     if 'vidlox' in url:
       url=getMediaLinkForGuest_vidlox(url)[1]
     if 'movix' in url:
        url=resolve_movix(url)
     if '://vidtod' in url and rd_sources=='false':
       
       url=VidToDoResolver(url)[1]
     if '://vidto.' in url and rd_sources=='false':

        if 'embed' in url:
          regex='vidto.me/embed-(.+?)-'
          id=re.compile(regex).findall(url)[0]
          url='http://vidto.me/%s.html'%id
        url=__get_vidto(url)[1]

     if 'thevideo' in url and rd_sources=='false':
        url=getMediaLinkForGuest_thevid(url)[1]

     if 'vshare' in url and rd_sources=='false':
        url=resolve_vidshare(url)
        
        #url=getMediaLinkForGuest_vshare(url)[1]
        
       
    
     if  rd_sources=='true':
       import resolveurl
     elif 'ssd.putvid.com' not in url and  'uptobox' not in url and 'vidtod' not in url and 'thevideo' not in url and 'vshare' not in url and 'vidlox' not in url and 'vidup' not in url and '-Sdarot' not in description:
       import resolveurl
     url3=url
     if 'pron.tv' in url:
      
        url3=get_allu_links(url)

     if url3!=None:
           url=url3
     
     if  rd_sources=='true' and '-Sdarot' not in description and 'upto' not in url:
        try:
          
          url=resolve_rd(url)
        except Exception as e:
          logging.warning(e)
          pass
        #resolvable=resolveurl.HostedMediaFile(url, include_disabled=True,include_universal=True).valid_url()
        resolvable=False
     elif 'ssd.putvid.com' not in url and 'streamango' not in url and 'uptobox' not in url and 'vidtod' not in url and 'thevideo' not in url  and 'vshare' not in url and 'vidlox' not in url and 'vidup' not in url and '-Sdarot' not in description:
       resolvable=resolveurl.HostedMediaFile(url).valid_url()
       
       
     else:
       resolvable=False
     if 'googleusercontent' in url:
       resolvable=False
     
     if  rd_sources=='true':
        universal=True
     else:
        universal=False
     if 'viooz.fun' in url:
        headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
       
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        x=requests.get(url,headers=headers).content
        regex='getinfo\("(.+?)"'
        match=re.compile(regex).findall(x)
       
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
            'Referer': url,
            'Origin': 'https://viooz.fun',
        }
        y=requests.get('https://hdv.fun/1-a.php?a='+match[0],headers=headers).json()
      
       
        
        path=y['webseed'].split('u=')[0]+'u='+urllib.quote_plus(y['webseed'].split('u=')[1])
        url='https://torrent.hdv.fun/m3u8.php?i=%s&u=%s'%(y['id'],path)
     if 'ganol.ru' in url:
        
        from jsunpack import unpack
        headers = {
        #'Host': 'ganool.im',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        #'Referer': 'https://ganool.im/?s=black+panther',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        x=requests.get(url,headers=headers).content
        regex='IFRAME.+?SRC="(.+?)"'
        match=re.compile(regex,re.IGNORECASE).findall(x)
        names_urls=[]
        urls=[]
        resolvea=[]
        for item in match:
          if 'blazefile.co' in item:
             try:
                 
                 y=requests.get(item).content
                 regex="type='text/javascript'>(.+?)<"
                 match_in=re.compile(regex,re.DOTALL).findall(y)
                 temp=unpack(match_in[0])
           
                 regex_link='file:"(.+?)"'
                 match_link=re.compile(regex_link).findall(temp)[0]
                 regex_n='//(.+?)/'
                 match_n=re.compile(regex_n).findall(match_link)[0]
                 names_urls.append(match_n)
                 urls.append(match_link)
                 resolvea.append(False)
             except:
              pass
          elif 'youtube' not in item:
             
             regex_n='//(.+?)/'
             match_n=re.compile(regex_n).findall(item)[0]
             
             name1,match_s,res,check=server_data(item,match_n)
             if check:
               names_urls.append(match_n)
               resolvea.append(True)
               urls.append(item)
        if len(urls)>1:
            ret=xbmcgui.Dialog().select("בחר שרת", names_urls)
            if ret==-1:
                sys.exit()
            else:
               url=urls[ret]
               resolvable=resolvea[ret]
        else:
           if len(urls)==0:
            xbmcgui.Dialog().ok('Error occurred','אין לינקים תקינים')
            sys.exit()
           else:
            url=urls[0]

            
            
            
     if  resolvable:
           regex='//(.+?)/'
           match=re.compile(regex).findall(url)
           if len (match)>0:
             src=match[0]
           else:
             src=url
           src=src.lower().replace("openload","vumoo").replace("thevideo","vumoo.li").replace("Openload","vumoo")
           
           xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'Source Resolving:'+src)).encode('utf-8'))
           Domain=Addon.getSetting("server")
           En_Domain=Addon.getSetting("serveroption")
           if '-ftp-' not in description:
               x=requests.get(url,timeout=20)
                   
               if x.status_code!=200:
                
                   error_link=x.status_code
               else:
                 yz=check_link(x)
                 if yz==False:
                   error_link='File Not Found'
           if error_link!=0:
             xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'Fault:'+str(error_link))).encode('utf-8'))
       
           if ('openload' in url or 'oload.stream' in url or 'oload.win' in url) and error_link==0 and rd_sources=='false':
              if Addon.getSetting("vummo2")=='1':
              
                x=requests.get('https://www.saveitoffline.com/process/?url='+urllib.quote_plus(url)).json()
                
                if 'urls' in x:
                 if len(x['urls'])>0:
                    link=x['urls'][0]['id']
              elif Addon.getSetting("vummo2")=='0':
               xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'Vimoo Source')).encode('utf-8'))
               streamurl=getMediaLinkForGuest(url)
             
               link=streamurl
               xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', '[COLOR lighgreen]Vimoo OK[/COLOR]')).encode('utf-8'))
              else:
               xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'Vimoo Source')).encode('utf-8'))
               streamurl=getMediaLinkForGuest_new(url)
             
               link=streamurl
               xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', '[COLOR lighgreen]Vimoo OK[/COLOR]')).encode('utf-8'))

           
       
           else:
             pass_openload='ok'
             
             try:
               
               x=requests.get(url,timeout=20)
               yz=True
               if x.status_code!=200 :
                 
                   error_link=x.status_code
               else:
                 yz=check_link(x)
          
               if yz==False:
                   error_link='File Not Found'
  
               if  rd_sources=='true':
                 
                 hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
                 link = hmf.resolve()
               else:
               
                 link =resolveurl.resolve(url)
         
             except Exception as e:
               logging.warning(e)
               link=url
               pass
           if pass_openload=='fail':
             
             try:
              
               x=requests.get(url,timeout=20)
               
               if x.status_code!=200:
                
                   error_link=x.status_code
               else:
                 yz=check_link(x)
                 if yz==False:
                   error_link='File Not Found'
               link =resolveurl.resolve(url)
               
             except:
               link=url
               pass
             
     else:
           xbmc.executebuiltin((u'Notification(%s,%s)' % ('EverySource', 'Source Resolving:Direct')).encode('utf-8'))
           link=url
     if '-Sdarot' not in description and 'ftp://' not in link and '-MK-' not in description:
           link=link.replace(" ","").replace("\n","").replace("\r","").replace("\t","")
     elif 'ftp://' in link:
     
          link=urllib.unquote(link)

          
          
     if '-4K' in description:
              xx=requests.get(url).content
              regex='iframe .+? src="(.+?)"'
              match2=re.compile(regex).findall(xx)
              link_f=match2[0]
            
              link =resolveurl.resolve(link_f)
      
     if '-sdarot' in description:
  
       error_link=0
     if 'uptobox' in url:# and rd_sources=='false':
       link=resolve_uptobox(url)
       error_link=0
     if 'thevideo' in url:
       error_link=0
     if 'upfile' in link or 'www.upf.co.il' in url:
        name2,link=get_upfile_det(url)
        error_link=0
    return link,error_link