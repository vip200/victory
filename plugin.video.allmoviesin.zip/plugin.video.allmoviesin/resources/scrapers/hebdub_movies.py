# -*- coding: utf-8 -*-
import cache
global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6
import  threading,xbmcplugin,sys,os,re,requests,logging,json,xbmcaddon
dir_path = os.path.dirname(os.path.realpath(__file__))

mypath=os.path.join(dir_path,'..\done')
sys.path.append(mypath)
Addon = xbmcaddon.Addon()
from general import replaceHTMLCodes
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
    
from addall import addLink
import xbmc
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
user_dataDir_pre = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
from pen_addons import download_file,unzip,gdecom

if KODI_VERSION>=17:
 
  domain_s='https://'
elif KODI_VERSION<17:
  domain_s='http://'
all_dub=[]
all_dub2=[]
all_dub3=[]
all_dub4=[]
all_dub5=[]
all_dub6=[]
all_dub7=[]

all_dub8=[]
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
user_dataDir=os.path.join(user_dataDir_pre,'cache_f','ghost')

if not os.path.exists(user_dataDir):
    os.makedirs(user_dataDir)
user_dataDir2=os.path.join(user_dataDir_pre,'cache_f','avegner')

if not os.path.exists(user_dataDir2):
    os.makedirs(user_dataDir2)
user_dataDir3=os.path.join(user_dataDir_pre,'cache_f','orn')


if not os.path.exists(user_dataDir3):
    os.makedirs(user_dataDir3)
    
user_dataDir4=os.path.join(user_dataDir_pre,'cache_f','dragon')


if not os.path.exists(user_dataDir4):
    os.makedirs(user_dataDir4)
    
user_dataDir5=os.path.join(user_dataDir_pre,'cache_f','fhd')


if not os.path.exists(user_dataDir5):
    os.makedirs(user_dataDir5)
    
user_dataDir7=os.path.join(user_dataDir_pre,'cache_f','hp')


if not os.path.exists(user_dataDir7):
    os.makedirs(user_dataDir7)
user_dataDir8=os.path.join(user_dataDir_pre,'cache_f','ghk')


if not os.path.exists(user_dataDir8):
    os.makedirs(user_dataDir8)
def renew_data(path,l_list):


    download_file(l_list,path)

    unzip(os.path.join(path, "fixed_list.txt"),path)

    return 'ok'

def fix_data(data):
    return data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace("\n"," ").replace("\r"," ").replace("\t"," ")
def get_dub_movies():
    global all_dub
    l_list='https://github.com/oren2706/Multimedialist/blob/master/hebdub%20list%20(VER_5).txt?raw=true'
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir3,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir3)

        unzip(os.path.join(user_dataDir3, "fixed_list.txt"),user_dataDir3)

    else:

        all_img=cache.get(renew_data,1,user_dataDir3,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('סרטים מדובבים',' ','')")
    match = dbcur.fetchall()
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
            
        all_dub.append((name,f_link,5,'[[ON]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
def get_dub_movies2():
    global all_dub2
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    #l_list='https://files.fm/pa/moshep1977/upload/1.txt'
    l_list=Addon.getSetting("ghaddr").decode('base64')
    
    cacheFile=os.path.join(user_dataDir,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir)

        unzip(os.path.join(user_dataDir, "fixed_list.txt"),user_dataDir)

    else:

        all_img=cache.get(renew_data,1,user_dataDir,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where  REPLACE(father,' ','') like REPLACE('%[B][COLOR orange]ילדים[/B][/COLOR][B]סרטים מדובבים לילדים[/B]%',' ','') or REPLACE(father,' ','') like REPLACE('%[B][COLOR orange]ילדים[/B][/COLOR][B]סרטים מדובבים 1[/B]%',' ','')  or REPLACE(father,' ','') like REPLACE('%[B][COLOR orange]ילדים[/B][/COLOR][B]סרטים מדובבים 2[/B]%',' ','') and type='item'")
    match = dbcur.fetchall()
 
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub2.append((name,f_link,5,'[[GH]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
    
def get_dub_movies3():
    global all_dub3
    import cache
    l_list='https://github.com/shimonar/The-Avenger/raw/master/%D7%94%D7%A0%D7%95%D7%A7%D7%9D%20%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F.txt'
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    
   
    cacheFile=os.path.join(user_dataDir2,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir2)

        unzip(os.path.join(user_dataDir2, "fixed_list.txt"),user_dataDir2)

    else:

        all_img=cache.get(renew_data,1,user_dataDir2,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('[B][COLOR deepskyblue] הנוקם הראשון סרטים בתרגום מובנה [/COLOR][/B][B][COLOR deepskyblue] עולם הילדים [/COLOR][/B]מדובבים',' ','') or REPLACE(father,' ','')=REPLACE('[B][COLOR deepskyblue] הנוקם הראשון סרטים בתרגום מובנה [/COLOR][/B][B][COLOR deepskyblue] עולם הילדים [/COLOR][/B]מדובבים HD',' ','')")
    
       
        
    match = dbcur.fetchall()
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub3.append((name,f_link,5,'[[AV]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
def get_dub_movies4():
    global all_dub4
 
    
    import cache
    l_list='https://github.com/hpotter1234/matrix/raw/master/dubbed.txt'
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    
   
    cacheFile=os.path.join(user_dataDir7,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir7)

        unzip(os.path.join(user_dataDir7, "fixed_list.txt"),user_dataDir7)

    else:

        all_img=cache.get(renew_data,1,user_dataDir7,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where type='item'")
    
       
        
    match = dbcur.fetchall()
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub4.append((name,f_link,5,'[[HP]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
def get_dub_movies5():
    global all_dub5
 
    
    import cache
    l_list='https://raw.githubusercontent.com/moshep15/back/master/onlykids.txt'
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    
   
    cacheFile=os.path.join(user_dataDir8,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir8)

        unzip(os.path.join(user_dataDir8, "fixed_list.txt"),user_dataDir8)

    else:

        all_img=cache.get(renew_data,1,user_dataDir8,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable   where father like '%מדובבים%' and type='item'")
    
       
        
    match = dbcur.fetchall()
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub5.append((name,f_link,5,'[[GHK]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
def get_dub_movies5_dead():
        global all_dub5
        all_dub5=[]
        url=domain_s+'raw.githubusercontent.com/Jksp/jksp.repo/master/db/HebDub.json'
        html=requests.get(url).json()
        
        for item in html['movies']:
            
             
             
               name1=item
               link="https://www.rapidvideo.com/v/%s" % html['movies'][item]['video_id']
               icon=html['movies'][item]['thumb']
               image=html['movies'][item]['fanart']
               plot=html['movies'][item]['video_info']['plot']
               data={}
               
               data['title']=name1
         
               data['poster']=image
               data['plot']=plot
               data['genre']=html['movies'][item]['video_info']['genre']
               data['year']=html['movies'][item]['video_info']['year']
               
               #addLink(name1,link,5,False,icon,image,plot,video_info=data)
               all_dub5.append((name1,link,5,'[[JK]]',icon,image,plot,json.dumps(data)))
def get_dub_movies6():
    global all_dub6
    import urllib
    all_dub6=[]
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'hebdub.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM hebdub")
    match = dbcur.fetchall()

    for name,link,img,plot,cat in match:
            data={}
            name=html_decode(name.decode('utf8')).decode('utf8')
            #name=replaceHTMLCodes(name)
            plot=html_decode(plot.decode('utf8')).decode('utf8')
            data['title']=name.replace('*מדובב לעברית*','').strip()

            data['poster']=img
            data['plot']=plot.replace('\n','').replace('\r','').replace('\t','').replace('"',"'").strip()


            #addLink(name1,link,5,False,icon,image,plot,video_info=data)
            all_dub6.append((name.replace('*מדובב לעברית*','').strip(),urllib.unquote_plus(link),5,'[[OS]]',img.encode('utf8'),img.encode('utf8'),plot.replace('\n','').replace('\r','').replace('\t','').strip(),json.dumps(data)))
    logging.warning('Done 6')
def get_dub_movies9():
    global all_dub9
    import urllib
    all_dub9=[]
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'se_hebdub.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM hebdub")
    match = dbcur.fetchall()

    for name,link,img,plot,cat in match:
            data={}
            name=html_decode(name.decode('utf8')).decode('utf8')
            #name=replaceHTMLCodes(name)
            plot=html_decode(plot.decode('utf8')).decode('utf8')
            data['title']=name.replace('*מדובב לעברית*','').strip()

            data['poster']=img
            data['plot']=plot.replace('\n','').replace('\r','').replace('\t','').replace('"',"'").strip()


            #addLink(name1,link,5,False,icon,image,plot,video_info=data)
            all_dub9.append((name.replace('*מדובב לעברית*','').strip(),urllib.unquote_plus(link),5,'[[SE]]',img.encode('utf8'),img.encode('utf8'),plot.replace('\n','').replace('\r','').replace('\t','').strip(),json.dumps(data)))
    logging.warning('Done 9')

def get_dub_movies7():
    global all_dub7
    if Addon.getSetting("unfilter_test") !='1122':
        return []
    l_list='https://github.com/drmpon/drmpon/raw/master/333.txt'
    logging.warning('Start 7')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
   
   
    cacheFile=os.path.join(user_dataDir4,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir4)

        unzip(os.path.join(user_dataDir4, "fixed_list.txt"),user_dataDir4)

    else:

        all_img=cache.get(renew_data,1,user_dataDir4,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('[B][COLOR   aqua] ילדים [/COLOR][/B][B][COLOR   aqua] סרטים לילדים   [/COLOR][/B][B][COLOR   aqua] #סרטים מדובבים#   [/COLOR][/B]',' ','')")
    match = dbcur.fetchall()
    logging.warning('Dragon Found:'+str(len(match)))
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
       
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass

    
            
        all_dub7.append((name,f_link,5,'[[Dr]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
def get_dub_movies8():
    global all_dub8
    import cache
    logging.warning('Source 8 Start:')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    logging.warning('Source 8 Start1:')
    #l_list='https://files.fm/pa/moshep1977/upload/1.txt'
    l_list='https://github.com/hpotter1234/new/raw/master/dubbed%20movies%20update.txt'
    cacheFile=os.path.join(user_dataDir5,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir5)

        unzip(os.path.join(user_dataDir5, "fixed_list.txt"),user_dataDir5)

    else:

        all_img=cache.get(renew_data,1,user_dataDir5,l_list, table='posters')
    
    logging.warning('Source 8 Start2:')


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.execute("SELECT * FROM MyTable where  REPLACE(father,' ','') like REPLACE('פוטר מדובביםמדובביםמדובבים',' ','') or  REPLACE(father,' ','') like REPLACE('פוטר מדובביםמדובביםמדובבים HD',' ','') and type='item'")
        match = dbcur.fetchall()
        logging.warning('Source 8 :'+str(len(match)))
    except Exception as e:
        logging.warning(e)
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
        all_dub8.append((name,f_link,5,'[[FH]]',icon,fanart,plot,data.replace("OriginalTitle","originaltitle")))
    
def get_background_data():
    global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub7,all_dub6,all_dub8,all_dub9
    while 1:
        if  xbmc.Player().isPlaying() :
            if  xbmc.Player().getTime()>10:
                break
        xbmc.sleep(100)
    addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    
    logging.warning('Waiting for play')
    
    
    logging.warning('Done Waiting')
    thread=[]
    
    thread.append(Thread(get_dub_movies))
    thread.append(Thread(get_dub_movies2))
    thread.append(Thread(get_dub_movies3))
    thread.append(Thread(get_dub_movies4))
    thread.append(Thread(get_dub_movies5))
    thread.append(Thread(get_dub_movies6))
    
    thread.append(Thread(get_dub_movies7))
    thread.append(Thread(get_dub_movies8))
    thread.append(Thread(get_dub_movies9))
    for td in thread:
          td.start()
    
    while 1:

    
        for threads in thread:
       
            still_alive=0
            for yy in range(0,len(thread)):
                    if thread[yy].is_alive():
                      
                      still_alive=1
            xbmc.sleep(300)
        if still_alive==0:
          break
    logging.warning('all_dub:'+str(len(all_dub)))
    logging.warning('all_dub2:'+str(len(all_dub2)))
    logging.warning('all_dub3:'+str(len(all_dub3)))
    logging.warning('all_dub4:'+str(len(all_dub4)))
    logging.warning('all_dub5:'+str(len(all_dub5)))
    logging.warning('all_dub6:'+str(len(all_dub6)))
    logging.warning('all_dub7:'+str(len(all_dub7)))
    logging.warning('all_dub8:'+str(len(all_dub8)))
    logging.warning('all_dub9:'+str(len(all_dub9)))
    all_data_tog=all_dub+all_dub2+all_dub3+all_dub4+all_dub5+all_dub6+all_dub7+all_dub8+all_dub9
    '''
    for name1,link,con1,origin,icon,image,plot,data in all_data_tog:
    
        dbcur.execute("SELECT * FROM kids_movie where name='%s'"%name1)
        match = dbcur.fetchall()
        if match==None:
            dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?,?,?)" % 'newones', (name1.decode('utf8'),link.decode('utf8'),con1,origin.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),data.decode('utf8')))
    '''
    dbcur.execute("DELETE FROM kids_movie")
    for name1,link,con1,origin,icon,image,plot,data in all_data_tog:
       dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?,?,?)" % 'kids_movie', (name1.decode('utf8'),link.decode('utf8'),con1,origin.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),data.decode('utf8')))
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    
    logging.warning('Done Update')
def html_decode(s):
   
    """
    Returns the ASCII decoded version of the given HTML string. This does
    NOT remove normal HTML tags like <p>.
    """
    htmlCodes = (
            ("'", '&#39;'),
            ("'", '&#039;'),
            ('"', '&quot;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('-','&#8211;'),
            ('...','&#8230;'),
            ('&', '&amp;')
        )
    for code in htmlCodes:
        s = s.replace(code[1], code[0])
    return s
def get_background_data_tr():
        thread=[]
        thread.append(Thread(get_background_data))
        thread[0].start()
        return 'OK'
def get_dub(page,search_entered=''):
        global all_dub,all_dub2,all_dub3,all_dub4,all_dub5
        import xbmcgui
       
        if Addon.getSetting("kids_dp")=='true':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','טוען', '','')
            dp.update(0, 'אנא המתן','טוען', '' )
  
        
    
       
        #get_background_data()
        addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
        tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
        tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
        dbcon = database.connect(tmdb_cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
        dbcon.commit()
        dbcur.execute("SELECT * FROM kids_movie")

        match = dbcur.fetchall()

        all_links={}
        all_names=[]
        xx=0
        for name1,link,con1,origin,icon,image,plot,data in match:
          if 'rapidv' in link:
            continue
          if Addon.getSetting("kids_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף', name1 )
              xx+=1
          name1=name1.decode('utf8').strip().replace('*מדובב*','').replace('*','').replace('-',' ')
          fault_data=0
          
          dd=''
          
          try:
            name1=json.loads(data)['title'].replace('-',' ')
            data2=json.loads(data)
            if 'dateadded' in data2:
                dd=data2['dateadded']
          except:
            try:
             
             data=data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace(': """",',': "" "",').replace(': """"}',': "" ""}').replace(': "",',': " ",').replace(': ""}',': " "}').replace('""','"').replace('\n','').replace('\r','')
             #name1=json.loads(data)['title'].replace('-',' ')
             
             data2=json.loads(data)
             if 'dateadded' in data2:
                dd=data2['dateadded']
             #dd=json.loads(data)['dateadded']
            except Exception as e:
             #logging.warning('Error in dub2:'+str(e))
             
             fault_data=1
             pass
          
          if name1 not in all_names:
             try:
                data2['plot']=origin.replace('[','').replace(']','')+'\n[COLOR lightblue]'+dd+'[/COLOR]\n'+data2['plot']+'-HebDub-'
                data=json.dumps(data2)
             except Exception as e:
                logging.warning('Error Hebdub:'+str(e))
                pass
             all_names.append(name1)
             all_links[name1]={}
             all_links[name1]['icon']=icon
             all_links[name1]['image']=image
             all_links[name1]['plot']=plot
             all_links[name1]['data']=data
             all_links[name1]['link']=origin+link
             all_links[name1]['origin']=origin.replace('[','').replace(']','')
          else:
               if link not in all_links[name1]['link']:
                 all_links[name1]['origin']=all_links[name1]['origin']+','+origin.replace('[','').replace(']','')
                 try:
                    data2['plot']=all_links[name1]['origin']+'\n[COLOR lightblue]'+dd+'[/COLOR]\n'+data2['plot']+'-HebDub-'
                    data=json.dumps(data2)
                    all_links[name1]['data']=data
                 except Exception as e:
                    logging.warning('Error Hebdub:'+str(e))
                    pass
                 if '$$$' in link:
                      links=link.split('$$$')
                      for link in links:
                        all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link
                 else:
                   all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link
        
        xx=0
        for items in all_links:
            if Addon.getSetting("kids_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(all_links))) ), 'אנא המתן','שלב 2', items )
              xx+=1
            
            link=all_links[items]['link']
            icon=all_links[items]['icon']
            image=all_links[items]['image']
            plot=all_links[items]['plot']+'-HebDub-'
            data=all_links[items]['data']
            
            if search_entered=='':
            
              if fault_data==1:
                logging.warning('Fault:')
                data={}
              
              try:
                aa=json.loads(data)['title'].replace('-',' ')
              except:
                data={}
              addLink(items,link,5,False,icon,image,plot+'-HebDub-',video_info=data,dont_earse=True)
            else:
              if search_entered in items  :
                addLink(items,link,5,False,icon,image,plot+'-HebDub-',video_info=data,dont_earse=True)
        if Addon.getSetting("kids_dp")=='true':
              dp.update(100, 'אנא המתן','סיימתי', ' ' )
              dp.close()
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        dbcur.close()
        dbcon.close()
        all_img=cache.get(get_background_data_tr,24, table='posters')

        









        