import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.dragonFRD/?site=cGui&function=viewInfo)", True)
