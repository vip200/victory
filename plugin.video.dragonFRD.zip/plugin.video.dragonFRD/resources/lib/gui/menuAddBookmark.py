import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.dragonFRD/?site=cFav&function=setBookmark)", True)
