# -*- coding: utf-8 -*-
import xbmcgui,xbmcaddon,time
import xbmcvfs
__addon__ = xbmcaddon.Addon()
Addon = xbmcaddon.Addon()

list_url='http://ngarba.xyz/adds/AKA47/AA.txt'

time_data=[]
import xbmcaddon,os,xbmc,urllib,re,xbmcplugin,sys,logging

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
from resources.modules import public
addNolink=public.addNolink
addDir3=public.addDir3
addLink=public.addLink
lang=public.lang
from  resources.modules import cache
import threading,json
global all_jen_links
global from_seek
sort_by_episode=False
from_seek=False
all_jen_links=[]

play_status_rd_ext=''
break_window_rd=False
break_window=False
play_status=''
infoDialog_counter_close=False
all_other_sources_uni={}
aa_results={}
avg_f=''
stop_cpu=False
cores_use=''
COLOR2='yellow'
COLOR1='white'

ADDONTITLE='Dragon FRD'
DIALOG         = xbmcgui.Dialog()
dir_path = os.path.dirname(os.path.realpath(__file__))
dra=os.path.join(dir_path,'icon.png')
tvdb_results=[]
done1=0
done1_1=0
wait_for_subs=''
if KODI_VERSION>18:
    
    class Thread (threading.Thread):
       def __init__(self, target, *args):
        super().__init__(target=target, args=args)
       def run(self, *args):
          
          self._target(*self._args)
          return 0
else:
   
    class Thread(threading.Thread):
        def __init__(self, target, *args):
           
            self._target = target
            self._args = args
            
            
            threading.Thread.__init__(self)
            
        def run(self):
            self._target(*self._args)
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
    from urlparse import parse_qsl
else:
    import xbmcvfs,urllib,urllib.parse
    from urllib.parse import parse_qsl
    xbmc_tranlate_path=xbmcvfs.translatePath
home_path =xbmc .translatePath ("special://home/addons/")#line:13
__plugin__ =Addon .getAddonInfo ('path').replace (home_path ,'')
from resources.modules import log
addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))
user_dataDir = xbmc_tranlate_path(Addon.getAddonInfo("profile"))
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
else:
    import xbmcvfs,urllib,urllib.parse
    xbmc_tranlate_path=xbmcvfs.translatePath
if KODI_VERSION<=18:
    que=urllib.quote_plus

else:
    que=urllib.parse.quote_plus

if KODI_VERSION<=18:
    unque=urllib.unquote_plus
    url_encode=urllib.urlencode
    unque_n=urllib.unquote
else:
    unque=urllib.parse.unquote_plus
    url_encode=urllib.parse.urlencode
    unque_n=urllib.parse.unquote
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
if os.path.exists(os.path.join(addonPath,'resources','data','accounts.db')):
    jdata_file=os.path.join(addonPath,'resources','data','accounts.db')
else:
    jdata_file=os.path.join(addonPath,'resources','data','accounts.cfg')
names={'01377831245698351686':'סדרות',
       '03795292767349703669': 'סרטים',
       '07544211567429109729':'סדרות 2'}
icons={'01377831245698351686':'https://img.utdstc.com/icons/turkish-live-tv-android.png:225',
       '03795292767349703669':'http://img.freeflagicons.com/thumb/white_movie_icon/turkey/turkey_640.png',
       '07544211567429109729':'https://cdn.smehost.net/dailyrindblogcom-orchardprod/wp-content/uploads/2016/12/Turkey_TV_AdobeStock.jpeg'}
fans={'01377831245698351686':'https://lh3.googleusercontent.com/EptRQzLFvgbplw06pxQzRWqaNiP8NfGM_otuqr_zY-9ZE3hpnV8eQ-CYwFedEMtE53A',
       '03795292767349703669':'https://acenews.pk/wp-content/uploads/2020/03/First-Turkish-Movie-to-Rele.jpg',
       '07544211567429109729':'https://www.conexioconsulting.com/wp-content/uploads/2019/04/TURKISH-TV-SERIES-IN-ISRAEL.jpg'}
def LogNotify(title, message, times=2000, icon=dra,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def addDir4(name,url,mode,iconimage,fanart,description,fid='root',ct_date=''):
        u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)+"&iconimage="+que(iconimage)+"&fanart="+que(fanart)+"&description="+que(description)+'&fid='+fid
        ok=True
        menu_items=[]
        menu_items.append(('[I]Set view type[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=167')%(sys.argv[0])))
        try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description,'date':ct_date } )
        liz.setProperty( "Fanart_Image", fanart )
        liz.addContextMenuItems(menu_items, replaceItems=False)
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink2( name, url,mode, iconimage,fanart,description,fid=' ',ct_date='',pre_data='',all_w={}):

          u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+(name)+"&fid="+str(fid)+"&description="+(description)+"&pre_data="+pre_data
 

          
          menu_items=[]
          menu_items.append(('[I]Set view type[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=167')%(sys.argv[0])))
          
          #u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)
          try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
          except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
          liz.addContextMenuItems(menu_items, replaceItems=False)
          liz.setInfo(type="Video", infoLabels={ "Title": unque_n( name), "Plot": description,'date':ct_date   })
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
         
          if name in all_w:
              
              liz.setProperty('ResumeTime', all_w[name]['seek_time'])
              liz.setProperty('TotalTime', all_w[name]['total_time'])
              
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=False)

def download_db(url,nm,extract=False,headers={}):
   try:
    file=os.path.join(user_dataDir,nm)
    if os.path.exists(file):
        os.remove(file)
    import ssl

    ssl._create_default_https_context = ssl._create_unverified_context
    try:
        from urllib.request import Request, urlopen  # Python 3
    except ImportError:
        from urllib2 import Request, urlopen  # Python 2

    req = Request(url)
    if headers!={}:
        for key in headers:
            req.add_header(key, headers[key])
    response = urlopen(req)
    
    
    CHUNK = 16 * 1024
    file=os.path.join(user_dataDir,nm)
    with open(file, 'wb') as f:
        while True:
            chunk = response.read(CHUNK)
            if not chunk:
                break
            f.write(chunk)
    
    if extract:
        log.warning('Extract:')
        try:
            
            from resources.modules.zfile_18 import ZipFile
        except:
            from zipfile import ZipFile
        xbmc.sleep(500)
        try:
            with contextlib.closing(ZipFile(file , "r")) as z:
                z.extractall(user_dataDir)
        except:
            with ZipFile(file, 'r') as zip_ref:
                zip_ref.extractall(user_dataDir)
        log.warning('Done Extract:'+user_dataDir)
        # xbmc.executebuiltin("ReloadSkin()")
    return 'ok'
   except Exception as e:
    # xbmc.executebuiltin((u'Notification(%s,%s)' % (Addon.getAddonInfo('name'),  "בעיה במאסטר")))
    log.warning('ExtractFault:'+str(e))

    return 'Fault'

def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass
def clean_data(data):

    try:
        a=data.replace ('	','').replace ("\\"," ").replace (': """",',': "" "",').replace (': """"}',': "" ""}').replace (': "",',': " ",').replace (': ""}',': " "}').replace ('""','"').replace ('\n','').replace ('\r','').replace ("OriginalTitle","Originaltitle").replace ('%27',"'")
        a=json.loads(a)
    except:
        log.warning(data.replace ('[',' ').replace (']',' ').replace ('	','').replace ("\\"," ").replace (': """",',': "" "",').replace (': """"}',': "" ""}').replace (': "",',': " ",').replace (': ""}',': " "}').replace ('""','"').replace ('\n','').replace ('\r','').replace ("OriginalTitle","Originaltitle").replace ('%27',"'"))
        a={}
    
    return a
def crypt(source,key):
    from itertools import cycle
    result=''
    temp=cycle(key)
    for ch in source:
        result=result+chr(ord(ch)^ord(next(temp)))
    return result
def master_addon(url,iconimage,o_fanart,heb_name,type_search,page,o_plot):
    global sort_by_episode
    o_url=url
    progress_master=Addon.getSetting('progress_master')=='true'
    remove_keys=["heb title","icon","imdb","poster","studios","tmdb"]
    try:
        page=int(page)
    except:
        page=0
    if page==0:
        added_index=0
    else:
        added_index=1
    
    if progress_master:
        dp = xbmcgui . DialogProgress ( )
        if KODI_VERSION>18:
            dp.create('Please wait','Downloading DB...')
            dp.update(0, 'Please wait'+'\n'+'Downloading DB...'+'\n'+ '' )
        else:
            dp.create('Please wait','Downloading DB...', '','')
            dp.update(0, 'Please wait','Downloading DB...', '' )

    file=os.path.join(user_dataDir,'master.db')
    refresh_rate=int(Addon.getSetting('refresh_rate'))
    html=cache.get(download_db,refresh_rate,url,'master.db',True, table='posters')
    if html!=str('ok'):
        html=cache.get(download_db,0,url,'master.db',True, table='posters')
    if progress_master:
        if KODI_VERSION>18:
            
            dp.update(0, 'Please wait'+'\n'+'Opening DB...'+'\n'+ '' )
        else:
            
            dp.update(0, 'Please wait','Opening DB...', '' )
    all_d=[]
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    file=os.path.join(user_dataDir,'localfile.txt')
    dbcon = database.connect(file)
    dbcur = dbcon.cursor()
    log.warning('type_search:'+type_search)
    
    heb_name=heb_name.replace(' ','')

    if type_search=='latest_movies':
        st_type ='\'%"mediatype": "movie"%\''#line:3423
        dbcur.execute("SELECT * FROM MyTable where type='item' and data like "+st_type )
    elif type_search=='latest_tv':
        st_type ='\'%"mediatype": "tv"%\''#line:3425
        dbcur.execute("SELECT * FROM MyTable where type='item' and data like "+st_type )
    elif type_search=='category_selected':
    
        if o_plot =='1-2':#line:3194
           dbcur .execute ("SELECT * FROM MyTable WHERE  name LIKE '0%' or name LIKE '1%' or name LIKE '2%' or name LIKE '3%' or name LIKE '4%' or name LIKE '5%' or name LIKE '6%' or name LIKE '7%' or name LIKE '8%' or name LIKE '9%' ")#line:3196
        else :#line:3197
           st_type ='\'%"mediatype": "movie"%\''#line:3423
           dbcur .execute ("SELECT * FROM MyTable WHERE name like '{0}%' and type='item' and data like {1}".format (o_plot,st_type ))#line:3198
    elif type_search=='category_selected_full':
           st_type ='\'%"mediatype": "movie"%\''#line:3423
           dbcur .execute ("SELECT * FROM MyTable WHERE genre like '%{0}%' and type='item' and data like {1}".format (o_plot,st_type ))#line:3198
    elif type_search=='search':
        dr_data=cache.get(refresh_token,24, table='pages')
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
        keyboard.doModal()
        if keyboard.isConfirmed() :
               search_entered = (keyboard.getText().replace("'","%27"))
           # search_entered = que(keyboard.getText())
               if search_entered!='':
                all_l=[]
                for items in dr_data:
                    all_f,all_img=get_folder('Search',items,search_entered,search=True)
                    all_l=place_links(all_f,all_img,all_l)
               if search_entered=='':
                sys.exit()
               if search_entered==' ':
                sys.exit()
        else:
          sys.exit()
        dbcur .execute ("SELECT * FROM MyTable where name like '%{0}%'".format (search_entered ))
    else:
        try:
            dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('%s',' ','')ORDER BY rowid DESC"%heb_name)
        except:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
            
            html=cache.get(download_db,0,url,'master.db',True, table='posters')
            xbmc.sleep(2000)
            dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('%s',' ','')ORDER BY rowid DESC"%heb_name)
    try:
        match = dbcur.fetchall()
    except:
        xbmc.sleep(2000)
        match = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    prev_name=heb_name
    all_data=[]
    count=0
    next_page_en=False
    per_page=int(Addon.getSetting('num_per_page'))

    sort_by_episode=False
    sort_by_ab=False
    for index,name,link,icon,fanart,plot,data,date,year,genre,father,type in match:
        icon=icon.strip()
        fanart=fanart.strip()
        data = clean_data(data)
        if type_search=='search':
            prev_name=father
            
        if KODI_VERSION<=18:
            name=name.encode('utf-8')
        if type_search=='latest_movies':
            try:
                dateadded=data['dateadded']
                data['plot']=data['dateadded']+'\n'+data['plot']
                plot=data['dateadded']+'\n'+plot
                data['title']=name.replace('%27',"'")
                
            except:
                
                dateadded='2020-01-01 01:01:00'
                pass
            season=' '
            episode=' '
            if 'Season' in data:
                season=data['Season']
            if 'Episode' in data:
                episode=data['Episode']
            original_title=data.get('originaltitle',name)
            
            id=data.get('tmdb',' ')
            if id==' ':
                    id=data.get('imdb',' ')
            for item in remove_keys:
                try:
                    data.pop(item, None)
                except:
                    pass
            try:
                if data['plot']=='':
                    data['plot']=plot
            except:
                pass
            try:
                trailer = "plugin://plugin.video.dragonFRD?mode=25&id=%s&url=%s" % (id,'movie')
            except:
                trailer = ''
            if not dateadded:
                dateadded='2020-01-01 01:01:00'
            all_data.append((name.replace ('%27',"'"),'Jen_link$$$$Matser_link'+link,icon,fanart,plot.replace ('%27',"'"),id,original_title,year,data,year,season,episode,dateadded,trailer))
        elif type_search=='latest_tv':
            original_title=data.get('originaltitle',name)
            season=' '
            episode=' '
            if 'Season' in data:
                season=data['Season']
            if 'Episode' in data:
                episode=data['Episode']
                
            try:
                dateadded=data['dateadded']
                data['plot']=data['dateadded']+'\n'+data['plot']
                plot=data['dateadded']+'\n'+plot
                data['title']=original_title.replace(' - IMDb','')+' עונה %s פרק %s'%(season,episode)
            except:
                dateadded='2020-01-01 01:01:00'
                pass
            
            
            id=data.get('tmdb',' ')
            if id==' ':
                    id=data.get('imdb',' ')
            for item in remove_keys:
                try:
                    data.pop(item, None)
                except:
                    pass
            if not dateadded:
                    dateadded='2020-01-01 01:01:00'
            all_data.append((original_title.replace(' - IMDb','')+' עונה %s פרק %s'%(season,episode),'Jen_link$$$$Matser_link'+link,icon,fanart,plot.replace ('%27',"'"),id,original_title,year,data,year,season,episode,dateadded,''))
        
        else:
            if type=='category':
                if 'tvshowtitle' in data:
                    sort_by_ab=True
                
                try:
                    if data['plot']=='':
                            data['plot']=plot
                except:
                    pass
                try:
                    id=data.get('tmdb',' ')
                    if id==' ':
                            id=data.get('imdb',' ')
                except:pass
                try:
                    trailer = "plugin://plugin.video.dragonFRD?mode=25&id=%s&url=%s" % (id,'tv')
                except:
                    trailer = ''
                name=name.replace('     ','').replace('    ','').replace('   ','').replace('  ','')
                aa=addDir3(name.replace ('%27',"'"),o_url,193,icon,fanart,plot.replace ('%27',"'"),data=year,video_info=data,id='11',heb_name=prev_name+name,tmdbid='categoty' ,trailer=trailer)
                all_d.append(aa)
            else:
                season=' '
                episode=' '
                
                if 'Season' in data:
                    season=data['Season']
                if 'Episode' in data:
                    episode=data['Episode']
                    try:
                        e=int(episode)
                        sort_by_episode=True
                    except:
                        pass
                        
                    
                log.warning('episode:'+episode)
                try:
                    dateadded=data['dateadded']
                    data['plot']=data['dateadded']+'\n'+data['plot']
                    plot=data['dateadded']+'\n'+plot
                    data['title']=name.replace('%27',"'")
                except:
                    dateadded='2020-01-01 01:01:00'
                    log.warning('Error date:'+str(data))
                    pass
              
                original_title=data.get('originaltitle',name)
                id=data.get('tmdb',' ')
                if id==' ':
                        id=data.get('imdb',' ')
                try:
                    trailer = "plugin://plugin.video.dragonFRD?mode=25&id=%s&url=%s" % (id,data['mediatype'])
                except:
                    trailer =''

                for item in remove_keys:
                    try:
                        data.pop(item, None)
                    except:
                        pass
                if not dateadded:
                    dateadded='2020-01-01 01:01:00'
                all_data.append((name.replace ('%27',"'"),'Jen_link$$$$Matser_link'+link,icon,fanart,plot.replace ('%27',"'"),id,original_title,year,data,year,season,episode,dateadded,trailer))

    if len(all_data)>0:#type_search=='latest_movies' or type_search=='latest_tv':
        count=0
        import datetime #line:1601
        if not sort_by_ab:
            
                all_data=sorted(all_data, key=lambda x:  time.strptime(x[12], '%Y-%m-%d %H:%M:%S'), reverse=True)

        for name,link,icon,fanart,plot,id,original_title,year,data,year,season,episode,dateadded,trailer in all_data:
                # if name=='[B][COLOR   aqua] סרטים אחרונים  [/COLOR][/B]':
                 # continue
                # if name=='[B][COLOR   aqua] פרקים אחרונים  [/COLOR][/B]':
                 # continue
                if count>=((page*per_page)+added_index):
                    aa=addLink(name,link,6,False,icon,fanart,plot,tmdb=id,original_title=original_title,data=year,video_info=data,year=year,season=season,episode=episode,place_control=True,trailer=trailer)
                    all_d.append(aa)
                if count>((page+1)*per_page):
                   
                    next_page_en=True
                    break
                count+=1
    if type_search=='' or type_search=='%20':
        aa=addDir3('[B][COLOR burlywood]-סרטים אחרונים- [/COLOR][/B]',o_url,193,'http://ngarba.xyz/adds/yos/aa354.jpg','http://ngarba.xyz/adds/yos/aa350.jpg','סרטים אחרונים',tmdbid='latest_movies' )
        all_d.append(aa)
        aa=addDir3('[B][COLOR burlywood]-פרקים אחרונים- [/COLOR][/B]',o_url,193,'http://ngarba.xyz/adds/yos/aa365.jpg','http://ngarba.xyz/adds/yos/aa349.jpg','פרקים אחרונים',tmdbid='latest_tv' )
        all_d.append(aa)
        aa=addDir3('[B][COLOR burlywood]לפי א-ב[/COLOR][/B]',o_url,194,'http://ngarba.xyz/adds/yos/aa361.jpg','http://ngarba.xyz/adds/yos/aa348.jpg','לפי א-ב' )
        all_d.append(aa)
        aa=addDir3('[B][COLOR burlywood]קטגוריות[/COLOR][/B]',o_url,197,'http://ngarba.xyz/adds/yos/aa355.jpg','http://ngarba.xyz/adds/yos/aa345.jpg','לפי א-ב' )
        all_d.append(aa)
        mypass=""
        key='zWrite'
        mypass=crypt(mypass,key)
        # aa=addDir3('Dragon RD', 'https://narcacist.com/Jen4k/4ksection.json',191,'http://ngarba.xyz/adds/yos/aa354.jpg','http://ngarba.xyz/adds/yos/aa354.jpg','Odin',mypass=mypass)
        # all_d.append(aa)
        aa=addDir3('[B][COLOR burlywood]חיפוש[/COLOR][/B]',o_url,193,'http://ngarba.xyz/adds/yos/aa362.jpg','http://ngarba.xyz/adds/yos/aa347.jpg','חיפוש',tmdbid='search' )
        all_d.append(aa)
        aa=addDir3('[B][COLOR burlywood]נוגן לאחרונה[/COLOR][/B]','www',144,'http://ngarba.xyz/adds/yos/aa356.jpg','http://ngarba.xyz/adds/yos/aa351.jpg','Last Played') 
        all_d.append(aa)
        
    elif next_page_en:
        aa=addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',o_url,193,iconimage,o_fanart,o_plot,tmdbid=type_search,dates=str(page+1),heb_name=prev_name)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    if progress_master:
        dp.close()
    
    if sort_by_episode:
        xbmcplugin .addSortMethod (int (sys .argv [1 ]),xbmcplugin .SORT_METHOD_EPISODE )#line:3759
def refresh_token():
    if os.path.exists(os.path.join(addonPath,'resources','data','accounts.db')):
        data={}
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        dbcon =database .connect (jdata_file )#line:226
        dbcur =dbcon .cursor ()#line:227
        dbcur .execute ("SELECT * FROM store")#line:2995
        
        match =dbcur .fetchall ()#line:2997
        for key,value in match:
            
            data[key]=json.loads(value.replace("u'","'").replace("'",'"'))
        dbcur .close ()#line:3761
        dbcon .close ()#line:3762
      
    else:
        with open(jdata_file) as json_file:
            data = json.load(json_file)
    
    dr_data={}
    counter=0
    for keys in data:
 
        dr_data[keys]={}
        dr_data[keys]['name']=data[keys]['name']
        dr_data[keys]['icon']=data[keys].get('icon','')
        dr_data[keys]['fan']=data[keys].get('fanart','')
        dr_data[keys]['drivers_id']=keys
        dr_data[keys]['token']=data[keys]['access_tokens']['refresh_token']
 
        headers = {
            'Connection': 'Keep-Alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0; Redmi Note 4X MIUI/V10.2.1.0.MBFMIXM)'
        }
        progress='requests Herok'
        url='https://drive-login.herokuapp.com/refresh'
        body='refresh_token=%s&provider=googledrive'%dr_data[keys]['token']
        headers={'addon': 'plugin.noone 1.0.2/1.0.2'}
        import requests
        x=requests.post(url,headers=headers,params=body).json()
        
        dr_data[keys]['auth']=u'Bearer %s'%x['access_token']
        
        
        counter+=1
        
    return dr_data
def get_folder(name,url,fid,page_token='',all_d=[],search=False,whats_new=False,pre_date='',collect_icons={}):
    o_fid=fid

    import base64
    if not search and not whats_new:
        if page_token!='':
            y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false&pageToken={1}".format(fid,que(page_token)),url)
            
            
        else:
            y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(fid),url)
    
    if whats_new:
        
        if page_token!='':
            y=get_result("https://www.googleapis.com/drive/v3/files?q=modifiedTime%3E'{0}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false&pageToken={1}".format(pre_date,que(page_token)),url)
        else:
            y=get_result("https://www.googleapis.com/drive/v3/files?q=modifiedTime%3E'{0}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(pre_date),url)
        
        
    if search:
        u="https://www.googleapis.com/drive/v3/files?q=fullText contains '%s' or fullText contains '%s'&spaces=drive&includeTeamDriveItems=true&prettyPrint=false&fields=files(id,name,modifiedTime,size,mimeType,description,hasThumbnail,thumbnailLink,owners(permissionId),parents,trashed,imageMediaMetadata(width),videoMediaMetadata)&corpora=teamDrive&supportsTeamDrives=true"%(fid,fid)
        y=get_result("https://www.googleapis.com/drive/v3/files?q=fullText%20contains%20'{0}'%20or%20fullText%20contains%20'{1}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(fid,fid),url)
       
    if y==[]:
        return []
    general_icon=None
    
    for items in y['files']:
        t_name=items['name']
        if '.ICON.GENERAL'  in t_name:
            
            general_icon=items['thumbnailLink'].replace('.ICON.GENERAL','')
        if 'ICON' in t_name:
            b=base64.b64encode(t_name.replace('.ICON','').encode("utf-8")).decode("utf-8") 
            collect_icons[b]=items['thumbnailLink']
    if whats_new or search:
        general_icon=None

    vid_types=['.mp4','.mkv','.avi']
    import datetime,time
    
    for items in y['files']:
        logging.warning('343422 '+str(items))
        t_name=items['name']
        ct_date=''
        if 'modifiedTime' in items:
            ct_date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(items['modifiedTime'], "%Y-%m-%dT%H:%M:%S.%fZ"))).strftime("%d.%m.%Y")
            #try:
            #    ct_date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(order_date, "%Y-%m-%dT%H:%M:%S.000Z"))).strftime("%d.%m.%Y")
            #except:
            #    ct_date=''
        if whats_new or search:
            if 'parents' in items:
             fid=items['parents'][0]
        if 'ICON' not in t_name:
            media_type=False
            if 'video' in items['mimeType']:
                media_type=True
            for t in vid_types:
                t_name=t_name.replace(t,'')
            iconimage=' '
            fanart=' '
            description=' '

            b=base64.b64encode(t_name.encode("utf-8")).decode("utf-8") 
            if b in collect_icons:
                iconimage=collect_icons[b]
                if 'thumbnailLink' in items:
                    fanart=items['thumbnailLink']
                else:
                    fanart=iconimage
            elif 'thumbnailLink' in items:
                iconimage=items['thumbnailLink']
                fanart=iconimage
            if general_icon:
                iconimage=general_icon
                if 'thumbnailLink' in items:
                    fanart=items['thumbnailLink']
                else:
                    fanart=iconimage
            pre_data=''
            if 'folder' in items['mimeType']:
                mode=234
                
                #addDir3(t_name,url,mode,iconimage,fanart,ct_date+'\n'+description,fid=items['id'],ct_date=ct_date)
            else:
                mode=235
                
                
                pre_data=json.dumps([fid,url])
                #if '.srt' not in t_name and media_type:
                #    addLink(t_name,url,mode,iconimage,fanart,ct_date+'\n'+description,fid=items['id'],ct_date=ct_date,pre_data=pre_data)

            if t_name=='סדרות':
                iconimage='http://ngarba.xyz/adds/yos/a1a223.png'
                fanart='http://ngarba.xyz/adds/yos/aa117.jpg'
            elif t_name=='סרטים':
                iconimage='http://ngarba.xyz/adds/yos/a1a222.png'
                fanart='http://ngarba.xyz/adds/yos/aa117.jpg'
            all_d.append((t_name,url,mode,items['id'],name,iconimage,fanart,ct_date,pre_data,media_type))
    if 'nextPageToken' in y:
        get_folder(name,url,o_fid,page_token=y['nextPageToken'],collect_icons=collect_icons,whats_new=whats_new,search=search,pre_date=pre_date)
    return all_d,collect_icons
def get_result(url,provider,dont_show=True):
    dr_data=cache.get(refresh_token,24, table='pages')
    auth=dr_data[provider]['auth']
    import requests
    y=requests.get(url,headers= {'authorization': auth}).json()
    if 'error' in y:
        
        if y['error']['message']=='Invalid Credentials':
            dr_data=cache.get(refresh_token,0, table='pages')
            auth=dr_data[provider]['auth']
            y=requests.get(url,headers= {'authorization': auth}).json()
        else:
            if not dont_show:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('Error', y['error']['message'])))
             
            return []
    return y
def search():
    dr_data=cache.get(refresh_token,24, table='pages')
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = que(keyboard.getText())
           if search_entered!='':
            all_l=[]
            for items in dr_data:
                all_f,all_img=get_folder('Search',items,search_entered,search=True)
                all_l=place_links(all_f,all_img,all_l)
def jump_seek_tur(name,url,fid,pre_data):
    table_name='Dream'
    global break_jump
    break_jump=1
    timeout=0
    try:
        ab_req=xbmc.abortRequested()
    except:
        monit = xbmc.Monitor()
        ab_req=monit.abortRequested()

    while timeout<200 and ab_req:
        timeout+=1
        if break_jump==0:
            break
        if xbmc.Player().isPlaying():
            break
        xbmc.sleep(100)
    mark_once=0
    counter_stop=0
    g_timer=0
    while xbmc.Player().isPlaying():
        
        if break_jump==0:
            break
        try:
        
            vidtime = xbmc.Player().getTime()
        except Exception as e:
            vidtime=0
            pass
       
        
        if vidtime>0.2:
            try:
               g_timer=xbmc.Player().getTime()
               
                
                
               g_item_total_time=xbmc.Player().getTotalTime()
               time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
               
            except:
                pass

    all_record=read_firebase(table_name+'_seek_time')

    
    
    f_name=name
    
    for itt in all_record:

        
        if all_record[itt]['name']==f_name:
                
                delete_firebase(table_name+'_seek_time',itt)
  
    if g_timer>30:
        write_firebase(name,url,fid,pre_data,table_name+'_seek_time',str(g_timer),str(g_item_total_time))

    return 0
def play(name,url,fid,pre_data): 
    try:
        if not KODI_VERSION<=18:
            res = ''.join([i for i in name.replace(')','').replace('(','') if not i.isdigit()])
            res=res[::-1]
            regex='.*([1-3][0-9]{3})'
            year_pre=re.compile(regex).findall(name)
            year=0
            if len(year_pre)>0:
                year=year_pre[0]
             
                name=name.replace(year,'')
            pre_year='('+year+')'
            name=res+pre_year
    except:pass

    y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format('zzzzzzzzzzzzzzzz'),url,dont_show=True)
    dr_data=cache.get(refresh_token,24, table='pages')
    auth=dr_data[url]['auth']
    url='https://www.googleapis.com/drive/v3/files/%s?alt=media'%(fid)

    head=url_encode({'authorization': auth})
    ff_link=url+"|"+head
    
    listItem = xbmcgui.ListItem(name, path=ff_link) 
        

    listItem.setInfo(type='Video', infoLabels={'title':name,'mpaa':('heb')})
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    fid,url=json.loads(pre_data)


    
    all_f,all_img=get_folder(name,url,fid)
  
    subs=None
    for t_name,url,mode,fid,parent,iconimage,fanart,ct_date,pre_data,media_type in all_f:
        
        if t_name==name+'.srt':
           
            
            subs='https://www.googleapis.com/drive/v3/files/%s?alt=media'%(fid)
    if subs:
        
        x=0
        while not xbmc.Player().isPlaying() and x<1000:
                xbmc.sleep(10) #wait until video is being played
                x+=1
        xbmc.sleep(500)
        
        temp_sub=os.path.join(user_dataDir,'temp_sub.srt')
        if  KODI_VERSION>18:
            import chardet
            try:
                from urllib.request import Request, urlopen  # Python 3
            except ImportError:
                from urllib2 import Request, urlopen  # Python 2

            req = Request(subs)
            req.add_header('authorization', auth)
            
            x = urlopen(req).read()
            encoding=chardet.detect(x)['encoding']
            x=str(x.decode(encoding))
            log.warning('Encoding:'+encoding)
            file = open(temp_sub, 'w', encoding="utf-8") 
            
            
            
        else:
            import requests
            x=requests.get(subs,headers={'authorization': auth}).text
            file = open(temp_sub, 'w') 
        
        file.write(x)
        file.close()
        while  xbmc.Player().isPlaying():
            vidtime = xbmc.Player().getTime()
            if vidtime>0.5:
                break
        
        xbmc.Player().setSubtitles(temp_sub)
    thread=[]

    thread.append(Thread(jump_seek_tur,name,url,fid,pre_data))
        
    
    thread[0].start()
def what_new():
    import datetime
    import _strptime
    data_back=xbmcgui.Dialog().numeric(0, 'כמה ימים אחורה') 
    from datetime import date, timedelta

    current_date = date.today().isoformat()   
    days_before = (date.today()-timedelta(days=int(data_back))).isoformat()
    dr_data=cache.get(refresh_token,24, table='pages')
    all_l=[]
    for items in dr_data:
        
        all_f,all_img=get_folder('Search',items,'root',whats_new=True,pre_date=str(days_before))
        all_l=place_links(all_f,all_img,all_l)
def set_view_type_tur():
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    preserve_viewid = window.getFocusId()
    view_type=xbmc.getInfoLabel('Container.Viewmode' )
    listlabel = xbmc.getInfoLabel("ListItem.Tag")
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""mode TEXT,""name TEXT, ""id TEXT, ""type TEXT, ""free TEXT,""free2 TEXT);"%'views')
    
    #ok=xbmcgui.Dialog().yesno(("Global lock"),('lock all displays of the addon?'))
    if 1:
        dbcur.execute("SELECT * FROM views  where free='global'")

        match = dbcur.fetchall()
       
        if len(match)>0:
            dbcur.execute("UPDATE views SET name='%s',id='%s' where free='global'"%(view_type,str(preserve_viewid)))
        else:
            dbcur.execute("INSERT INTO views Values ('%s','%s','%s','%s','%s','%s')"%('pre_mode',view_type,str(preserve_viewid),' ','global',' '))
        dbcon.commit()
        a= str('Updated to '+(view_type))
        xbmcgui.Dialog().ok('Ok',a)
    
   
    dbcur.close()
    dbcon.close()
def place_links(all_f,all_img,all_l):
    all_w={}
    if len(Addon.getSetting("firebase"))>0:
            all_db=read_firebase('Dream_seek_time')
        
            for itt in all_db:
                
                items=all_db[itt]
                all_w[items['name']]={}
                all_w[items['name']]['seek_time']=items['seek_time']
                all_w[items['name']]['total_time']=items['total_time']

    for t_name,url,mode,fid,parent,iconimage,fanart,ct_date,pre_data,media_type in all_f:
        
        if fid in all_l:
            continue
        all_l.append(fid)
        import base64
        b=base64.b64encode(t_name.encode("utf-8")).decode("utf-8") 
        if KODI_VERSION<19:
            t_name=t_name.encode('utf-8')
        if b in all_img:
            iconimage=all_img[b]
            
        if len(fanart)<4:
            fanart=iconimage
            
        if mode==234:
            
            
            addDir4(t_name,url,mode,iconimage,fanart,ct_date,fid=fid,ct_date=ct_date)
        else:
            
            
            
      
            if '.srt' not in t_name and media_type:
                
                addLink2(t_name,url,mode,iconimage,fanart,ct_date,fid=fid,ct_date=ct_date,pre_data=pre_data,all_w=all_w)
    return all_l
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

params=get_params()

selected_scrapers='All'
url=None
name=''
mode=None
iconimage=None
fanart=None
description=None
data=None
original_title=None
read_data2=''
id='0'
dates='0'
season='0'
episode='0'
show_original_year='0'
nextup='true'
dd=''
video_data={}
get_sources_nextup='false'
all_w={}
use_filter='true'
use_rejected='true'
heb_name=''
tmdbid=''
has_alldd='false'
prev_name=''
search_db=''
mypass=""
fid=None
description=""
try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass
try:        
        data=(params["data"])
except:
        pass
try:        
        original_title=unque(params["original_title"])
except:
        pass
        
try:        
        id=(params["id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass
try:        
        show_original_year=(params["show_original_year"])
except:
        pass
try:        
        dd=(params["dd"])
except:
        pass
try:        
        nextup=(params["nextup"])
except:
        pass
try:        
        dates=(params["dates"])
except:
        pass
try:        
        video_data=unque(params["video_data"])
except:
        pass
try:        
        get_sources_nextup=(params["get_sources_nextup"])
except:
        pass
        
try:        
        all_w=unque(params["all_w"])
except:
        pass
        
try:        
        use_filter=(params["use_filter"])
except:
        pass
        
try:        
        use_rejected=(params["use_rejected"])
except:
        pass
try:        
        heb_name=unque(params["heb_name"])
except:
        pass
        
try:        
        tmdbid=str(params["tmdbid"])
except:
        pass
try:        
        has_alldd=str(params["has_alldd"])
except:
        pass
prev_name=name
try:        
        prev_name=unque(params["prev_name"])
except:
        pass
try:        
        search_db=unque(params["search_db"])
except:
        pass

try:        
        from_seek=(params["from_seek"])=='True'
except:
        pass
try:
    mypass=unque(params["mypass"])
except:
        pass
try:
    url=url.replace(' ','%20')  
except:
    pass
try:        
        description=unque(params["description"])
except:
        pass
try:        
        fid=(params["fid"])
except:
        pass
try:        
        pre_data=(params["pre_data"])
except:
        pass
if Addon.getSetting("full_db")=='true':
    
    if KODI_VERSION>18:
        dp_full.update(0, 'Please wait'+'\n'+'Level 17...'+'\n'+ '' )
    else:
        dp_full.update(0, 'Please wait','Level 17...', '' )
    dp_full.close()
if mode==None :
    dr_data=cache.get(refresh_token,24, table='pages')
    # dr_data=refresh_token()
    all_l=[]
    for items in dr_data:
        if str(dr_data[items]['drivers_id']) in names:
            name=names[str(dr_data[items]['drivers_id'])]
        else:
            name=dr_data[items]['name'].encode('utf-8')
        url=items
        mode=234
       
        if items in icons:
            iconimage=icons[items]
        else:
            iconimage=dr_data[items]['icon']#icons[items]
        if items in fans:
            fanart=fans[items]
        else:
            fanart=dr_data[items]['fan']#fans[items]
       
        all_f,all_img=get_folder(name,url,'root')
        place_links(all_f,all_img,all_l)
        description=name
        #addDir3(name,url,mode,iconimage,fanart,description,fid='root')
    
    
    addDir4('מה חדש','www',236,'http://ngarba.xyz/adds/yos/a1a221.png','http://s1.picswalls.com/wallpapers/2014/01/29/dragon-hd-wallpaper_063723920_21.jpg',' ',fid='root')
    addDir4('חפש','www',237,'http://ngarba.xyz/adds/yos/a1a220.png','http://ngarba.xyz/adds/yos/aa117.jpg',' ',fid='root')
    # return 0
    # master_addon(list_url,iconimage,fanart,heb_name,tmdbid,dates,'Master')


elif mode==6:
    from default import play_link
    play_link(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year,dd,heb_name,prev_name=prev_name,has_alldd=has_alldd,nextup=nextup,video_data_exp=video_data,get_sources_nextup=get_sources_nextup,all_w=all_w,tvdb_id=tmdbid)


elif mode==25:
    from default import play_trailer
    play_trailer(id,url,description)

elif mode==35:
    from default import  ClearCache
    ClearCache()


elif mode==137:
    from default import clear_rd
    clear_rd()

elif mode==139:
    from default import clear_pr
    clear_pr()
elif mode==140:
    from default import re_enable_pr
    re_enable_pr()
elif mode==141:
    from default import clear_all_d
    clear_all_d()

elif mode==143:
    from default import search_history
    search_history(url,iconimage,fanart)
elif mode==144:
   from default import last_played
   last_played()
elif mode==145:
   from default import last_viewed
   read_data2,enc_data,all_folders,url_o=cache.get(last_viewed,24,url, table='last_view')
   aa=[]
   if len(all_folders)>0:
        for name, url,mode, icon,added_res_trakt,all_w,heb_name,fanart,data_ep,plot,original_title,id,season,episode,eng_name,watched,show_original_year,dates,dd in all_folders:
            aa.append(addNolink(name, url,mode,False, iconimage=icon,all_w_trk=added_res_trakt,all_w=all_w,heb_name=heb_name,fanart=fanart,data=data_ep,plot=plot,original_title=original_title,id=id,season=season,episode=episode,eng_name=eng_name,watched=watched,show_original_year=show_original_year,dates=dates,dd=dd,dont_place=True))
            
        if Addon.getSetting("trakt_access_token")!='' and url_o=='tv':
            aa.append(addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32114), id,157,False,fanart='https://bestdroidplayer.com/wp-content/uploads/2019/06/trakt-what-is-how-use-on-kodi.png', iconimage=BASE_LOGO+'trakt.png',plot=' ',dont_place=True))
            
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))



elif mode==151:

    Addon.openSettings()

elif mode==158:
    from default import was_i
    was_i()
elif mode==159:
    from default import remove_was_i
    remove_was_i(name,id,season,episode)

elif mode==162:
    from default import clear_was_i
    clear_was_i()


elif mode==167:
    from default import set_view_type
    set_view_type(str(url))

elif mode==170:
    from default import simple_play
    simple_play(name,url)

elif mode==175:

    listItem = xbmcgui.ListItem(name, path=url) 
    listItem.setInfo(type='Video', infoLabels={'title':name})
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)


elif mode==187:
    from default import get_keywords_ab
    get_keywords_ab(iconimage,fanart)
elif mode==188:
    from default import get_keywords
    get_keywords(url,iconimage,fanart,dates)

elif mode==191:
    from default import populate_playlist,populate_json_playlist
    
    if ".json" in url or ".m3u8" in url:
        populate_json_playlist(url,iconimage,fanart,search_db,mypass=mypass)
        
    else:
        populate_playlist(url,iconimage,fanart,search_db,mypass=mypass)

elif mode==193:

    master_addon(list_url,iconimage,fanart,heb_name,tmdbid,dates,description)

elif mode==194:
    from default import  cat_select
    cat_select(iconimage,fanart,url)
elif mode==196:
    from default import play_youtube
    play_youtube(url,name )
elif mode==197:
    from default import cat_full_select
    cat_full_select(iconimage,fanart,url)
elif mode==199:
    from default import run_link
    run_link (url )
elif mode==233:
    from  resources.modules.client import get_html
    furl=re.compile('message\((.+?)\)').findall(url)
    if len(furl)==0:
        x=get_html(url.split('message/')[1]).content()
        showText(name,x)
    else:
        x=get_html(furl[0]).content()
        showText(name,x)
elif mode==234:

    all_l=[]
    all_f,all_img=get_folder(name,url,fid)

    place_links(all_f,all_img,all_l)
elif mode==235:
    play(name,url,fid,pre_data=pre_data)
elif mode==236:
    what_new()
    
elif mode==237:
    search()
elif mode==238:
    set_view_type_tur()
# elif mode==6:
    # ClearCache()
# elif mode==99:
    # disply_hwr2 ()
match=[]


if Addon.getSetting("display_lock")=='true':
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""mode TEXT,""name TEXT, ""id TEXT, ""type TEXT, ""free TEXT,""free2 TEXT);"%'views')
    try:
        dbcur.execute("SELECT * FROM views where (mode='%s' or free='global')"%(str(mode)))


                
        match = dbcur.fetchall()
    except:
        match=[]
    dbcur.close()
    dbcon.close()
all_modes=[]


type='%s default'%Addon.getAddonInfo('name')
for mode,name,id,type,free1,free2 in match:
        all_modes.append(mode)

if mode=='global':
    type='%s default'%Addon.getAddonInfo('name')
log.warning('type:'+type)
if type=='files' or type=='movies' or type=='tvshows' or type=='episodes':
    #log.warning('setContent:'+type)
    xbmcplugin.setContent(int(sys.argv[1]), type)
else:
    if mode==2 or mode==3 or mode==114 or mode==112 or mode==101:
        xbmcplugin.setContent(int(sys.argv[1]), 'files')
    elif mode==16 :
       xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    elif mode==19 or mode==20 or sort_by_episode:
       xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    else:
        log.warning('Set Type:movies')
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')

if len(all_modes)>0:
    
    #log.warning('Container.SetViewMode(%d)' % int(id))
    xbmc.executebuiltin('Container.SetViewMode(%d)' % int(id))

xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
