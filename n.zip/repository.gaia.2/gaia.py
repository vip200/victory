# coding: utf-8
import xbmc,time,threading

refreshCommand = 'RunPlugin(plugin://repository.gaia.2/?mode=1)'
xbmc.executebuiltin(refreshCommand)


def every(delay, task):
  next_time = time.time() + delay
  while True:
    time.sleep(max(0, next_time - time.time()))
    try:
      task()
    except Exception:
      pass
    next_time += (time.time() - next_time) // delay * delay + delay
def check_update():
    refreshCommand = 'RunPlugin(plugin://repository.gaia.2/?mode=1)'
    xbmc.executebuiltin(refreshCommand)
    
#10800 3שעות
threading.Thread(target=lambda: every(10800, check_update)).start()



