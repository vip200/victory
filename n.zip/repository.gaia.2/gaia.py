# coding: utf-8
import xbmc

refreshCommand = 'RunPlugin(plugin://repository.gaia.2/?mode=1)'
xbmc.executebuiltin(refreshCommand)
xbmc.executebuiltin('AlarmClock(idanplus,{0},01:00:00,silent,loop)'.format(refreshCommand))



