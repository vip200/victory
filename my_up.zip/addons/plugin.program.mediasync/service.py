# -*- coding: utf-8 -*-
import xbmc,time,xbmcaddon,os,xbmcgui,re,logging,threading,urllib,json
import ssl,xbmcvfs
from datetime import date, datetime, timedelta
from resources.modules import tmdbn
try:
    from urllib.request import urlopen
    from urllib.request import Request
except ImportError:
    from urllib2 import urlopen
    from urllib2 import Request
Addon = xbmcaddon.Addon()
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath

else:#קודי19
    translatepath=xbmcvfs.translatePath
START=True

COLOR2='yellow'
COLOR1='white'
ADDONTITLE='Media Sync'
HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
PACKAGES       = os.path.join(ADDONS,   'packages')
iconx = Addon.getAddonInfo('icon')
DIALOG         = xbmcgui.Dialog()


user_dataDir = translatepath(Addon.getAddonInfo("profile"))


AUTONEXTRUN    = Addon.getSetting("next_sync")
AUTOFEQ        = Addon.getSetting('autosyncfeq')
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)


def LogNotify(title, message, times=2000, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound) 
file_data=''
file_code=''


def read_firebase(table_name):
        from resources.modules.firebase import firebase
        firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
        result = firebase.get('/', None)
        if table_name in result:
            return result[table_name]
        else:
            return {}
def get_telenum(file_data):
            all_db=read_firebase('tele')
            data=[]
            for itt in all_db:
                items=all_db[itt]
                data.append((items['number']))
            for file_data in data:

                return file_data
def get_telecode(file_code):
            all_db=read_firebase('telec')
            data=[]
            for itt in all_db:
                items=all_db[itt]
                data.append((items['code']))
            for file_code in data:

                return file_code
                


if not os.path.exists(os.path.join(user_dataDir, '4.2.0')) and len(Addon.getSetting("firebase"))>0:
    Addon.setSetting("tele_code",get_telecode(file_code)) 
    Addon.setSetting("tele_number",get_telenum(file_data)) 
    
    file = open(os.path.join(user_dataDir, '4.2.0'), 'w') 
     
    file.write(str('Done'))
    file.close()
player_monitor = xbmc.Monitor()
class KodiPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
        kplayer=xbmc.Player.__init__(self)

    @classmethod
    def onPlayBackEnded(self):
          
          if not Addon.getSetting("bot_id")=='':
            xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=6&url=www)")
          # if len(Addon.getSetting("firebase"))>0:
            # xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=12&url=www)")
            # xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=15&url=www)")
    @classmethod
    def onPlayBackStopped(self):
          if not Addon.getSetting("bot_id")=='':
            xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=6&url=www)")
          # if len(Addon.getSetting("firebase"))>0:
            # xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=12&url=www)")
            # xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=15&url=www)")

# def ddd():
    # service = False
    # days = [TODAY, TOMORROW,TWODAYS, THREEDAYS, ONEWEEK]
    # feq = int(float(AUTOFEQ))
    # if AUTONEXTRUN <= str(TODAY) or feq == 0:
        # service = True
        # next_run = days[feq]
        # Addon.setSetting('next_sync', str(next_run))

    # if service == True:
      # xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=23&url=www)")

# ddd()


# xbmc.executebuiltin(refreshCommand)
if len(Addon.getSetting("firebase"))>0:
    refreshCommand = "RunPlugin(plugin://plugin.program.mediasync?mode=12&url=www)"
    xbmc.executebuiltin('AlarmClock(mediasync,{0},03:00:00,silent,loop)'.format(refreshCommand))

class KodiRunner:
  if Addon.getSetting("backg_sync")=='true':
    player = KodiPlayer()
    while not player_monitor.abortRequested():
        player_monitor.waitForAbort(1)
    del player

monitor = xbmc.Monitor()

strings = time.strftime("%Y,%m,%d,%H,%M,%S")
t = strings.split(',')
numbers = [ int(x) for x in t ]
pre_date=numbers[2]
while not monitor.abortRequested() and not Addon.getSetting("bot_id")=='' and not Addon.getSetting("user_name")=='':

    if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            break

    START=False
    strings = time.strftime("%Y,%m,%d,%H,%M,%S")
    t = strings.split(',')
    numbers = [ int(x) for x in t ]
    
    if numbers[3]==int(Addon.getSetting("update")) and numbers[2]!=pre_date:

        
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מסנכרן נתונים בערוץ[/COLOR]' % COLOR2)
        pre_date=numbers[2]
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=3&url=www)")

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון הסתיים[/COLOR]' % COLOR2)

       
    xbmc.sleep(1000)
del monitor


