# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,re,xbmcplugin,sys,time,random
import shutil
import urllib,xbmcvfs
import re
import json
import logging
import zipfile
from datetime import date, datetime, timedelta

try:
    import urllib.parse
except:
    import urlparse
try:
    from resources.libs.zfile import Items
except:pass
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath

else:#קודי19
    translatepath=xbmcvfs.translatePath
if KODI_VERSION<=18:
    que=urllib.quote_plus
    url_encode=urllib.urlencode
else:
    que=urllib.parse.quote_plus
    url_encode=urllib.parse.urlencode
if KODI_VERSION<=18:
    unque=urllib.unquote_plus
else:
    unque=urllib.parse.unquote_plus

KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
try:
    HOME           = xbmc.translatePath('special://home/')
except:
    HOME           = xbmcvfs.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
try:
    if KODIV > 17:

        from resources.libs import zfile as zipfile #FTG mod for Kodi 18
    else:
        import zipfile
except:pass


Addon = xbmcaddon.Addon()
addon_id = 'plugin.program.mediasync'
ADDON = xbmcaddon.Addon(id=addon_id)
FANART = translatepath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = translatepath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = translatepath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
try:
    addonPath = translatepath(Addon.getAddonInfo("path")).decode("utf-8")
    user_dataDir = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
except:
    addonPath = translatepath(Addon.getAddonInfo("path"))
    user_dataDir = translatepath(Addon.getAddonInfo("profile"))
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
VERSION = "3.0.0"
PATH = "forceclose"            
BASE = "fclose"
DIALOG         = xbmcgui.Dialog()
COLOR1         = 'yellow'
COLOR2         = 'white'
log            = translatepath('special://logpath/')
LOGO=os.path.join(addonPath, 'resources', 'logos/')
ADDONTITLE='Media Sync'

AUTONEXTRUN    = Addon.getSetting("next_sync")
AUTOFEQ        = Addon.getSetting('autosyncfeq')
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
TWODAYS        = TODAY + timedelta(days=2)
THREEDAYS      = TODAY + timedelta(days=3)
ONEWEEK        = TODAY + timedelta(days=7)






def LogNotify(title, message, times=4000, icon=ICON,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def get_custom_params(item):
        param=[]
        item=item.split("?")
        if len(item)>=2:
          paramstring=item[1]
          
          if len(paramstring)>=2:
                params=item[1]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def get_params():
        param=[]

        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param  
def backup_vik():
    import datetime
    strptime = datetime.datetime.strptime
    logging.warning('backing up')
    threading.Thread(target=do_bakcup).start()
    return '1'
def read_firebase(table_name):
    from resources.modules.firebase import firebase
    firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
# write_firebase(name,tmdb,season,episode,playtime,total,free,table_name,'0','0')

def write_firebase_rd(r,p,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'r_user':r,'r_pass':p})
    return 'OK'
def write_firebase_trakt(u,p,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'r_user':u,'r_pass':p})
    return 'OK'

def write_firebase_iptv(m3u,epg,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'m3u':m3u,'epg':epg})
    return 'OK'
def write_favourite(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'favourite':file_data})
    return 'OK'
def write_skin(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'skin':file_data})
    return 'OK'
def write_guisettings(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'guisettings':file_data})
    return 'OK'
def write_wizsettings(file_data,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'wizsettings':file_data})
    return 'OK'
def write_tele_login(file_data,file_login,table_name):#test
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'file_data':file_data,'file_login':file_login})
    return 'OK'
def write_tele_number(search_entered,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'number':search_entered})
    return 'OK'
def write_tele_code(search_entered,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'code':search_entered})
    return 'OK'

def delete_firebase(table_name,record):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = fb_app.delete(table_name, record)
    return 'OK'
def check_firebase():
        try:
            all_db=read_firebase('table_name')
        except:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'בעיה בסנכרון'),'[COLOR %s]מזהה ID שגוי[/COLOR]' % COLOR2)
            
            try:
              xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync?mode=9&url=www)")
            except:pass
def firebase_rd():
  try:
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    r=(Settingz.getSetting("rd_user"))
    p=(Settingz.getSetting("rd_pass"))
    table_name='rd_save'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:
       if not r=='' and not p=='':
            delete_firebase(table_name,items)

    if write_fire and not r=='' and not p=='':

        write_firebase_rd(r,p,table_name)
  except:pass
def firebase_trakt():
  try:
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    u=(Settingz.getSetting("trk_user"))
    p=(Settingz.getSetting("trk_pass"))
    table_name='trakt_save'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:
       if not u=='' and not p=='':
            delete_firebase(table_name,items)

    if write_fire and not u=='' and not p=='':

        write_firebase_trakt(u,p,table_name)
  except:pass
def firebase_iptv():
    try:
        pvr = xbmcaddon.Addon('pvr.iptvsimple')
        m3u=(pvr.getSetting("m3uUrl"))
        epg=(pvr.getSetting("epgUrl"))
        table_name='iptvsimple'
        all_firebase=read_firebase(table_name)
        write_fire=True
        
        for items in all_firebase:
            if not m3u=='':
                delete_firebase(table_name,items)

        if write_fire and not m3u=='':

            write_firebase_iptv(m3u,epg,table_name)
    except:pass
    
def sync_rd():
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    if not Settingz.getSetting("auto_rd")=='true':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון RD[/COLOR]' % COLOR2)
        all_db=read_firebase('rd_save')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['r_user'],items['r_pass']))
        for r_user,r_pass in data:
            Settingz.setSetting('auto_rd','true')
            Settingz.setSetting('rd_user',r_user)
            Settingz.setSetting('rd_pass',r_pass)
        xbmc.sleep(5000)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Settingz-Anon?mode=304&url=www)")
def sync_trakt():
    Settingz = xbmcaddon.Addon('plugin.program.Settingz-Anon')
    if not Settingz.getSetting("auto_trk")=='true':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר חשבון טראקט.[/COLOR]' % COLOR2)
        all_db=read_firebase('trakt_save')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['r_user'],items['r_pass']))
        for r_user,r_pass in data:
            Settingz.setSetting('auto_trk','true')
            Settingz.setSetting('trk_user',r_user)
            Settingz.setSetting('trk_pass',r_pass)
        xbmc.sleep(5000)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Settingz-Anon?mode=308&url=www)")
            

def sync_iptv():
    
    all_db=read_firebase('iptvsimple')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['m3u'],items['epg']))
    for m3u,epg in data:

            setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "pvr.iptvsimple","settings.xml")
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'משחזר את חשבון ה IPTV שלך'),'[COLOR %s]מגדיר כתובת ערוצים...[/COLOR]' % COLOR2)
            if KODI_VERSION<=18:
                file = open(setting_file, 'r') 
                file_data= file.read()
                file.close()

                regex='<setting id="m3uUrl" value="(.+?)/>'
                m=re.compile(regex).findall(file_data)[0]
                file = open(setting_file, 'w') 
                file.write(file_data.replace('<setting id="m3uUrl" value="%s/>'%m,'<setting id="m3uUrl" value="%s"/>'%m3u))
                file.close()



                file = open(setting_file, 'r') 
                file_data= file.read()
                file.close()
                regex='<setting id="epgUrl" value="(.+?)/>'
                m=re.compile(regex).findall(file_data)[0]
                file = open(setting_file, 'w') 
                file.write(file_data.replace('<setting id="epgUrl" value="%s/>'%m,'<setting id="epgUrl" value="%s"/>'%epg))
                file.close()
            else:
                file = open(setting_file, 'r', encoding='utf-8') 
                file_data= file.read()
                file.close()
                regex='<setting id="m3uUrl" default="(.+?)/>'
                m=re.compile(regex).findall(file_data)[0]
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data.replace('<setting id="m3uUrl" default="%s/>'%m,'<setting id="m3uUrl">%s</setting>'%m3u))
                file.close()



                file = open(setting_file, 'r', encoding='utf-8') 
                file_data= file.read()
                file.close()
                regex='<setting id="epgUrl" default="(.+?)/>'
                m=re.compile(regex).findall(file_data)[0]
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data.replace('<setting id="epgUrl" default="%s/>'%m,'<setting id="epgUrl">%s</setting>'%epg))
                file.close()
def sync_iptv2():
    
    all_db=read_firebase('iptvsimple')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['m3u'],items['epg']))
    for m3u,epg in data:
        pvr = xbmcaddon.Addon('pvr.iptvsimple')
        m3ulist=(pvr.getSetting("m3uUrl"))
        if m3ulist=='':
            DIALOG         = xbmcgui.Dialog()
            choice = DIALOG.yesno(ADDONTITLE, "קיים חשבון IPTV בענן, האם לשחזר אותו?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
            if choice == 1:
                setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "pvr.iptvsimple","settings.xml")
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'משחזר את חשבון ה IPTV שלך'),'[COLOR %s]הקודי יסגר בעוד 5 שניות[/COLOR]' % COLOR2)
                if KODI_VERSION<=18:
                    file = open(setting_file, 'r') 
                    file_data= file.read()
                    file.close()

                    regex='<setting id="m3uUrl" value="(.+?)/>'
                    m=re.compile(regex).findall(file_data)[0]
                    file = open(setting_file, 'w') 
                    file.write(file_data.replace('<setting id="m3uUrl" value="%s/>'%m,'<setting id="m3uUrl" value="%s"/>'%m3u))
                    file.close()



                    file = open(setting_file, 'r') 
                    file_data= file.read()
                    file.close()
                    regex='<setting id="epgUrl" value="(.+?)/>'
                    m=re.compile(regex).findall(file_data)[0]
                    file = open(setting_file, 'w') 
                    file.write(file_data.replace('<setting id="epgUrl" value="%s/>'%m,'<setting id="epgUrl" value="%s"/>'%epg))
                    file.close()
                else:
                    file = open(setting_file, 'r', encoding='utf-8') 
                    file_data= file.read()
                    file.close()
            # <setting id="m3uUrl">http://22/22</setting>
                    regex='<setting id="m3uUrl" default="(.+?)/>'
                    m=re.compile(regex).findall(file_data)[0]
                    file = open(setting_file, 'w', encoding='utf-8') 
                    file.write(file_data.replace('<setting id="m3uUrl" default="%s/>'%m,'<setting id="m3uUrl">%s</setting>'%m3u))
                    file.close()



                    file = open(setting_file, 'r', encoding='utf-8') 
                    file_data= file.read()
                    file.close()
                    regex='<setting id="epgUrl" default="(.+?)/>'
                    m=re.compile(regex).findall(file_data)[0]
                    file = open(setting_file, 'w', encoding='utf-8') 
                    file.write(file_data.replace('<setting id="epgUrl" default="%s/>'%m,'<setting id="epgUrl">%s</setting>'%epg))
                    file.close()
                    
                xbmc.sleep(5000)
                os._exit(1)

            else:
                sys.exit()

def sync_iptv_rd():
    try:
     sync_rd()
    except:pass
    
    try:
     sync_iptv()
    except:pass
    try:
     sync_favourite()
    except:pass
    try:
     firebase_mediasync()
    except:pass
    try:
     sync_trakt()
    except:pass
    
def firebase_favourite():
    setting_file=os.path.join(translatepath("special://userdata"),"favourites.xml")
    if KODI_VERSION<=18:
        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
    else:
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

    table_name='favourite'
    all_firebase=read_firebase(table_name)
    write_fire=True
    if not file_data =='':
        for items in all_firebase:
                delete_firebase(table_name,items)
        write_favourite(file_data,table_name)

def firebase_mediasync():
    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "plugin.program.mediasync","settings.xml")
    if KODI_VERSION<=18:
        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
    else:
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()

    table_name='mediasync'
    all_firebase=read_firebase(table_name)
    write_fire=True
    if not file_data =='':
        for items in all_firebase:
                delete_firebase(table_name,items)
        write_favourite(file_data,table_name)


def sync_favourite():
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]משחזר מועדפים[/COLOR]' % COLOR2)
        setting_file=os.path.join(translatepath("special://userdata"),"favourites.xml")
        all_db=read_firebase('favourite')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['favourite']))
        for file_data in data:
            if KODI_VERSION<=18:
                file = open(setting_file, 'w') 
                file.write(file_data)
                file.close()
            else:
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data)
                file.close()
def firebase_skin():
    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
    if KODI_VERSION<=18:
        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
    else:
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
    table_name='skin'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:

            delete_firebase(table_name,items)
    write_skin(file_data,table_name)

def sync_skin():
        setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")
        all_db=read_firebase('skin')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['skin']))
        for file_data in data:
            if KODI_VERSION<=18:
                file = open(setting_file, 'w') 
                file.write(file_data)
                file.close()
            else:
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data)
                file.close()
                
def firebase_guisettings():
    setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
    if KODI_VERSION<=18:
        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
    else:
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
    table_name='guisettings'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:

            delete_firebase(table_name,items)
    write_guisettings(file_data,table_name)
    
def sync_guisettings():
        setting_file=os.path.join(translatepath("special://userdata"),"guisettings.xml")
        all_db=read_firebase('guisettings')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['guisettings']))
        for file_data in data:
            if KODI_VERSION<=18:
                file = open(setting_file, 'w') 
                file.write(file_data)
                file.close()
            else:
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data)
                file.close()
def firebase_wizsettings():
    setting_file=os.path.join(translatepath("special://userdata/addon_data/plugin.program.Anonymous"),"settings.xml")
    if KODI_VERSION<=18:
        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
    else:
        file = open(setting_file, 'r', encoding='utf-8') 
        file_data= file.read()
        file.close()
    table_name='wizsettings'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:

            delete_firebase(table_name,items)
    write_wizsettings(file_data,table_name)

def sync_wizsettings():
        setting_file=os.path.join(translatepath("special://userdata/addon_data/plugin.program.Anonymous"),"settings.xml")
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        all_db=read_firebase('wizsettings')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['wizsettings']))
        for file_data in data:
            if KODI_VERSION<=18:
                file = open(setting_file, 'w') 
                file.write(file_data)
                file.close()
            else:
                file = open(setting_file, 'w', encoding='utf-8') 
                file.write(file_data)
                file.close()
            
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הגדרות ויזארד שוחזרו.[/COLOR]' % COLOR2)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
def sync_number_tele():
    
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס את מספר הטלפון שלך')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           if search_entered=='':
            sys.exit()
    table_name='tele'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:
           if search_entered=='':
            sys.exit()
           else:
            delete_firebase(table_name,items)
    Addon.setSetting("tele_number",search_entered)
    write_tele_number(search_entered,table_name)
def sync_code_tele():
    
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס את קוד האימות הדו שלבי שלך')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           if search_entered=='':
            sys.exit()
    table_name='telec'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:
           if search_entered=='':
            sys.exit()
           else:
            delete_firebase(table_name,items)
    Addon.setSetting("tele_code",search_entered)
    write_tele_code(search_entered,table_name)
def clear_tele():
    table_name='telec'
    table_name2='tele'
    all_firebase=read_firebase(table_name)
    all_firebase2=read_firebase(table_name2)
    for items in all_firebase:
     delete_firebase(table_name,items)
    for items in all_firebase2:
     delete_firebase(table_name2,items)
    Addon.setSetting('tele_code','')
    Addon.setSetting('tele_number','')
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]נוקה![/COLOR]' % COLOR2)
def firebase_tele_login():
    import base64
    import codecs
    login_file=os.path.join(translatepath("special://userdata"),"addon_data", "plugin.video.telemedia", "database","td.binlog")
    setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "plugin.video.telemedia", "settings.xml")
    file = open(setting_file, 'r') 
    file_data= file.read()
    file.close()
    file = open(login_file, 'r') 
    file_login= file.read()
    file.close()
    
    table_name='tele'
    all_firebase=read_firebase(table_name)
    write_fire=True
    
    for items in all_firebase:

            delete_firebase(table_name,items)
            
    write_tele_login(file_data,file_data,table_name)
# firebase_tele_login()
def sync_tele_login():
        import codecs
        login_file=os.path.join(translatepath("special://userdata"),"addon_data", "plugin.video.telemedia", "database","td.binlog")
        setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "plugin.video.telemedia", "settings.xml")
        all_db=read_firebase('tele_login')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['file_data'],items['file_login']))
        for file_data,file_login in data:

            file = open(setting_file, 'w') 
            file.write(file_data)
            file.close()
            file = open(login_file, 'w') 
            file.write(codecs.decode(file_login, 'utf-8'))
            file.close()
            
def get_telenum(tele):
        all_db=read_firebase('tele')
        data=[]
        for itt in all_db:
            items=all_db[itt]
            data.append((items['file_data']))
        for file_data in data:

            file_data=tele
        return
        
def firebase_test():

	try:
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "pvr.iptvsimple","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="epgUrl" type="bool(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="epgUrl" type="bool%s/setting>'%m,'<setting id="epgUrl" type="bool"></setting>'))
		file.close()
	except:
		pass
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png",description=' '):
 


          u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+(name)
          try:
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          except:
            liz = xbmcgui.ListItem( name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
          try:
           liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name),'plot':description   })
          except:
           liz.setInfo(type="Video", infoLabels={ "Title": urllib.parse.unquote( name),'plot':description   })
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def main_menu():
      addNolink('הכנס מזהה ID','www',7,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('סנכרן עכשיו','www',8,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('בטל סנכרון','www',9,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('גיבוי','www',3,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('שחזור','www',4,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('בחר ערוץ גיבוי','www',2,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')
      addNolink('הגדרות','www',5,False,iconimage=LOGO+'play.png',fanart='https://images2.alphacoders.com/589/thumb-1920-589553.png')

def do_bakcup_silent(silent='True'):
  global Pass
  
  if Addon.getSetting("bot_id")=='' or Addon.getSetting("user_name")=='':
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא הוגדר שם למכשיר או ערוץ לסנכרון[/COLOR]' % COLOR2)
    if Addon.getSetting("user_name")=='':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
    if Addon.getSetting("bot_id")=='':
     
      set_bot_id()
  else:
   
    logging.warning('silent')
    logging.warning(silent)
    # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מסנכרן[/COLOR]' % COLOR2)

    import datetime,os
    from shutil import copyfile
    from os.path import basename
    if silent=='False':
        logging.warning('silent2')
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מתחבר לשרת', '','')
        dp.update(0, 'אנא המתן','מכווץ', '' )
    exclude_files = ['xmltv.xml.cache']
    tele=os.path.join(translatepath('special://profile/addon_data/plugin.video.telemedia'))
    databasetele=os.path.join(tele, 'database.db')
    databasetele2=os.path.join(tele, 'cache_play.db')
    databasetele3=os.path.join(tele, 'skipintro.json')
    
    
    torrent=os.path.join(translatepath('special://profile/addon_data/plugin.video.torrent'))
    databasetorrent=os.path.join(torrent, 'settings.xml')
    databasetorrent2=os.path.join(torrent, 'cache_play.db')
    
    
    mando=os.path.join(translatepath('special://profile/addon_data/plugin.video.mando'))
    databasemando=os.path.join(mando, 'database.db')
    databasemando2=os.path.join(mando, 'cache_play.db')
    databasemando3=os.path.join(mando, 'settings.xml')
    
    myfav=os.path.join(translatepath('special://profile/addon_data/context.myfav'))
    myfav2=os.path.join(myfav, 'cache_play.db')
    myfav3=os.path.join(myfav, 'settings.xml')
    
    
    shadow=os.path.join(translatepath('special://profile/addon_data/plugin.video.shadow'))
    databaseshadow=os.path.join(shadow, 'database.db')
    databaseshadow2=os.path.join(shadow, 'cache_play.db')
    databaseshadow3=os.path.join(shadow, 'settings.xml')
    

    iptvsimple=os.path.join(translatepath('special://profile/addon_data/pvr.iptvsimple'))

    
    resolveurl=os.path.join(translatepath('special://profile/addon_data/script.module.resolveurl'))
    resolveurlsettings=os.path.join(resolveurl, 'settings.xml')

    seren=os.path.join(translatepath('special://profile/addon_data/plugin.video.seren'))
    serensettings=os.path.join(seren, 'settings.xml')
    
    exodusredux=os.path.join(translatepath('special://profile/addon_data/plugin.video.exodusredux'))
    exodusreduxsettings=os.path.join(exodusredux, 'settings.xml')
    exodusreduxbookmarks=os.path.join(exodusredux, 'bookmarks.db')
    last_played=os.path.join(translatepath('special://profile/addon_data/plugin.video.last_played'))
    
    
    thecrew=os.path.join(translatepath('special://profile/addon_data/plugin.video.thecrew'))
    thecrewsettings=os.path.join(thecrew, 'settings.xml')
    thecrewbookmarks=os.path.join(thecrew, 'bookmarks.db')


    favourites=os.path.join(translatepath('special://profile'))
    favouritesfile=os.path.join(favourites, 'favourites.xml')

    guisettings=os.path.join(translatepath('special://profile'))
    guisettingsfile=os.path.join(guisettings, 'guisettings.xml')


    Database=os.path.join(translatepath('special://profile/Database'))
    DatabaseView=os.path.join(Database, 'ViewModes6.db')
    DatabaseVideos=os.path.join(Database, 'MyVideos107.db')
    DatabaseVideos18=os.path.join(Database, 'MyVideos116.db')

    skinshortcuts=os.path.join(translatepath('special://profile/addon_data/script.skinshortcuts'))

    username=Addon.getSetting("user_name")
    
#"%Y,%m,%d,%H,%M,%S"
    zp_file=os.path.join(user_dataDir,str(time.strftime("%d/%m/%Y").replace('/','.')+' שעה '+str(time.strftime("%H/%M").replace('/',':')+' '+username +'.zip')))
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    zipf = zipfile.ZipFile(zp_file , mode='w')
    
    
    dirname=os.path.join(translatepath('special://profile'))
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasetele,databasetele[len(dirname):])
        except:pass
        try:
         zipf.write(databasetele3,databasetele3[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasetele2,databasetele2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasemando,databasemando[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasemando2,databasemando2[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databasetorrent,databasetorrent[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasetorrent2,databasetorrent2[len(dirname):])
        except:pass
        
        
        
        
        
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databasemando3,databasemando3[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databaseshadow,databaseshadow[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databaseshadow2,databaseshadow2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databaseshadow3,databaseshadow3[len(dirname):])
        except:pass
        
        
      
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(resolveurlsettings,resolveurlsettings[len(dirname):])
        except:pass
        try:
         zipf.write(serensettings,serensettings[len(dirname):])
        except:pass
        try:
         zipf.write(exodusreduxsettings,exodusreduxsettings[len(dirname):])
        except:pass
        try:
         zipf.write(thecrewsettings,thecrewsettings[len(dirname):])
        except:pass
    if Addon.getSetting("sync_favo")=='true':
        try:
         zipf.write(favouritesfile,favouritesfile[len(dirname):])
        except:pass
    if Addon.getSetting("sync_display")=='true':
        try:
         zipf.write(DatabaseView,DatabaseView[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(DatabaseVideos,DatabaseVideos[len(dirname):])
        except:pass
        try:
         zipf.write(DatabaseVideos18,DatabaseVideos18[len(dirname):])
        except:pass
        try:
         zipf.write(exodusreduxbookmarks,exodusreduxbookmarks[len(dirname):])
        except:pass
        try:
         zipf.write(thecrewbookmarks,thecrewbookmarks[len(dirname):])
        except:pass
    if Addon.getSetting("guisettings")=='true':
        try:
         zipf.write(guisettingsfile,guisettingsfile[len(dirname):])
        except:pass
        
        
    if Addon.getSetting("sync_skinshortcuts")=='true':
       for base, dirs, files in os.walk(skinshortcuts):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_lastview")=='true':
       for base, dirs, files in os.walk(last_played):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_iptv")=='true':
       for base, dirs, files in os.walk(iptvsimple):
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass

    
    zipf.close()
    

    
    
    from os.path import basename
    if Addon.getSetting("remote_selection")=='0':
        onlyfiles=[]
        db_bk_folder=translatepath(Addon.getSetting("remote_path"))
        dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
      
        ct_min=0
        
            
        count=0
        for files in onlyfiles:
            f_patch_file=os.path.join(db_bk_folder,files)
            if Addon.getSetting("db_bk_name") in basename(files):
                count+=1
        
        if count>5:
            for files in onlyfiles:
                f_file=(os.path.join(db_bk_folder,files))
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                logging.warning(ct_date)
                #ct_date=time.ctime(os.path.getctime(f_file))
                if ct_min==0:
                    ct_min=ct_date
                elif ct_date<ct_min:
                    ct_min=ct_date
            
            for files in onlyfiles:
                f_file=os.path.join(db_bk_folder,files)
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                #ct_date=time.ctime(os.path.getctime(f_file))
               
                if ct_date==ct_min:
                   
                    xbmcvfs.delete(f_file)
                    break
        xbmcvfs.copy (zp_file,os.path.join(db_bk_folder,Addon.getSetting("db_bk_name")+'_'+str(time.strftime("%d/%m/%Y")).replace('/','_')))
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
    elif Addon.getSetting("remote_selection")=='1':
        if silent=='False':
            dp.update(20, 'אנא המתן','מתחבר לשרת', '' )
        import ftplib
        import os,urllib
        from datetime import datetime
        import _strptime
            
        server=Addon.getSetting("ftp_host")
        username=Addon.getSetting("ftp_user")
        password=Addon.getSetting("ftp_pass")
        try:
            myFTP = ftplib.FTP(server, username, password)
            if silent=='False':
                dp.update(40, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            if silent=='False':
                dp.update(60, 'אנא המתן','אוסף קבצים', '' )
            for f in files:
                
               
                
                if 'kodi_backup' in f:
                    found=1
                    
            if found==0:
                myFTP.mkd('kodi_backup')
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            for f in files:
                
                if Addon.getSetting("db_bk_name") in basename(f):
                    count+=1
            if count>5:
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
                    try:
                        modifiedTime = myFTP.sendcmd('MDTM ' + f)
                       
                        
                        #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        try:
                            ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        except TypeError:
                            ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                            ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                        
                        if ct_min==0:
                            ct_min=ct_date
                        elif ct_date<ct_min:
                            ct_min=ct_date
                    except Exception as e:
                        logging.warning(e)
                        pass
             
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
            
                    modifiedTime = myFTP.sendcmd('MDTM ' + f)
          
             
                    
                    #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    try:
                        ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    except TypeError:
                        ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                        ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                   
                    if ct_date==ct_min:
                    
                        
                        myFTP.delete(f)
                        break
            if silent=='False':
                dp.update(80, 'אנא המתן','מעלה לשרת', '' )
            uploadThis(zp_file,myFTP)
            
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
        except Exception as e:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'שגיאה בגיבוי לשרת בדוק הגדרות'.decode('utf8'))).encode('utf-8'))
    else:
        import requests
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        selected_group_id=Addon.getSetting("bot_id")
        num2=random.randint(0,60000)
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
                 }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        exit_now=0
        try:
            if 'status' in event:
                xbmcgui.Dialog().ok('Error occurred',str(event['status']))
                exit_now=1
        except:pass
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': zp_file}},'@extra': 1 })
                     }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        xbmc.sleep(10000)
        # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוצע![/COLOR]' % COLOR2)
    try:
        xbmc.sleep(1000)
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    except:
        pass
    if silent=='False':
        dp.close()
    logging.warning('Done backing up')
def do_bakcup(silent='True'):
  global Pass
  if Addon.getSetting("bot_id")=='' or Addon.getSetting("user_name")=='':
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא הוגדר שם למכשיר או ערוץ לסנכרון[/COLOR]' % COLOR2)
    if Addon.getSetting("user_name")=='':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
    if Addon.getSetting("bot_id")=='':
     
      set_bot_id()
  else:
   
    # logging.warning('silent')
    # logging.warning(silent)
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מגבה[/COLOR]' % COLOR2)

    import datetime,os
    from shutil import copyfile
    from os.path import basename
    if silent=='False':
        logging.warning('silent2')
        dp = xbmcgui . DialogProgress ( )
        try:
            dp.create('אנא המתן','מתחבר לשרת', '','')
            dp.update(0, 'אנא המתן','מכווץ', '' )
        except:
            dp.create('אנא המתן','מתחבר לשרת')
            dp.update(0,'מכווץ' )
    exclude_files = ['xmltv.xml.cache']
    tele=os.path.join(translatepath('special://profile/addon_data/plugin.video.telemedia'))
    databasetele=os.path.join(tele, 'database.db')
    databasetele2=os.path.join(tele, 'cache_play.db')
    databasetele3=os.path.join(tele, 'skipintro.json')
    
    
    torrent=os.path.join(translatepath('special://profile/addon_data/plugin.video.torrent'))
    databasetorrent=os.path.join(torrent, 'settings.xml')
    databasetorrent2=os.path.join(torrent, 'cache_play.db')
    
    
    mando=os.path.join(translatepath('special://profile/addon_data/plugin.video.mando'))
    databasemando=os.path.join(mando, 'database.db')
    databasemando2=os.path.join(mando, 'cache_play.db')
    databasemando3=os.path.join(mando, 'settings.xml')
    
    myfav=os.path.join(translatepath('special://profile/addon_data/context.myfav'))
    myfav2=os.path.join(myfav, 'cache_play.db')
    myfav3=os.path.join(myfav, 'settings.xml')
    
    shadow=os.path.join(translatepath('special://profile/addon_data/plugin.video.shadow'))
    databaseshadow=os.path.join(shadow, 'database.db')
    databaseshadow2=os.path.join(shadow, 'cache_play.db')
    databaseshadow3=os.path.join(shadow, 'settings.xml')
    

    iptvsimple=os.path.join(translatepath('special://profile/addon_data/pvr.iptvsimple'))

    
    resolveurl=os.path.join(translatepath('special://profile/addon_data/script.module.resolveurl'))
    resolveurlsettings=os.path.join(resolveurl, 'settings.xml')

    seren=os.path.join(translatepath('special://profile/addon_data/plugin.video.seren'))
    serensettings=os.path.join(seren, 'settings.xml')
    
    exodusredux=os.path.join(translatepath('special://profile/addon_data/plugin.video.exodusredux'))
    exodusreduxsettings=os.path.join(exodusredux, 'settings.xml')
    exodusreduxbookmarks=os.path.join(exodusredux, 'bookmarks.db')
    last_played=os.path.join(translatepath('special://profile/addon_data/plugin.video.last_played'))

    thecrew=os.path.join(translatepath('special://profile/addon_data/plugin.video.thecrew'))
    thecrewsettings=os.path.join(thecrew, 'settings.xml')
    thecrewbookmarks=os.path.join(thecrew, 'bookmarks.db')

    favourites=os.path.join(translatepath('special://profile'))
    favouritesfile=os.path.join(favourites, 'favourites.xml')

    guisettings=os.path.join(translatepath('special://profile'))
    guisettingsfile=os.path.join(guisettings, 'guisettings.xml')


    Database=os.path.join(translatepath('special://profile/Database'))
    DatabaseView=os.path.join(Database, 'ViewModes6.db')
    DatabaseVideos=os.path.join(Database, 'MyVideos107.db')
    DatabaseVideos18=os.path.join(Database, 'MyVideos116.db')

    skinshortcuts=os.path.join(translatepath('special://profile/addon_data/script.skinshortcuts'))

    username=Addon.getSetting("user_name")
    
#"%Y,%m,%d,%H,%M,%S"
    zp_file=os.path.join(user_dataDir,str(time.strftime("%d/%m/%Y").replace('/','.')+' שעה '+str(time.strftime("%H/%M").replace('/',':')+' '+username +'.zip')))
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    zipf = zipfile.ZipFile(zp_file , mode='w')
    
    
    dirname=os.path.join(translatepath('special://profile'))
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasetele,databasetele[len(dirname):])
        except:pass
        try:
         zipf.write(databasetele3,databasetele3[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasetele2,databasetele2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databasemando,databasemando[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasemando2,databasemando2[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databasetorrent,databasetorrent[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databasetorrent2,databasetorrent2[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databasemando3,databasemando3[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_tvshow")=='true':
        try:
         zipf.write(databaseshadow,databaseshadow[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(databaseshadow2,databaseshadow2[len(dirname):])
        except:pass
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(databaseshadow3,databaseshadow3[len(dirname):])
        except:pass
        
    if Addon.getSetting("sync_rd")=='true':
        try:
         zipf.write(resolveurlsettings,resolveurlsettings[len(dirname):])
        except:pass
        try:
         zipf.write(serensettings,serensettings[len(dirname):])
        except:pass
        try:
         zipf.write(exodusreduxsettings,exodusreduxsettings[len(dirname):])
        except:pass
        try:
         zipf.write(thecrewsettings,thecrewsettings[len(dirname):])
        except:pass
    if Addon.getSetting("sync_favo")=='true':
        try:
         zipf.write(favouritesfile,favouritesfile[len(dirname):])
        except:pass
        try:
         zipf.write(myfav2,myfav2[len(dirname):])
        except:pass
        try:
         zipf.write(myfav3,myfav3[len(dirname):])
        
        except:pass
    if Addon.getSetting("sync_display")=='true':
        try:
         zipf.write(DatabaseView,DatabaseView[len(dirname):])
        except:pass
    if Addon.getSetting("sync_lastview")=='true':
        try:
         zipf.write(DatabaseVideos,DatabaseVideos[len(dirname):])
        except:pass
        try:
         zipf.write(DatabaseVideos18,DatabaseVideos18[len(dirname):])
        except:pass
        try:
         zipf.write(exodusreduxbookmarks,exodusreduxbookmarks[len(dirname):])
        except:pass
        try:
         zipf.write(thecrewbookmarks,thecrewbookmarks[len(dirname):])
        except:pass
    if Addon.getSetting("guisettings")=='true':
        try:
         zipf.write(guisettingsfile,guisettingsfile[len(dirname):])
        except:pass
        
        
    if Addon.getSetting("sync_skinshortcuts")=='true':
       for base, dirs, files in os.walk(skinshortcuts):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_lastview")=='true':
       for base, dirs, files in os.walk(last_played):
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass
    if Addon.getSetting("sync_iptv")=='true':
       for base, dirs, files in os.walk(iptvsimple):
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
         fn = os.path.join(base, file)
         try:
          zipf.write(fn,fn[len(dirname):])
         except:pass

    
    zipf.close()
    
    from os.path import basename
    if Addon.getSetting("remote_selection")=='0':
        onlyfiles=[]
        db_bk_folder=translatepath(Addon.getSetting("remote_path"))
        dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
      
        ct_min=0
        
            
        count=0
        for files in onlyfiles:
            f_patch_file=os.path.join(db_bk_folder,files)
            if Addon.getSetting("db_bk_name") in basename(files):
                count+=1
        
        if count>5:
            for files in onlyfiles:
                f_file=(os.path.join(db_bk_folder,files))
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                logging.warning(ct_date)
                #ct_date=time.ctime(os.path.getctime(f_file))
                if ct_min==0:
                    ct_min=ct_date
                elif ct_date<ct_min:
                    ct_min=ct_date
            
            for files in onlyfiles:
                f_file=os.path.join(db_bk_folder,files)
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                #ct_date=time.ctime(os.path.getctime(f_file))
               
                if ct_date==ct_min:
                   
                    xbmcvfs.delete(f_file)
                    break
        xbmcvfs.copy (zp_file,os.path.join(db_bk_folder,Addon.getSetting("db_bk_name")+'_'+str(time.strftime("%d/%m/%Y")).replace('/','_')))
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
    elif Addon.getSetting("remote_selection")=='1':
        if silent=='False':
            dp.update(20, 'אנא המתן','מתחבר לשרת', '' )
        import ftplib
        import os,urllib
        from datetime import datetime
        import _strptime
            
        server=Addon.getSetting("ftp_host")
        username=Addon.getSetting("ftp_user")
        password=Addon.getSetting("ftp_pass")
        try:
            myFTP = ftplib.FTP(server, username, password)
            if silent=='False':
                dp.update(40, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            if silent=='False':
                dp.update(60, 'אנא המתן','אוסף קבצים', '' )
            for f in files:
                
               
                
                if 'kodi_backup' in f:
                    found=1
                    
            if found==0:
                myFTP.mkd('kodi_backup')
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            for f in files:
                
                if Addon.getSetting("db_bk_name") in basename(f):
                    count+=1
            if count>5:
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
                    try:
                        modifiedTime = myFTP.sendcmd('MDTM ' + f)
                       
                        
                        #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        try:
                            ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        except TypeError:
                            ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                            ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                        
                        if ct_min==0:
                            ct_min=ct_date
                        elif ct_date<ct_min:
                            ct_min=ct_date
                    except Exception as e:
                        logging.warning(e)
                        pass
             
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
            
                    modifiedTime = myFTP.sendcmd('MDTM ' + f)
          
             
                    
                    #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    try:
                        ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    except TypeError:
                        ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                        ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                   
                    if ct_date==ct_min:
                    
                        
                        myFTP.delete(f)
                        break
            if silent=='False':
                dp.update(80, 'אנא המתן','מעלה לשרת', '' )
            uploadThis(zp_file,myFTP)
            
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
        except Exception as e:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'שגיאה בגיבוי לשרת בדוק הגדרות'.decode('utf8'))).encode('utf-8'))
    else:
        import requests
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        selected_group_id=Addon.getSetting("bot_id")
        num2=random.randint(0,60000)
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
                 }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        exit_now=0

        if 'status' in event:
            xbmcgui.Dialog().ok('Error occurred',event['status'])
            exit_now=1
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': zp_file}},'@extra': 1 })
                     }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        xbmc.sleep(10000)
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]גיבוי בוצע![/COLOR]' % COLOR2)
    try:
        xbmc.sleep(1000)
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    except:
        pass
    if silent=='False':
        dp.close()
    logging.warning('Done backing up')
def uploadThis(f,myFTP):
    from os.path import basename
    fh = open(f, 'rb')
    myFTP.storbinary('STOR %s' % Addon.getSetting("db_bk_name")+'1_'+str(time.strftime("%d/%m/%Y")).replace('/','_'), fh)
    fh.close()
def unzip(file,path):
       
        # from resources.libs.zfile import ZipFile

        
        zip_file = file
        ptp = 'Masterpenpass'
        zf=zipfile.ZipFile(zip_file)
        logging.warning('Extracting')
        listOfFileNames = zf.namelist()
        # Iterate over the file names
        for fileName in listOfFileNames:
            logging.warning(fileName)
        #zf.setpassword(bytes(ptp))
        #with ZipFile(zip_file) as zf:
        #zf.extractall(path)
        with zipfile.ZipFile(zip_file, 'r') as zipObj:
           # Extract all the contents of zip file in current directory
           zipObj.extractall(path)
def restore_backup():
  if Addon.getSetting("bot_id")=='' or Addon.getSetting("user_name")=='':
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא הוגדר שם מכשיר או ערוץ לגיבוי[/COLOR]' % COLOR2)
    if Addon.getSetting("user_name")=='':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס שם למכשיר')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon.setSetting('user_name', str(search_entered))
    if Addon.getSetting("bot_id")=='':
   
      set_bot_id()
  else:
    import random
    from shutil import copyfile
    import os
    if 1:#try:
        cacheFile = os.path.join(user_dataDir, 'cache_play.db')
        zp_file= os.path.join(user_dataDir, 'data.zip')
        from os.path import basename
        if Addon.getSetting("remote_selection")=='0':
           
            onlyfiles=[]
            db_bk_folder=translatepath(Addon.getSetting("remote_path"))
            dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
            
    
            all_n=[]
            all_f=[]
            for f in onlyfiles:
                all_n.append(basename(f))
                all_f.append(os.path.join(db_bk_folder,f))
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    db_name=Addon.getSetting('db_bk_name')
                    if '.db' not in all_n[ret]:
                        xbmcvfs.copy(all_f[ret],os.path.join(user_dataDir,'temp_zip'))
                        unzip(os.path.join(user_dataDir,'temp_zip'),user_dataDir)
                        xbmcvfs.delete(os.path.join(user_dataDir,'temp_zip'))
                    else:
                        xbmcvfs.copy(all_f[ret],cacheFile)
                    #xbmc.executebuiltin('Container.Update')
                    #Addon.setSetting('db_bk_name',db_name)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שחזור בוצע בהצלחה![/COLOR]' % COLOR2)
            else:
               sys.exit()
        elif Addon.getSetting("remote_selection")=='1':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','מתחבר לשרת', '','')
            dp.update(0, 'אנא המתן','מתחבר לשרת', '' )
            import ftplib
            import os,urllib
            from datetime import datetime
            server=Addon.getSetting("ftp_host")
            username=Addon.getSetting("ftp_user")
            password=Addon.getSetting("ftp_pass")
            try:
            
              myFTP = ftplib.FTP(server, username, password)
            except Exception as e:
               xbmcgui.Dialog().ok('שגיאת התחברות',str(e))
               sys.exit()
            dp.update(0, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            for f in files:
         
                if 'kodi_backup' in f:
                    found=1
            if found==0:
            
                xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR red][I]לא קיימים גיבויים[/I][/COLOR]')
                sys.exit()
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            all_n=[]
            all_f=[]
            dp.update(0, 'אנא המתן','אוסף קבצים', '' )
            for f in files:

                all_n.append(basename(f))
                all_f.append(f)
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    
                    db_name=Addon.getSetting('db_bk_name')
                    i=cacheFile
                    dp.update(0, 'אנא המתן','מוריד קובץ', '' )
                    myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    dp.close()
                    if '.db' not in all_n[ret]:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(zp_file, 'wb').write)
                        unzip(zp_file,user_dataDir)
                    else:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    Addon.setSetting('db_bk_name',db_name)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שחזור בוצע בהצלחה![/COLOR]' % COLOR2)
            else:
               sys.exit()
        else:
            import requests
            resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
            listen_port=resuaddon.getSetting('port')
            selected_group_id=Addon.getSetting("bot_id")
            num=random.randint(1,1001)
            
            

            num2=random.randint(0,60000)
            data={'type':'td_send',
                     'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num2})
                     }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            exit_now=0

            if 'status' in event:
                xbmcgui.Dialog().ok('Error occurred',event['status'])
                exit_now=1
            
            
            
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(selected_group_id), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }

           
         
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            all_n=[]
            all_ids=[]



            for items in event['messages']:
                file_name=items['content']['document']['file_name']
                all_n.append(file_name.replace('.zip',''))
                all_ids.append(str(items['content']['document']['document']['id']))
            ret = xbmcgui.Dialog().select("בחר תאריך סנכרון", all_n)
            if ret!=-1 :
                # ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                # if ok:
                    data={'type':'download_photo',
                             'info':all_ids[ret]
                             }
                    logging.warning('Sending')
                    
                    file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    logging.warning('file:'+file)
                    xbmc.sleep(100)
                    dirname=os.path.join(translatepath('special://profile'))
                    unzip(file,dirname)
                    xbmcvfs.delete(file)
                    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שחזור בוצע בהצלחה![/COLOR]' % COLOR2)
            else:
             xbmc.log( "Sync Is: %s." % ('המתן') , 5)

                        
        if os.path.isfile(zp_file):
            os.remove(zp_file)
        if Addon.getSetting("guisettings")=='true':
            Addon.setSetting('guisettings','false')
            DP = xbmcgui.DialogProgress()
            DP.create("להלשמת הפעולה הקודי יסגר ", "אנא המתן 5 שניות", '',
            
            "[COLOR orange][B]מסיים פעולות[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                DP.update(int((5 - s) / 5.0 * 100), "הקודי יסגר", 'בעוד {0} שניות'.format(s), '')
                if DP.iscanceled():
                    os._exit(1)
                    return None, None
            os._exit(1)
         # os._exit(1)
    #except Exception as e:
    #    xbmcgui.Dialog().ok('תקלה','[COLOR red] בדוק את הגדרות ההרחבה [/COLOR]'+str(e))
    
    try:
        dp.close()
    except:
        pass
def backup_vik():
    import datetime
    strptime = datetime.datetime.strptime
    logging.warning('backing up')
    threading.Thread(target=do_bakcup).start()
    return '1'
def set_bot_id():
    import requests
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        names=[]
        ids=[]
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            order=event['positions'][0]['order']
            
           
                         
                          
            j_enent=(event)
            
            
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
              
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("בחר ערוץ בו ישמר המידע", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            Addon.setSetting('bot_id',str(ids[ret]))
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ערוץ הגיבוי הוגדר![/COLOR]' % COLOR2)
    # do_bakcup(silent='True')


# resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
# listen_port=resuaddon.getSetting('port')
# num=random.randint(0,60000)
# data={'type':'td_send',
         # 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
         # }
# event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
# exit_now=0

# if 'status' in event:
    # xbmcgui.Dialog().ok('Error occurred',event['status'])
    # exit_now=1



params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

#######################################    ^
# Manual Mode Old Method (For Pussies)#    |
#######################################    |


##########################################
	
try:
        url= unque(params["url"])
       
except:
        pass
try:

        name=unque(params["name"])
except:
        pass
try:
        iconimage= unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass
        

if mode==None or url==None or len(url)<1 and len(sys.argv)>1:
        main_menu()
elif mode==2:
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]טוען רשימה אנא המתן...[/COLOR]' % COLOR2)
    import requests
    try:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:


       set_bot_id()
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==3:
    import requests
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:
      do_bakcup(silent=url)
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==4:
    import requests
    try:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:
      restore_backup()
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן שטלמדיה תתחבר[/COLOR]' % COLOR2)
elif mode==5:
    
   Addon.openSettings()
elif mode==6:
    import requests
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source is True:
      do_bakcup_silent(silent=url)
    else: 
     xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")
elif mode==7: 
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מזהה ID')
    keyboard.doModal()
    if keyboard.isConfirmed():
     search_entered = keyboard.getText()
     try:
        Addon.setSetting('firebase',search_entered)
     except:pass
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
        sync_tele.setSetting('firebase',search_entered)
        sync_tele.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
        sync_mando.setSetting('firebase',search_entered)
        sync_mando.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.wallmovie')):
        sync_wallmovie=xbmcaddon.Addon('plugin.video.wallmovie')
        sync_wallmovie.setSetting('firebase',search_entered)
        sync_wallmovie.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.kids_new')):
        sync_kids_new=xbmcaddon.Addon('plugin.video.kids_new')
        sync_kids_new.setSetting('firebase',search_entered)
        sync_kids_new.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.thorrent')):
        sync_torrent=xbmcaddon.Addon('plugin.video.thorrent')
        sync_torrent.setSetting('firebase',search_entered)
        sync_torrent.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'context.myfav')):
        sync_myfav=xbmcaddon.Addon('context.myfav')
        sync_myfav.setSetting('firebase',search_entered)
        sync_myfav.setSetting('sync_mod','true')
    if os.path.exists(os.path.join(ADDONS, 'script.module.xtvsh')):
        sync_xtvsh=xbmcaddon.Addon('script.module.xtvsh')
        sync_xtvsh.setSetting('firebase',search_entered)
        sync_xtvsh.setSetting('sync_mod','true')
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מזהה ID הוכנס![/COLOR]' % COLOR2)
    check_firebase()
    sys.exit()

elif mode==8: 
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מסנכרן, אנא המתן.[/COLOR]' % COLOR2)
    xx=Addon.getSetting("firebase")
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
        sync_tele.setSetting('sync_mod','true')
        sync_tele.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=183&url=www)")
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
        sync_mando.setSetting('sync_mod','true')
        sync_mando.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=198&url=www)")
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.wallmovie')):
        sync_wallmovie=xbmcaddon.Addon('plugin.video.wallmovie')
        sync_wallmovie.setSetting('sync_mod','true')
        sync_wallmovie.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.wallmovie?mode=67&url=www)")
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.kids_new')):
        sync_kids_new=xbmcaddon.Addon('plugin.video.kids_new')
        sync_kids_new.setSetting('sync_mod','true')
        sync_kids_new.setSetting('firebase',xx)
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.thorrent')):
        sync_torrent=xbmcaddon.Addon('plugin.video.thorrent')
        sync_torrent.setSetting('sync_mod','true')
        sync_torrent.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thorrent?mode=198&url=www)")
    if os.path.exists(os.path.join(ADDONS, 'context.myfav')):
        sync_myfav=xbmcaddon.Addon('context.myfav')
        sync_myfav.setSetting('sync_mod','true')
        sync_myfav.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=11&url=www)")
    if os.path.exists(os.path.join(ADDONS, 'script.module.xtvsh')):
        sync_xtvsh=xbmcaddon.Addon('script.module.xtvsh')
        sync_xtvsh.setSetting('sync_mod','true')
        sync_xtvsh.setSetting('firebase',xx)
        xbmc.executebuiltin("RunPlugin(plugin://script.module.xtvsh?mode=19&url=www)")
    firebase_rd()
    firebase_trakt()
    firebase_iptv()
    try:
     firebase_skin()
    except:pass
    try:
     sync_rd()
    except:pass
    try:
     sync_trakt()
    except:pass
    
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הסנכרון הסתיים.[/COLOR]' % COLOR2)
    sys.exit()
elif mode==9: 
    Addon.setSetting('firebase','')
    try:
        sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
    except:pass
    try:
        sync_mando=xbmcaddon.Addon('plugin.video.mando')
    except:pass
    try:
        sync_wallmovie=xbmcaddon.Addon('plugin.video.wallmovie')
    except:pass
    try:
        sync_kids_new=xbmcaddon.Addon('plugin.video.kids_new')
    except:pass
    try:
        sync_torrent=xbmcaddon.Addon('plugin.video.thorrent')
    except:pass
    try:
        sync_myfav=xbmcaddon.Addon('context.myfav')
    except:pass
    try:
        sync_xtvsh=xbmcaddon.Addon('script.module.xtvsh')
    except:pass
    try:
        sync_tele.setSetting('sync_mod','false')
    except:pass
    try:
        sync_mando.setSetting('sync_mod','false')
    except:pass
    try:
        sync_wallmovie.setSetting('sync_mod','false')
    except:pass
    try:
        sync_kids_new.setSetting('sync_mod','false')
    except:pass
    try:
        sync_torrent.setSetting('sync_mod','false')
    except:pass
    try:
        sync_myfav.setSetting('sync_mod','false')
    except:pass
    try:
        sync_xtvsh.setSetting('sync_mod','false')
    except:pass
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סנכרון בוטל[/COLOR]' % COLOR2)
    sys.exit()
elif mode==10: 
    sync_iptv_rd()
elif mode==11: 
    firebase_rd()
elif mode==12: 
    # service = False
    # days = [TODAY, TOMORROW,TWODAYS, THREEDAYS, ONEWEEK]
    # feq = int(float(AUTOFEQ))
    # if AUTONEXTRUN <= str(TODAY) or feq == 0:
        # service = True
        # next_run = days[feq]
        # Addon.setSetting('next_sync', str(next_run))

    # if service == True:
    # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מסנכרן נתונים מהענן.[/COLOR]' % COLOR2)
    while xbmc.Player().isPlaying():
        time.sleep(60)
    try:
     firebase_skin()
    except:pass
    try:
     firebase_mediasync()
    except:pass
    try:
     firebase_guisettings()
    except:pass
    try:
     firebase_iptv()
    except:pass
    try:
     firebase_wizsettings()
    except:pass
     
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=200&url=www)")
    if os.path.exists(translatepath("special://home/addons/") + 'context.myfav'):
        xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=15&url=www)")
elif mode==13: 
    sync_skin()
elif mode==14: 
    sync_number_tele()
elif mode==15: 
    sync_code_tele()
elif mode==16: 
    Addon.openSettings()
elif mode==17: 
    clear_tele()
elif mode==18: 
    try:
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno('גיבוי מועדפים', "האם לגבות את המועדפים?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
        if choice == 1:
             LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגבה'),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
             firebase_favourite()
             # firebase_mediasync()
             LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'מגבה'),'[COLOR %s]גיבוי הושלם.[/COLOR]' % COLOR2)
        else:
         sys.exit()
    except:pass
elif mode==19: 
    try:
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno('שחזור מועדפים', "האם לשחזר את המועדפים?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
        if choice == 1:
             LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'משחזר מועדפים'),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
             sync_favourite()
     # firebase_mediasync()
             LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'שחזור הושלם.'),'[COLOR %s]להשלמת הפעולה הקודי יסגר בעוד 3 שניות.[/COLOR]' % COLOR2)
             xbmc.sleep(3000)
             os._exit(1)
        else:
         sys.exit()
    except:pass
elif mode==20: 
    firebase_trakt()
elif mode==21: 
    sync_guisettings()
elif mode==22: 
   try:
    sync_iptv2()
   except:pass

elif mode==24: # מופעל על ידי הויזארד בהתקנה חדשה
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=200&url=www)")
    xbmc.executebuiltin("RunPlugin(plugin://script.module.xtvsh?mode=19&url=www)")
    if os.path.exists(translatepath("special://home/addons/") + 'context.myfav'):
                xbmc.executebuiltin("RunPlugin(plugin://context.myfav?mode=15&url=www)")
elif mode==25: 
    sync_wizsettings()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
