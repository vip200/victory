# -*- coding: utf-8 -*-
import xbmcgui,xbmcaddon,time
import _strptime,xbmcvfs

Addon = xbmcaddon.Addon()

start_time_start=time.time()
time_data=[]
import xbmcaddon,os,xbmc,urllib,re,xbmcplugin,sys
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
from resources.modules import log,sub
from pyparsing import my1,my2,my3,my4,my5,sport,tvall,music
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
else:
    import xbmcvfs
    xbmc_tranlate_path=xbmcvfs.translatePath
COLOR1         = 'gold'
COLOR2         = 'white'
DIALOG         = xbmcgui.Dialog()
dir_path = os.path.dirname(os.path.realpath(__file__))
mando_icon=os.path.join(dir_path,'icon.png')
ADDONTITLE='Mando 2'
def LogNotify(title, message, times=2000, icon=mando_icon,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
import threading,json

from resources.modules import public
from resources.modules import tmdbn
sort_by_episode=False
from_seek=False
all_jen_links=[]
play_status_rd_ext=''
break_window_rd=False
break_window=False
play_status=''
infoDialog_counter_close=False
all_other_sources_uni={}
aa_results={}
avg_f=''
stop_cpu=False

tvdb_results=[]
done1=0
done1_1=0
wait_for_subs=''
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
stop_window=False

once_fast_play=0
close_on_error=0
all_other_sources={}
all_hased=[]

if KODI_VERSION<=18:#kodi18
    if Addon.getSetting('debug')=='false':
        reload (sys )#line:61
        sys .setdefaultencoding ('utf8')#line:62
else:#kodi19
    import importlib
    importlib.reload (sys )#line:61
all_w_global={}
l_full_stats=''
po_watching=''
clicked_id=''
selected_index=-1
clicked=False
silent=False
break_jump=0
global list_index,str_next,sources_searching
global susb_data_next
susb_data_next={}
sources_searching=False
str_next=''
list_index=999
all_s_in=({},0,'','','')
close_sources_now=0
addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))
user_dataDir = xbmc_tranlate_path(Addon.getAddonInfo("profile"))
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
lang=xbmc.getLanguage(0)
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)

addNolink=public.addNolink
addDir3=public.addDir3
addLink=public.addLink
addLink_db=public.addLink_db
lang=public.lang
pre_mode=public.pre_mode
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time+999)

elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
from  resources.modules import cache
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)

elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
if Addon.getSetting("theme")=='0':
    art_folder='artwork'
    
elif Addon.getSetting("theme")=='1':
    art_folder='artwork_keshav'
elif Addon.getSetting("theme")=='2':
    art_folder='artwork_shinobi'
elif Addon.getSetting("theme")=='3':
    art_folder='artwork_sonic'
elif Addon.getSetting("theme")=='4':
    art_folder='artwork_bob'
BASE_LOGO=os.path.join(addonPath, 'resources', art_folder+'/')
file = open(os.path.join(BASE_LOGO, 'fanart.json'), 'r') 
fans= file.read()
file.close()
fanarts=json.loads(fans)
all_fanarts={}
for items in fanarts:
    if 'http' in fanarts[items]:
        all_fanarts[items]=fanarts[items]
    else:
        all_fanarts[items]=(os.path.join(BASE_LOGO, fanarts[items]))
    
global playing_text
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
playing_text=''


t_path=os.path.dirname(os.path.realpath(__file__))
'''
try:
   
    from resources.sources.sdarot import resolve_dns,get_final_video_and_cookie,get_ip_url,get_user_cookie_sratim
except:
    import shutil
    d= os.path.join(t_path,'dns')
    if os.path.exists(d):
        shutil.rmtree(d)
    if KODI_VERSION<=18:
        dns_path=os.path.join(t_path,'dns_17')
    else:
        dns_path=os.path.join(t_path,'dns_19')
    
    shutil.copytree(dns_path, d, False, None)
    
    from resources.sources.sdarot import resolve_dns,get_final_video_and_cookie,get_ip_url,get_user_cookie_sratim

'''

try:
    import urllib.parse
except:
    import urlparse
if KODI_VERSION<=18:
    que=urllib.quote_plus
    url_encode=urllib.urlencode
else:
    que=urllib.parse.quote_plus
    url_encode=urllib.parse.urlencode
if KODI_VERSION<=18:
    unque=urllib.unquote_plus
else:
    unque=urllib.parse.unquote_plus
if KODI_VERSION<=18:
    from urlparse import urlparse
    urp=urlparse
else:
    import urllib.parse as urlparse
    urp=urlparse.urlparse
if KODI_VERSION>18:
    def trd_alive(thread):
        return thread.is_alive()
    class Thread (threading.Thread):
       def __init__(self, target, *args):
        super().__init__(target=target, args=args)
        
       def run(self, *args):
          
          self._target(*self._args)
          return 0
else:
    def trd_alive(thread):
        return thread.isAlive()
    class Thread(threading.Thread):
        def __init__(self, target, *args):
           
            self._target = target
            self._args = args
            
            
            threading.Thread.__init__(self)
            
        def run(self):
            
            self._target(*self._args)
def replaceHTMLCodes(txt):
    try:
        import HTMLParser
        html_parser = HTMLParser.HTMLParser()
       
    except:
        import html as html_parser
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = html_parser.unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    txt = txt.replace("&#8211", "-")
    txt = txt.replace("&#8217", "'")
    txt = txt.strip()
    return txt
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def main_menu(time_data):
    elapsed_time = time.time() - start_time_start
    time_data.append(elapsed_time+111)
    #show_updates()
    
            
    elapsed_time = time.time() - start_time_start
    time_data.append(elapsed_time+222)
    all_d=[]
   
    if Addon.getSetting('movie_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32024),'www',2,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
        all_d.append(aa)
    if Addon.getSetting('tv_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32025),'www',3,BASE_LOGO+'tv.png',all_fanarts['32025'],'TV')
        all_d.append(aa)
    if Addon.getSetting('idanplus')=='true':
        aa=addDir3('ערוצי עידן פלוס','www',190,BASE_LOGO+'basic.png',all_fanarts['32024'],'עידן')
        all_d.append(aa)
    if Addon.getSetting('trakt_world')=='true':
        aa=addDir3(Addon.getLocalizedString(32026),'www',21,BASE_LOGO+'trakt.png',all_fanarts['32026'],'No account needed)')
        all_d.append(aa)
    if Addon.getSetting('trakt')=='true':
        aa=addDir3(Addon.getLocalizedString(32027),'www',114,BASE_LOGO+'trakt.png',all_fanarts['32027'],'TV')
        all_d.append(aa)
    aa=addDir3('סרטים מדובבים','www',203,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    # aa=addDir3('קריוקי','www',229,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    # all_d.append(aa)
    if Addon.getSetting('search')=='true':
        aa=addDir3(Addon.getLocalizedString(32020),'www',211,BASE_LOGO+'search.png',all_fanarts['32020'],'Search')
        all_d.append(aa)
    # if Addon.getSetting('search_history')=='true':
        # aa=addDir3(Addon.getLocalizedString(32021),'both',143,BASE_LOGO+'search.png',all_fanarts['32021'],'TMDB')
        # all_d.append(aa)
    if Addon.getSetting('last_link_played')=='true':
        aa=addDir3(Addon.getLocalizedString(32022),'www',144,BASE_LOGO+'last.png',all_fanarts['32022'],'Last Played') 
        all_d.append(aa)
    if Addon.getSetting('whats_new1')=='true':
        aa=addNolink(Addon.getLocalizedString(32028) , id,149,False,fanart=all_fanarts['32028'], iconimage=BASE_LOGO+'news.png',plot='',dont_place=True)
        all_d.append(aa)
    if Addon.getSetting('settings')=='true':
        aa=addNolink( Addon.getLocalizedString(32029), id,151,False,fanart=all_fanarts['32029'], iconimage=BASE_LOGO+'setting.png',plot='',dont_place=True)
        all_d.append(aa)
    if Addon.getSetting('resume_watching')=='true':		
        aa=addDir3(Addon.getLocalizedString(32030),'both',158,BASE_LOGO+'resume.png',all_fanarts['32030'],'TMDB')
        all_d.append(aa)
    if Addon.getSetting('debrid_select')=='0':
        if Addon.getSetting('my_rd_history')=='true':
            aa=addDir3(Addon.getLocalizedString(32031),'1',168,BASE_LOGO+'rd_history.png',all_fanarts['32031'],'TMDB')
            all_d.append(aa)
        if Addon.getSetting('rd_Torrents')=='true':
            aa=addDir3(Addon.getLocalizedString(32032),'1',169,BASE_LOGO+'rd_Torrents.png',all_fanarts['32032'],'TMDB')
            all_d.append(aa)
    if Addon.getSetting('actor')=='true':
        aa=addDir3(Addon.getLocalizedString(32033),'www',72,BASE_LOGO+'actor.png',all_fanarts['32033'],'Actor')
        all_d.append(aa)
    if Addon.getSetting('scraper_check')=='true':
        aa=addDir3( Addon.getLocalizedString(32034), id,172,BASE_LOGO+'basic.png',all_fanarts['32034'],'Test')
        
        all_d.append(aa)
    # aa=addDir3('ע','0',214,BASE_LOGO+'movies.png','','ע')
    # all_d.append(aa)
    #place your Jen playlist here:
    #dulpicate this line with your address
    #aa=addDir3('Name', 'Your Jen Address',189,'Iconimage','fanart','Description',search_db='Your Search db Address')
    #all_d.append(aa)
    aa=addDir3('Anonymous TV', 'http://thechains24.com/Ghost-Addon/ghostxmls/Chains.Team.Main.xml',191,BASE_LOGO+'icon.png','','Ghost')
    all_d.append(aa)
    aa=addDir3('Anonymous TV 4K', 'https://narcacist.com/Addon/text/rd/4ksection.xml',191,BASE_LOGO+'icon.png','','Ghost')
    all_d.append(aa)

    # aa=addDir3('Master Addon', '',193,'https://img1.apk.tools/img/AVNLIsDvpHrEvFRTNM2uqIa3CJh6tJ3bYY0CPbfIwH73madeLR6TwaOU-i_o20oh0HQ=s150','https://i.redd.it/rd1qnm0p69131.jpg','Master')
    # all_d.append(aa)
    
    if Addon.getSetting('debug')=='true':
        aa=addDir3( 'Unit tests', 'www',181,'https://lh3.googleusercontent.com/proxy/Ia9aOfcgtzofMb0urCAs8NV-4RRhcIVST-Gqx9GI9RLsx7IJe_5jBqjfdsJcOO3QIV3TT-uiF2nKmyYCX0vj5UPR4iW1iHXgZylE8N8wyNgRLw','https://i.ytimg.com/vi/3wLqsRLvV-c/maxresdefault.jpg','Test')
        
        all_d.append(aa)
    found=False
    for i in range(0,10):
        if Addon.getSetting('imdb_user_'+str(i))!='':
            found=True
            break
    if found:
        aa=addDir3(Addon.getLocalizedString(32309),'www',183,BASE_LOGO+'basic.png',all_fanarts['32309'],'Imdb')
        all_d.append(aa)
    
    elapsed_time = time.time() - start_time_start
    time_data.append(elapsed_time+333)
    if Addon.getSetting("stop_where")=='0':
            xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    
    elapsed_time = time.time() - start_time_start
    time_data.append(elapsed_time+444)
    return time_data
def movie_world():
    all_d=[]
    aa=addDir3(Addon.getLocalizedString(32295),'http://api.themoviedb.org/3/movie/now_playing?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,BASE_LOGO+'int.png',all_fanarts['32295'],'Tmdb')
    all_d.append(aa)
    'Popular Movies'
    aa=addDir3(Addon.getLocalizedString(32036),'http://api.themoviedb.org/3/movie/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,BASE_LOGO+'popular.png',all_fanarts['32036'],'Tmdb')
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32037),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=3d&language=%s&append_to_response=origin_country&page=1'%lang,14,BASE_LOGO+'3d.png',all_fanarts['32037'],'Tmdb')
    all_d.append(aa)
    
    #Genre
    aa=addDir3(Addon.getLocalizedString(32038),'http://api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,BASE_LOGO+'genre.png',all_fanarts['32038'],'Tmdb')
    all_d.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32039),'movie_years&page=1',14,BASE_LOGO+'years.png',all_fanarts['32039'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32040),'movie_years&page=1',112,BASE_LOGO+'networks.png',all_fanarts['32040'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32041),'advance_movie',14,BASE_LOGO+'content_s.png',all_fanarts['32041'],'Advance Content selection')
    all_d.append(aa)
    aa=addDir3('סרטים','0',209,BASE_LOGO+'movies.png','','סרטים')
    all_d.append(aa)
    # aa=addDir3('סרטים','0',310,BASE_LOGO+'movies.png','','סרטים')
    # all_d.append(aa)
    #Search movie
    aa=addDir3(Addon.getLocalizedString(32042),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language={0}&append_to_response=origin_country&page=1'.format(lang),14,BASE_LOGO+'search_m.png',all_fanarts['32042'],'Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32043),'movie',143,BASE_LOGO+'search.png',all_fanarts['32043'],'TMDB')
    all_d.append(aa)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    table_name='lastlinkmovie'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

    match = dbcur.fetchone()
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    
    if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
               import base64
               url=base64.b64decode(url)
              
             aa=addLink('[I]%s[/I]'%Addon.getLocalizedString(32022), url,6,False,iconimage,fanart,description,data=show_original_year,prev_name=name,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             all_d.append(aa)
       except  Exception as e:
         log.warning(e)
         pass
    aa=addDir3(Addon.getLocalizedString(32044),'movie',145,BASE_LOGO+'history.png',all_fanarts['32044'],'History')
    
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32045),'0',174,BASE_LOGO+'classic.png',all_fanarts['32045'],'classic')
    
    all_d.append(aa)
    
    # aa=addDir3(Addon.getLocalizedString(32046),'0',176,BASE_LOGO+'westren.png',all_fanarts['32046'],'classic')
    
    # all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32047),'0',178,BASE_LOGO+'3d.png',all_fanarts['32047'],'3D')
    
    all_d.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32313),'0',187,BASE_LOGO+'keywords.png',all_fanarts['32313'],'keywords')
    
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def movie_prodiction():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    
    
    aa=addDir3('[COLOR red]Marvel[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7505&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://yt3.ggpht.com/a-/AN66SAwQlZAow0EBMi2-tFht-HvmozkqAXlkejVc4A=s900-mo-c-c0xffffffff-rj-k-no','https://images-na.ssl-images-amazon.com/images/I/91YWN2-mI6L._SL1500_.jpg','Marvel')
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]DC Studios[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=9993&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://pmcvariety.files.wordpress.com/2013/09/dc-comics-logo.jpg?w=1000&h=563&crop=1','http://www.goldenspiralmedia.com/wp-content/uploads/2016/03/DC_Comics.jpg','DC Studios')
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]Lucasfilm[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=1&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://fontmeme.com/images/lucasfilm-logo.png','https://i.ytimg.com/vi/wdYaG3o3bgE/maxresdefault.jpg','Lucasfilm')
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]Warner Bros.[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=174&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'http://looking.la/wp-content/uploads/2017/10/warner-bros.png','https://cdn.arstechnica.net/wp-content/uploads/2016/09/warner.jpg','SyFy')
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Walt Disney Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=2&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://i.ytimg.com/vi/9wDrIrdMh6o/hqdefault.jpg','https://vignette.wikia.nocookie.net/logopedia/images/7/78/Walt_Disney_Pictures_2008_logo.jpg/revision/latest?cb=20160720144950','Walt Disney Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR skyblue]Pixar[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=3&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://elestoque.org/wp-content/uploads/2017/12/Pixar-lamp.png','https://wallpapercave.com/wp/GysuwJ2.jpg','Pixar')
    all_d.append(aa)
    aa=addDir3('[COLOR deepskyblue]Paramount[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=4&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/Paramount_Pictures_2010.svg/1200px-Paramount_Pictures_2010.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/a/a1/Paramount_Pictures_logo_with_new_Viacom_byline.jpg/revision/latest?cb=20120311200405&format=original','Paramount')
    all_d.append(aa)
    aa=addDir3('[COLOR burlywood]Columbia Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=5&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://static.tvtropes.org/pmwiki/pub/images/lady_columbia.jpg','https://vignette.wikia.nocookie.net/marveldatabase/images/1/1c/Columbia_Pictures_%28logo%29.jpg/revision/latest/scale-to-width-down/1000?cb=20141130063022','Columbia Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR powderblue]DreamWorks[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://www.dreamworksanimation.com/share.jpg','https://www.verdict.co.uk/wp-content/uploads/2017/11/DA-hero-final-final.jpg','DreamWorks')
    all_d.append(aa)
    aa=addDir3('[COLOR lightsaltegray]Miramax[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=14&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://vignette.wikia.nocookie.net/disney/images/8/8b/1000px-Miramax_1987_Print_Logo.png/revision/latest?cb=20140902041428','https://i.ytimg.com/vi/4keXxB94PJ0/maxresdefault.jpg','Miramax')
    all_d.append(aa)
    aa=addDir3('[COLOR gold]20th Century Fox[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=25&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://pmcdeadline2.files.wordpress.com/2017/03/20th-century-fox-cinemacon1.jpg?w=446&h=299&crop=1','https://vignette.wikia.nocookie.net/simpsons/images/8/80/TCFTV_logo_%282013-%3F%29.jpg/revision/latest?cb=20140730182820','20th Century Fox')
    all_d.append(aa)
    aa=addDir3('[COLOR bisque]Sony Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=34&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Sony_Pictures_Television_logo.svg/1200px-Sony_Pictures_Television_logo.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/2/20/Sony_Pictures_Digital.png/revision/latest?cb=20140813002921','Sony Pictures')
    all_d.append(aa)
    aa=addDir3('[COLOR navy]Lions Gate Films[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=35&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'http://image.wikifoundry.com/image/1/QXHyOWmjvPRXhjC98B9Lpw53003/GW217H162','https://vignette.wikia.nocookie.net/fanon/images/f/fe/Lionsgate.jpg/revision/latest?cb=20141102103150','Lions Gate Films')
    all_d.append(aa)
    aa=addDir3('[COLOR beige]Orion Pictures[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=41&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://i.ytimg.com/vi/43OehM_rz8o/hqdefault.jpg','https://i.ytimg.com/vi/g58B0aSIB2Y/maxresdefault.jpg','Lions Gate Films')
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]MGM[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=21&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://pbs.twimg.com/profile_images/958755066789294080/L9BklGz__400x400.jpg','https://assets.entrepreneur.com/content/3x2/2000/20150818171949-metro-goldwun-mayer-trade-mark.jpeg','MGM')
    all_d.append(aa)
    aa=addDir3('[COLOR gray]New Line Cinema[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=12&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/0/04/New_Line_Cinema.svg/1200px-New_Line_Cinema.svg.png','https://vignette.wikia.nocookie.net/theideas/images/a/aa/New_Line_Cinema_logo.png/revision/latest?cb=20180210122847','New Line Cinema')
    all_d.append(aa)
    aa=addDir3('[COLOR darkblue]Gracie Films[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=18&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://i.ytimg.com/vi/q_slAJmZBeQ/hqdefault.jpg','https://i.ytimg.com/vi/yGofbuJTb4g/maxresdefault.jpg','Gracie Films')
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Imagine Entertainment[/COLOR]','https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=23&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://s3.amazonaws.com/fs.goanimate.com/files/thumbnails/movie/2813/1661813/9297975L.jpg','https://www.24spoilers.com/wp-content/uploads/2004/06/Imagine-Entertainment-logo.jpg','Imagine Entertainment')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def movie_db_menu():

    all_d=[]

    all_d.append(addDir3('סרטים מדובבים עמודים','0',204,BASE_LOGO+'movies.png','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים'))
    all_d.append(addDir3('סרטים מדובבים שנים','0',204,BASE_LOGO+'years.png','','לפי שנים'))
    all_d.append(addDir3(' סרטים מדובבים לפי א-ב','0',205,BASE_LOGO+'history.png','','סרטים מדובבים'))
    all_d.append(addDir3('סרטים שנצפו','0',204,BASE_LOGO+'item_jump.png','https://i.ytimg.com/vi/9FQgg_h_lcQ/maxresdefault.jpg','נצפו','נצפו'))
    
    all_d.append(addDir3('חפש','www',206,BASE_LOGO+'search.png','','חפש'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def adjusted_datetime(string=False, dt=False):
    from datetime import datetime, timedelta
    d = datetime.utcnow() + timedelta(hours=int(72))
    if dt: return d
    d = datetime.date(d)
    if string:
        try: d = d.strftime('%Y-%m-%d')
        except ValueError: d = d.strftime('%Y-%m-%d')
    else: return d
def main_trakt():
   all_d=[]
   aa=addDir3(Addon.getLocalizedString(32048),'movie?limit=40&page=1',116,BASE_LOGO+'lists.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32049),'tv?limit=40&page=1',116,BASE_LOGO+'lists.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Lists')
   all_d.append(aa)
   import datetime
   current_date = adjusted_datetime()
   start = (current_date - datetime.timedelta(days=14)).strftime('%Y-%m-%d')
   finish = 14
        
   aa=addDir3(Addon.getLocalizedString(32050),'calendars/my/shows/%s/%s?limit=40&page=1'%(start,finish),117,BASE_LOGO+'lists.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32051),'users/me/watched/shows?extended=full&limit=40&page=1',115,BASE_LOGO+'progress.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Progress')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32052),'sync/watchlist/episodes?extended=full&limit=40&page=1',115,BASE_LOGO+'ep_watch.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Episodes')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32053),'users/me/watchlist/episodes?extended=full&limit=40&page=1',117,BASE_LOGO+'series_w.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Series')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32054),'users/me/collection/shows?limit=40&page=1',117,BASE_LOGO+'tv_col.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','TV')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32055),'users/me/watchlist/shows?limit=40&page=1',117,BASE_LOGO+'show_w.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Shows')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32056),'recommendations/shows?limit=40&ignore_collected=true&page=1',166,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32057),'users/me/watchlist/movies?limit=40&page=1',117,BASE_LOGO+'movie_wl.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32058),'recommendations/movies?limit=40&ignore_collected=true&page=1',166,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32059),'users/me/watched/movies?limit=40&page=1',117,BASE_LOGO+'movie_w.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Watched')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32060),'users/me/watched/shows?limit=40&page=1',117,BASE_LOGO+'series_wa.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Watched shows')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32061),'users/me/collection/movies?limit=40&page=1',117,BASE_LOGO+'movie_c.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','collection')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32062),'users/likes/lists?limit=40&page=1',118,BASE_LOGO+'liked_l.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Liked lists')
   all_d.append(aa)
   aa=addDir3(Addon.getLocalizedString(32063),'sync/playback/movies?limit=40&page=1',117,BASE_LOGO+'liked_l.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Liked lists')
   all_d.append(aa)
   
   aa=addDir3(Addon.getLocalizedString(32064),'sync/playback/episodes?limit=40&page=1',164,BASE_LOGO+'liked_l.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Liked lists')
   all_d.append(aa)
   
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
            
            
def tv_show_menu():
    all_d=[]
    import datetime
    now = datetime.datetime.now()
    aa=addDir3(Addon.getLocalizedString(32023),'tv',145,BASE_LOGO+'tracker.png',all_fanarts['32023'],'History')
    #Popular
    aa=addDir3(Addon.getLocalizedString(32012),'http://api.themoviedb.org/3/tv/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,BASE_LOGO+'popular.png',all_fanarts['32013'],'TMDB')
    all_d.append(aa)

    aa=addDir3(Addon.getLocalizedString(32013),'https://api.themoviedb.org/3/tv/on_the_air?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,BASE_LOGO+'on_air.png',all_fanarts['32013'],'TMDB')
    all_d.append(aa)
    
    
    aa=addDir3(Addon.getLocalizedString(32014),'https://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US&sort_by=popularity.desc&first_air_date_year='+str(now.year)+'&timezone=America%2FNew_York&include_null_first_air_ates=false&language={0}&page=1'.format(lang),14,BASE_LOGO+'int.png',all_fanarts['32014'],'New Tv shows')
    all_d.append(aa)
    #new episodes
    aa=addDir3(Addon.getLocalizedString(32015),'https://api.tvmaze.com/schedule',20,BASE_LOGO+'new_ep.png',all_fanarts['32015'],'New Episodes')
    all_d.append(aa)
    #Genre
    aa=addDir3(Addon.getLocalizedString(32016),'http://api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,BASE_LOGO+'genre.png',all_fanarts['32016'],'TMDB')
    all_d.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32017),'tv_years&page=1',14,BASE_LOGO+'years.png',all_fanarts['32017'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32018),'tv_years&page=1',101,BASE_LOGO+'networks.png',all_fanarts['32018'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32019),'advance_tv',14,BASE_LOGO+'content_s.png',all_fanarts['32019'],'Advance Content selection')
    
    all_d.append(aa)
    #Search tv
    aa=addDir3(Addon.getLocalizedString(32020),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language={0}&page=1'.format(lang),14,BASE_LOGO+'search.png',all_fanarts['32020'],'TMDB')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32021),'tv',143,BASE_LOGO+'search.png',all_fanarts['32021'],'TMDB')
    all_d.append(aa)
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    table_name='lastlinktv'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

    match = dbcur.fetchone()
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    
    if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
               import base64
               url=base64.b64decode(url)
              
             aa=addLink('[I]%s[/I]'%Addon.getLocalizedString(32022), url,6,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             all_d.append(aa)
       except  Exception as e:
         log.warning(e)
         pass
         
    
    
    
    aa=addDir3(Addon.getLocalizedString(32023),'tv',145,BASE_LOGO+'tracker.png',all_fanarts['32023'],'History')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def tv_neworks():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    aa=addDir3('[COLOR lightblue]Disney+[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2739&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://lumiere-a.akamaihd.net/v1/images/image_308e48ed.png','https://allears.net/wp-content/uploads/2018/11/wonderful-world-of-animation-disneys-hollywood-studios.jpg','Disney')
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Apple TV+[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2552&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://ksassets.timeincuk.net/wp/uploads/sites/55/2019/03/Apple-TV-screengrab-920x584.png','https://www.apple.com/newsroom/videos/apple-tv-plus-/posters/Apple-TV-app_571x321.jpg.large.jpg','Apple')
    all_d.append(aa)
    aa=addDir3('[COLOR red]NetFlix[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=213&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://art.pixilart.com/705ba833f935409.png','https://i.ytimg.com/vi/fJ8WffxB2Pg/maxresdefault.jpg','NetFlix')
    all_d.append(aa)
    aa=addDir3('[COLOR gray]HBO[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=49&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://filmschoolrejects.com/wp-content/uploads/2018/01/hbo-logo.jpg','https://www.hbo.com/content/dam/hbodata/brand/hbo-static-1920.jpg','HBO')
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]CBS[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=16&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://cdn.freebiesupply.com/logos/large/2x/cbs-logo-png-transparent.png','https://tvseriesfinale.com/wp-content/uploads/2014/10/cbs40-590x221.jpg','HBO')
    all_d.append(aa)
    aa=addDir3('[COLOR purple]SyFy[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=77&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'http://cdn.collider.com/wp-content/uploads/syfy-logo1.jpg','https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F05%2Fdefault.jpg&w=1100&c=sc&poi=face&q=85','SyFy')
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]The CW[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=71&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://www.broadcastingcable.com/.image/t_share/MTU0Njg3Mjc5MDY1OTk5MzQy/tv-network-logo-cw-resized-bc.jpg','https://i2.wp.com/nerdbastards.com/wp-content/uploads/2016/02/The-CW-Banner.jpg','The CW')
    all_d.append(aa)
    aa=addDir3('[COLOR silver]ABC[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'http://logok.org/wp-content/uploads/2014/03/abc-gold-logo-880x660.png','https://i.ytimg.com/vi/xSOp4HJTxH4/maxresdefault.jpg','ABC')
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]NBC[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=6&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://designobserver.com/media/images/mondrian/39684-NBC_logo_m.jpg','https://www.nbcstore.com/media/catalog/product/cache/1/image/1000x/040ec09b1e35df139433887a97daa66f/n/b/nbc_logo_black_totebagrollover.jpg','NBC')
    all_d.append(aa)
    aa=addDir3('[COLOR gold]AMAZON[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=1024&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'http://g-ec2.images-amazon.com/images/G/01/social/api-share/amazon_logo_500500._V323939215_.png','https://cdn.images.express.co.uk/img/dynamic/59/590x/Amazon-Fire-TV-Amazon-Fire-TV-users-Amazon-Fire-TV-stream-Amazon-Fire-TV-Free-Dive-TV-channel-Amazon-Fire-TV-news-Amazon-1010042.jpg?r=1535541629130','AMAZON')
    all_d.append(aa)
    aa=addDir3('[COLOR green]hulu[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=453&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://i1.wp.com/thetalkinggeek.com/wp-content/uploads/2012/03/hulu_logo_spiced-up.png?resize=300%2C225&ssl=1','https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwi677r77IbeAhURNhoKHeXyB-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.hulu.com%2F&psig=AOvVaw0xW2rhsh4UPsbe8wPjrul1&ust=1539638077261645','hulu')
    all_d.append(aa)
    aa=addDir3('[COLOR red]Showtime[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=67&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://res.cloudinary.com/wnotw/images/c_limit,w_1536,q_auto:best,f_auto/v1501788508/sci5cdawypsux61i9pyb/showtime-networks-logo','https://www.sho.com/site/image-bin/images/0_0_0/0_0_0_prm-ogseries_1280x640.jpg','showtime')
    all_d.append(aa)
    aa=addDir3('[COLOR red]BBC One[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=4&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://lh3.googleusercontent.com/proxy/LnjjtuGk_PErC5iaReOcy6EEvwjT9wzlyZBKhQHconLsyHWdVn1NHa-Bz3E0_Dev0KV_yJtGyQTlHDwvvm3zW3i0NFSmQVim5_hYOeZ-jWpD1Zs','https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/BBC_One_HD.svg/800px-BBC_One_HD.svg.png','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR teal]BBC Two[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=332&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://pbs.twimg.com/profile_images/1057914504321908736/06hkWvx__400x400.jpg','http://amirsaidani.co.uk/wp-content/uploads/2019/06/BBC_TWO_LOGO_ANIMATION.gif','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR pink]BBC Three[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=3&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/BBC_Three_%282020%29.svg/1200px-BBC_Three_%282020%29.svg.png','https://ichef.bbci.co.uk/news/1024/media/images/81061000/jpg/_81061920_bbcthreelogo.jpg','BBC')
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]ITV[/COLOR]','https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=9&language={0}&sort_by={1}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(lang,order_by),14,'https://sm.imgix.net/20/31/itv.jpg?w=1200&h=1200&auto=compress,format&fit=clip','https://www.imediaethics.org/wp-content/uploads/2018/11/SCfaQb9l_400x400-350x350.jpg','BBC')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def trakt_world():
    all=[]
    aa=addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32124), id,27,False,fanart=' ', iconimage=' ',plot=' ',dont_place=True)
    all.append(aa)
    
    
    
    aa=addDir3(Addon.getLocalizedString(32125),'movies/trending?limit=40&page=1',117,BASE_LOGO+'people.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32126),'movies/popular?limit=40&page=1$$$noaut',166,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32127),'movies/played/%s?limit=40&page=1',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32128),'movies/watched/%s?limit=40&page=1',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32129),'movies/collected/%s?limit=40&page=1',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32130),'movies/anticipated?limit=40&page=1$$$noaut',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32131),'movies/boxoffice?limit=40&page=1$$$noaut',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Movies')
    all.append(aa)
    
    aa=addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32025), id,27,False,fanart=' ', iconimage=' ',plot=' ',dont_place=True)
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32132),'shows/trending?limit=40&page=1$$$noaut',117,BASE_LOGO+'people.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32133),'shows/popular?limit=40&page=1$$$noaut',166,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32134),'shows/played/%s?limit=40&page=1',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32135),'shows/collected/%s?limit=40&page=1',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32136),'shows/anticipated?limit=40&page=1$$$noaut',117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    import datetime
    datetime_get = (datetime.datetime.utcnow() - datetime.timedelta(days = 7))

    log.warning(datetime_get.strftime('%Y-%m-%d'))
    f_data=datetime_get.strftime('%Y-%m-%d')
    
    
    aa=addDir3(Addon.getLocalizedString(32307),'shows/updates/%s?limit=40&page=1$$$noaut'%f_data,117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    datetime_get = (datetime.datetime.utcnow() - datetime.timedelta(days = 30))

    log.warning(datetime_get.strftime('%Y-%m-%d'))
    f_data=datetime_get.strftime('%Y-%m-%d')
    
    
    aa=addDir3(Addon.getLocalizedString(32308),'shows/updates/%s?limit=40&page=1$$$noaut'%f_data,117,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32137), id,27,False,fanart=' ', iconimage=' ',plot=' ',dont_place=True)
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32138),'lists/trending',119,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    aa=addDir3(Addon.getLocalizedString(32139),'lists/popular',119,BASE_LOGO+'trakt.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Tv')
    all.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all,len(all))
def search_menu():
    all_d=[]

    if Addon.getSetting('search')=='true':
        aa=addDir3(Addon.getLocalizedString(32020),'www',5,BASE_LOGO+'search.png',all_fanarts['32020'],'Search')
        all_d.append(aa)
    if Addon.getSetting('search_history')=='true':
        aa=addDir3(Addon.getLocalizedString(32021),'both',143,BASE_LOGO+'search.png',all_fanarts['32021'],'TMDB')
        all_d.append(aa)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def load_resolveurl_libs():
    path=xbmc_tranlate_path('special://home/addons/script.module.resolveurl/lib')
    sys.path.append( path)
    path=xbmc_tranlate_path('special://home/addons/script.module.six/lib')
    sys.path.append( path)
    path=xbmc_tranlate_path('special://home/addons/script.module.kodi-six/libs')
    sys.path.append( path)
    path1=xbmc_tranlate_path('special://home/addons/script.module.requests/lib')
    sys.path.append( path1)
    path1=xbmc_tranlate_path('special://home/addons/script.module.urllib3/lib')
    sys.path.append( path1)
    path1=xbmc_tranlate_path('special://home/addons/script.module.chardet/lib')
    sys.path.append( path1)
    path1=xbmc_tranlate_path('special://home/addons/script.module.certifi/lib')
    sys.path.append( path1)
    path1=xbmc_tranlate_path('special://home/addons/script.module.idna/lib')
    sys.path.append( path1)
    path1=xbmc_tranlate_path('special://home/addons/script.module.futures/lib')
    sys.path.append( path1)
def resolve_chan(url):
    url=url.replace('%20','')  
    from resources.modules.client import get_html
    link=url.split('$$$')[0]
    headers=json.loads(url.split('$$$')[1])
    x=get_html('http://client-iptvmag.club:8080/portal.php?type=stb&action=handshake&token=&JsHttpRequest=1-xml',headers=headers).json()
    
    token=x['js']['token']
    x=get_html('http://client-iptvmag.club:8080/portal.php?&action=get_profile&mac=00%3A1A%3A79%3A68%3A96%3ABA&type=stb&hd=1&sn=&stb_type=MAG250&client_type=STB&image_version=218&device_id=&hw_version=1.7-BD-00&hw_version_2=1.7-BD-00&auth_second_step=1&video_out=hdmi&num_banks=2&metrics=%7B%22mac%22%3A%2200%3A1A%3A79%3A68%3A96%3ABA%22%2C%22sn%22%3A%22%22%2C%22model%22%3A%22MAG250%22%2C%22type%22%3A%22STB%22%2C%22uid%22%3A%22%22%2C%22random%22%3A%22null%22%7D&ver=ImageDescription%3A%200.2.18-r14-pub-250%3B%20ImageDate%3A%20Fri%20Jan%2015%2015%3A20%3A44%20EET%202016%3B%20PORTAL%20version%3A%205.6.1%3B%20API%20Version%3A%20JS%20API%20version%3A%20328%3B%20STB%20API%20version%3A%20134%3B%20Player%20Engine%20version%3A%200x566',headers=headers).content()

    headers['Authorization']='Bearer %s'%token
    x=get_html('http://client-iptvmag.club:8080/portal.php?type=itv&action=create_link&forced_storage=undefined&download=0&cmd=%s'%que(link),headers=headers).json()
    
    f_link=x['js']['cmd'].replace('ffmpeg ','')

    
    headers={'Icy-MetaData': '1',
    'Accept-Encoding': 'identity',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 10; BISON Build/QP1A.190711.020)',

    'Connection': 'Keep-Alive'}
    head=url_encode(headers)
    f_link=f_link+"|"+head
    
    return f_link
def resolve_pesek(url):

    base_header={
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',

                'Pragma': 'no-cache',
                
               
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                }
    from resources.modules.client import get_html
    x=get_html('https://www.pesekzman.com'+url,headers=base_header).content()
    log.warning('בב '+x)
    regex='iframe.+?src="(.+?)"'
    m=re.compile(regex).findall(x)
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', x)))
    # try:
    return m[0]
    # except:
       # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'Anonymous TV'),'[COLOR %s]הערוץ לא זמין כעת, נסה שוב מאוחר יותר.[/COLOR]' % COLOR2)
       # sys.exit()
def idan_chan():
    from  resources.modules.client import get_html
    x=get_html('https://raw.githubusercontent.com:443/RGdevz/RGDevz.github.io/master/test.txt').content()
    
    regex='tvg-logo="(.+?)".+?group-title=.+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(x)
    all=[]
    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all.append(aa)
    log.warning(m)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all,len(all))
def get_fchan():
    from resources.modules.client import get_html
    headers={'Cookie': 'mac=00%3A1A%3A79%3A68%3A96%3ABA; stb_lang=en; timezone=Europe%2FParis',
    'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
    'X-User-Agent': 'Model: MAG250; Link: WiFi',
    'Cache-Control': 'no-cache',
    'Referrer': 'http://client-iptvmag.club:8080/stalker_portal/c/',
    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'utf-8'}

    x=get_html('http://client-iptvmag.club:8080/portal.php?type=stb&action=handshake&token=&JsHttpRequest=1-xml',headers=headers).json()
    
    token=x['js']['token']

    x=get_html('http://client-iptvmag.club:8080/portal.php?&action=get_profile&mac=00%3A1A%3A79%3A68%3A96%3ABA&type=stb&hd=1&sn=&stb_type=MAG250&client_type=STB&image_version=218&device_id=&hw_version=1.7-BD-00&hw_version_2=1.7-BD-00&auth_second_step=1&video_out=hdmi&num_banks=2&metrics=%7B%22mac%22%3A%2200%3A1A%3A79%3A68%3A96%3ABA%22%2C%22sn%22%3A%22%22%2C%22model%22%3A%22MAG250%22%2C%22type%22%3A%22STB%22%2C%22uid%22%3A%22%22%2C%22random%22%3A%22null%22%7D&ver=ImageDescription%3A%200.2.18-r14-pub-250%3B%20ImageDate%3A%20Fri%20Jan%2015%2015%3A20%3A44%20EET%202016%3B%20PORTAL%20version%3A%205.6.1%3B%20API%20Version%3A%20JS%20API%20version%3A%20328%3B%20STB%20API%20version%3A%20134%3B%20Player%20Engine%20version%3A%200x566',headers=headers).content()

    headers['Authorization']='Bearer %s'%token
    # x=get_html('http://client-iptvmag.club:8080/portal.php?type=vod&action=get_categories',headers=headers).content()

    # x=get_html('http://client-iptvmag.club:8080/portal.php?type=itv&action=get_genres',headers=headers).content()

    x=get_html('http://client-iptvmag.club:8080/portal.php?type=itv&action=get_all_channels',headers=headers).json()


    all_channels={}
    for items in x['js']['data']:
       
        if 'VIP IL' in items['name']:
            all_channels[items['name']]={}
            all_channels[items['name']]['url']=items['cmd']
            all_channels[items['name']]['logo']=items['logo']
    return all_channels,headers
def idan_menu():
    all_d=[]
    aa=addDir3('לויין 1','www',222,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('לויין 2','www',223,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('לויין 3','www',220,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('לויין 4','www',221,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    # aa=addDir3('לויין 5','www',218,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    # all_d.append(aa)
    aa=addDir3('לויין 5','www',226,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('ספורט','www',225,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('כל הערוצים מכל העולם','www',224,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    aa=addDir3('עידן פלוס','www',219,BASE_LOGO+'movies.png',all_fanarts['32024'],'Movies')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite1():
    base_header={
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',

                'Pragma': 'no-cache',
                
               
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                }
    from resources.modules.client import get_html
    x=get_html('https://www.pesekzman.com/',headers=base_header).content()
   
           
    regex='<section class="sidebar" id="sidebar">(.+?)</ul>'
    m=re.compile(regex,re.DOTALL).findall(x)
    
    regex='<a href="(.+?)"><li class="(.+?)"><img src="(.+?)" /><p>(.+?)</p></li></a>'
    m2=re.compile(regex).findall(m[0])
    all_d=[]
    for url,nm,img,name in m2:
             # aa=addLink('[I]%s[/I]'%Addon.getLocalizedString(32022), url,6,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             # all_d.append(aa)
        all_d.append(addLink(name,url,215,False,img,img,name,description))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite2(img_o):
    all_d=[]
    all_channels,headers=cache.get(get_fchan, 5,table='pages')

    for items in all_channels:
        name=items
        url=all_channels[items]['url']
        img=all_channels[items]['logo']

        if 'http' not in img:
            img=img_o
        aa=addLink(name,url+'$$$'+json.dumps(headers),175,False,img,img,name+'.fullChan',description)
        all_d.append(aa)

    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def idan():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html('https://raw.githubusercontent.com:443/RGdevz/RGDevz.github.io/master/test.txt').content()
    
    regex='tvg-logo="(.+?)".+?group-title=.+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite_3():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(my3).content()
    
    regex='tvg-rec="(.+?)".+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm.replace('#EXTGRP:Израиль | ישראלי',''), 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite_4():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(my4).content()
    
    regex='tvg-rec="(.+?)".+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite_1():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(my1).content()
    regex='tvg-rec="(.+?)".+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm.replace('#EXTGRP:Израиль | ישראלי',''), 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite_2():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(my2).content()
    regex='tvg-name="(.+?)",.+?(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm.replace('#EXTGRP:ישראלי',''), 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def tv_all():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(tvall).content()
    regex='tvg-rec="(.+?)".+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm.replace('#EXTGRP:Израиль | ישראלי','').replace('#EXTGRP:',''), 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def sport_1():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(sport).content()
    
    regex='tvg-logo="(.+?)".+?group-title=.+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def Satellite_5():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(my5).content()
    
    regex='tvg-name="(.+?)".+?group-title=.+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def music_ip():
    all_d=[]
    from resources.modules.client import get_html
    xx=get_html(music).content()
    
    regex='tvg-logo="(.+?)".+?group-title=.+?,(.+?)http(.+?)\n'
    m=re.compile(regex,re.DOTALL).findall(xx)

    for im,nm,lk in m:
        url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+'http'+lk
        aa=addLink(nm, 'http'+lk.replace('\n','').strip(),175,False,im,im,nm,place_control=True)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def play_pesek(o_name,url,iconimage,fanart,description,name):

    url=resolve_pesek(url)
    load_resolveurl_libs()
    log.warning(url)
    import resolveurl
    url =resolveurl .HostedMediaFile (url =url ).resolve ()#line:2687
    
    episode='0'
    season='0'

    video_data={}
    
    video_data['title']=o_name+' ,'+name
    video_data['icon']=iconimage
    video_data['original_title']=o_name+' ,'+name
    video_data['plot']=description

    video_data['season']=season
    video_data['episode']=episode
    video_data['poster']=fanart
    video_data['poster3']=fanart
    video_data['fanart2']=fanart
    
    listItem = xbmcgui.ListItem(video_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=video_data)
    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    
def search_history(url,icon,fan):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
    dbcon.commit()
        
    dbcur.execute("SELECT * FROM search ORDER BY rowid DESC")
    
    # if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_search")=='true':
        # try:
            # all_db=read_firebase('search')
            # match_search=[]
            # for itt in all_db:
                
                # items=all_db[itt]

                # match_search.append((items['name'],items['free']))
        # except:
          # match_search = dbcur.fetchall()
          # # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, 'בעיה בסנכרון'),'[COLOR %s]מזהה ID שגוי[/COLOR]' % COLOR2)
    # else:
    
    match_search = dbcur.fetchall()
    
    all_d=[]
    for nm,fr in match_search:
        log.warning('חיפוש'+str(fr))
        aa=addDir3(nm,nm,199,BASE_LOGO+'search.png','https://www.york.ac.uk/media/study/courses/postgraduate/centreforlifelonglearning/English-Building-History-banner-bought.jpg','TMDB')
        # aa=addDir3(qua,'http://api.themoviedb.org/3/search/{0}?api_key=34142515d9d23817496eeb4ff1d223d0&query={1}&language={2}&page=1'.format(type,qua,lang),14,BASE_LOGO+'search.png','https://www.york.ac.uk/media/study/courses/postgraduate/centreforlifelonglearning/English-Building-History-banner-bought.jpg','TMDB')
        all_d.append(aa)
        

    aa=addNolink( '[COLOR orange]נקה היסטורייה[/COLOR]',url,148,False,fanart=fan, iconimage=icon,plot='Clear %s History'%url,dont_place=True)
    all_d.append(aa)
        
    dbcur.close()
    dbcon.close()
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def heb_mov_dub(url,description):
    import datetime
    page=int(url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    all_w={}
    dataDir_medovavim =(xbmc_tranlate_path("special://userdata/addon_data/") + 'db/youtube.db')
    dbcon = database.connect(dataDir_medovavim)
    dbcur = dbcon.cursor()
    if 'נצפו' in description:
        dbcur.execute("SELECT * FROM watched ")
    
        match = dbcur.fetchall()
        all_l=[]
        x=page
        all_array=[]
        count=0
        for name ,link,data,tmdbid,icon, image,free in match:
            all_array.append((count,name ,link,data,tmdbid,icon, image,free))
            count+=1
        all_array=sorted(all_array, key=lambda x: x[0], reverse=True)
        for count,name ,link,data,tmdbid,icon, image,free in all_array:
            if (x>=(page*30) and x<=((page+1)*30)):
                all_l.append(addLink_db(replaceHTMLCodes(name.replace("%27","'")),link,207,False,icon,image,'',video_info=unque(data),id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),204,BASE_LOGO+'next.png','',description))
        
    elif 'שנים' in description:
        
        dbcur.execute("SELECT * FROM kids_movie_year ORDER BY year DESC")
        all_l=[]
        match = dbcur.fetchall()
        x=page
        for name ,link,icon, image,plot,data,tmdbid ,date_added,year in match:
            if (x>=(page*30) and x<=((page+1)*30)):
                all_l.append(addLink_db(replaceHTMLCodes(name),link,207,False,icon,image,plot,video_info=data,id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),204,BASE_LOGO+'next.png','',description))
    else:
        
        dbcur.execute("SELECT * FROM kids_movie_ordered ORDER BY date_added DESC")
        all_l=[]
        match = dbcur.fetchall()
        x=page
        all_data_in=[]
        for name ,link,icon, image,plot,data,tmdbid ,date_added in match:
            try:
                try:
                      
                      new_date=datetime.datetime.strptime(date_added, '%Y-%m-%d %H:%M:%S')
                except TypeError:
                      
                      new_date=datetime.datetime(*(time.strptime(date_added, "%Y-%m-%d %H:%M:%S")[0:6]))
                      
            except:
               try:
                try:
                                                                      
                      new_date=datetime.datetime.strptime(date_added, '%d/%m/%Y %H:%M:%S')
                except TypeError:
                      
                      new_date=datetime.datetime(*(time.strptime(date_added, "%d/%m/%Y %H:%M:%S")[0:6]))
               except:
                new_date=new_date
            all_data_in.append((name ,link,icon, image,plot,data,tmdbid ,new_date))
        all_data_in=sorted(all_data_in, key=lambda x: x[7], reverse=True)
        for name ,link,icon, image,plot,data,tmdbid ,date_added in all_data_in:
            if (x>=(page*30) and x<=((page+1)*30)):
                all_l.append(addLink_db(replaceHTMLCodes(name),link,207,False,icon,image,plot,video_info=data,id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),204,BASE_LOGO+'next.png','',description))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_mov(url,description):
    import datetime
    page=int(url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    all_w={}
    dataDir_movieil =(xbmc_tranlate_path("special://userdata/addon_data/") + 'db/youtube_m.db')
    dbcon = database.connect(dataDir_movieil)
    dbcur = dbcon.cursor()

    if 'נצפו' in description:
        all_l=[]
        all_l.append(addDir3('חיפוש','www',212,BASE_LOGO+'search.png','','חיפוש'))

        dbcur.execute("SELECT * FROM watched ")
    
        match = dbcur.fetchall()
        
        x=page
        all_array=[]
        count=0
        for name ,link,data,tmdbid,icon, image,free in match:
            all_array.append((count,name ,link,data,tmdbid,icon, image,free))
            count+=1
        all_array=sorted(all_array, key=lambda x: x[0], reverse=True)
        for count,name ,link,data,tmdbid,icon, image,free in all_array:
            if (x>=(page*50) and x<=((page+1)*50)):
                all_l.append(addLink_db(replaceHTMLCodes(name.replace("%27","'")),link,207,False,icon,image,'',video_info=unque(data),id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),209,BASE_LOGO+'next.png','',description))

    elif 'שנים' in description:
        all_l=[]
        all_l.append(addDir3('חפש','www',212,BASE_LOGO+'search.png','','חפש'))
        dbcur.execute("SELECT * FROM movie_year ORDER BY year DESC")
        
        match = dbcur.fetchall()
        x=page
        for name ,link,icon, image,plot,data,tmdbid ,date_added,year in match:
            if (x>=(page*50) and x<=((page+1)*50)):
                all_l.append(addLink_db(replaceHTMLCodes(name),link,207,False,icon,image,plot,video_info=data,id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),209,BASE_LOGO+'next.png','',description))
    else:
        all_l=[]
        all_l.append(addDir3('חפש','www',212,BASE_LOGO+'search.png','','חפש'))
        dbcur.execute("SELECT * FROM movie_ordered ORDER BY date_added DESC")
        
        match = dbcur.fetchall()
        x=page
        all_data_in=[]
        for name ,link,icon, image,plot,data,tmdbid ,date_added in match:
            try:
                try:
                      
                      new_date=datetime.datetime.strptime(date_added, '%Y-%m-%d %H:%M:%S')
                except TypeError:
                      
                      new_date=datetime.datetime(*(time.strptime(date_added, "%Y-%m-%d %H:%M:%S")[0:6]))
                      
            except:
                new_date=new_date
            all_data_in.append((name ,link,icon, image,plot,data,tmdbid ,new_date))
        all_data_in=sorted(all_data_in, key=lambda x: x[7], reverse=True)
        for name ,link,icon, image,plot,data,tmdbid ,date_added in all_data_in:
            if (x>=(page*50) and x<=((page+1)*50)):
            
                all_l.append(addLink_db(replaceHTMLCodes(name),link,207,False,icon,image,plot,video_info=data,id=tmdbid,all_w=all_w))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),209,BASE_LOGO+'next.png','',description))
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def resolve_link(url,id,plot,name1,icon,fan):
    # log.warning('VID LINK' + url)
    import requests
    if 'drive.google.com' in url:
        o_url=url
        path=xbmc_tranlate_path('special://home/addons/script.module.resolveurl/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.six/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.kodi-six/libs')
        sys.path.append( path)
        import resolveurl
        url =resolveurl .HostedMediaFile (url =url ).resolve ()#line:2687
        log.warning('Resoving url: Done')
        log.warning(url)
        if not url:
            log.warning('Resoving url:')
            from resources.modules.google_solve import googledrive_resolve
            url,q=googledrive_resolve(o_url)
            log.warning(url)
        
        
        
        
    if 'tv4kids' in url:
        url=unque(url).replace('t1dxi9ex4ypp.cdn.shift8web.com','tv4kids.tk').replace('[[OS]]','')
        log.warning('f_url:'+url.replace('[[OS]]','').replace('t1dxi9ex4ypp.cdn.shift8web.com','tv4kids.tk'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=url_encode(headers)
        url=url+"|"+head
        url=response
        
    
    if '%%%' in url:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        url=url.split('%%%')[0]
        url_id=url
        if KODI_VERSION<=18:
            fixed_name=name1.decode('utf-8','ignore').encode("utf-8")

        else:
            fixed_name= bytes(name1, 'utf-8').decode('utf-8', 'ignore')


        url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=%s&url=%s&iconimage=%s&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',que(fixed_name),id,fan,url_id,icon,que(fixed_name),plot,'',name1,name1)
        log.warning(url)
    if '[' in url and 'http' not in url:
       from resources.modules.sdarot import MyResolver
       url_data=json.loads(url)
       log.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
    if 'f2h' in url:
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        url=id+'/files/'+match2[0].replace("|","%7C")
    if 'www.youtube.com' in url :
        vid=re.compile('\?(?:v|id)=(.+?)(?:$|&)').findall(url)[0]
        url='plugin://plugin.video.youtube/play/?video_id='+vid
    if 'dood.to' in url:
        
        headers = {
            'authority': 'dood.to',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-dest': 'iframe',
            'referer': url,
            'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
           }
        url=url.replace('/d/','/e/')
        log.warning(url)
        x=requests.get(url,headers=headers).content
        regex="'/pass_md5/(.+?)'"

        m=re.compile(regex,re.DOTALL).findall(x)
        x=requests.get('https://dood.to/pass_md5/'+m[0],headers=headers).content
        
        log.warning(x)
        tokens=m[0].split('/')
        token=tokens[len(tokens)-1]
        expiry=int(time.time()*1000)
        
        a='?token=5trtb3h06c50mgjd5yih06se&expiry=1596976834003'
        a='S4w8nJVnR1?token=%s&expiry=%s'%(token,expiry)
        log.warning(a)
        headers = {
            'Connection': 'keep-alive',
            'sec-ch-ua': '^\\^Chromium^\\^;v=^\\^88^\\^, ^\\^Google',
            'sec-ch-ua-mobile': '?0',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'cross-site',
            'Sec-Fetch-Mode': 'no-cors',
            'Sec-Fetch-Dest': 'video',
            'Referer': url,
            'Accept-Language': 'en-US,en;q=0.9',
           
        }


        headers2 = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'en-US,en;q=0.5',
           
            'Connection': 'keep-alive',
            'Referer': url,
        }
        url= x+a+"|"+ url_encode(headers)
    return url
def play_link_db(name,url,video_info,id,icon,fan,plot):
    # log.warning(url)
    # log.warning(name)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    dataDir_medovavim =(xbmc_tranlate_path("special://userdata/addon_data/") + 'db/youtube.db')
    dbcon = database.connect(dataDir_medovavim)
    dbcur = dbcon.cursor()
    
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'

    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'watched' )
    
    dbcur.execute("DELETE FROM "+table_name)
    try:
        dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,que(video_info),id,icon,fan,plot.replace("'","%27")))
    except:pass
    
    dbcur.execute("SELECT * FROM watched ")
    all_w=[]
    match = dbcur.fetchall()
    all_nw=[]
    for name_w ,link_w,data_w,tmdbid_w,icon_w, image_w,free_w in match:
        all_nw.append(name_w)
    if name.replace("'","%27") not in all_nw and name not in all_nw:
       try:
        dbcur.execute("INSERT INTO watched Values ('%s','%s','%s','%s','%s','%s','%s')"%(name.replace("'","%27"),url,que(video_info),id,icon,fan,plot.replace("'","%27")))
       except:pass
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    try:
        all_data=json.loads(video_info)
        try:
          all_data[u'mpaa']=unicode('heb')
        except:
          all_data[u'mpaa']=('heb')
    except:
        all_data={}
        all_data['title']=name
        all_data['plot']=plot
        try:
          all_data[u'mpaa']=unicode('heb')
        except:
          all_data[u'mpaa']=('heb')
    all_f_name=[]
    OriginalTitle=''
    try:
        try:
            OriginalTitle=all_data['originaltitle']
        except:
            OriginalTitle=all_data['OriginalTitle']
    except:pass
    if 1:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 log.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('TE',f_name.replace('%20',' '))]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','4TV').replace('.tk','.com').replace('dood.to','Tele').replace('dood.la','Tele').replace('dood.so','Tele').replace('dood.sh','Tele').replace('drive.google.com','Tele').replace('www.fembed.com','Tele')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #log.warning(all_s)
       all_s.append('Telemedia - כל המקורות')
       ret = xbmcgui.Dialog().select("בחר", all_s)
       plugin = all_s[ret]

       if ret == -1:
            sys.exit()
       if plugin =='Telemedia - כל המקורות':
         try:
                dialog = xbmcgui.DialogBusy()
                dialog.create()
         except:
               xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

         url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=15&original_title=%s&id=%s&data=&fanart=%s&url=%s&iconimage=%s&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url,'1','%20','%20',OriginalTitle,id,icon,que(name),icon,'',que(plot),'',que(name),que(name))
         xbmc.executebuiltin('RunPlugin(%s)'%url)
         # listItem = xbmcgui.ListItem(all_data['title'], path=url) 
         # listItem.setInfo(type='Video', infoLabels=all_data)


         # listItem.setProperty('IsPlayable', 'true')
         # ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
       if ret!=-1 and not plugin =='Telemedia - כל המקורות':
         try:
                dialog = xbmcgui.DialogBusy()
                dialog.create()
         except:
               xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
         #log.warning(links)
         #log.warning(ret)
         ff_link=links[ret]
         
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'TE' in all_s[ret]:
            
            
            ff_link=ff_link
            log.warning('ff_link2:'+ff_link)
           if 'http' in ff_link or 'TE' in all_s[ret]:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         log.warning('ff_link:'+ff_link)
        
         if 'TE' in all_s[ret]:
            
            
            heb_name=all_f_name[ret]
            saved_name=all_f_name[ret]
            original_title=all_f_name[ret]
            season='%20'
            
         url=ff_link.strip()
       else:
         sys.exit()
    else:
        try:
                dialog = xbmcgui.DialogBusy()
                dialog.create()
        except:
               xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
    o_url=url
    # log.warning('Resolveurl now33:'+o_url)
    try:
        if '[' not in o_url and not 'shift8web' in o_url and 't.me' not in o_url and 'tv4kids' not in o_url :
                try:
                        dialog = xbmcgui.DialogBusy()
                        dialog.create()
                except:
                       xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            
                o_url=o_url.replace('%20','')#.replace('https://dood.so','https://dood.to')
                if 'https://dood' in url:
                        from default import resolve_doodstream
                        url=url.replace('dood.to','doodstream.com').replace('dood.so','doodstream.com').replace('dood.so','doodstream.com').replace('dood.cx','doodstream.com').replace('%20','')
                        url=resolve_doodstream(url)
                else:
                    log.warning('11111111:'+str(url))
                    url=url.replace('https://dood.so','https://dood.to').replace('%20','')
                    import resolveurl
                    log.warning('Resolveurl now:'+url)
                    
                    url =resolveurl .HostedMediaFile (url =url ).resolve ()#line:2687
                    log.warning('ResolveD now:'+str(url))
    except:
         url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=15&original_title=%s&id=%s&data=&fanart=%s&url=%s&iconimage=%s&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url,'1','%20','%20',OriginalTitle,id,icon,que(name),icon,'',que(plot),'',que(name),que(name))
         xbmc.executebuiltin('RunPlugin(%s)'%url)
    else:
        try:
                dialog = xbmcgui.DialogBusy()
                dialog.create()
        except:
               xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        url=resolve_link(o_url,id,all_data['plot'],name,icon,fan)
    
    
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)
    if 'telemedia' in url:
        xbmc.executebuiltin('RunPlugin(%s)'%url)
    else:
      
        listItem.setProperty('IsPlayable', 'true')

        ok=xbmc.Player().play(url,listitem=listItem,windowed=False)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        # ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    thread=[]

    if 'youtube' not in o_url:
        from default import jump_seek
        thread.append(Thread(jump_seek,name,o_url,que(video_info),id,icon,fan,plot,table_name))
        
    
        thread[0].start()
    else:
       playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
       base_header = {
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Accept': '*/*',
        'DNT': '1',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        }
       import requests,random
       if KODI_VERSION<19:
            x=requests.get(o_url,headers=base_header).content
       else:
           x=requests.get(o_url,headers=base_header).content.decode('utf-8')
       
       matche = re.compile('ytInitialData = (.+?)};',re.DOTALL).findall(x)
       all_j=json.loads(matche[0]+'}')
       log.warning(json.dumps(all_j))
       rand=random.randint(0,len(all_j['playerOverlays']['playerOverlayRenderer']['endScreen']['watchNextEndScreenRenderer']['results'])-1)
       title=all_j['playerOverlays']['playerOverlayRenderer']['endScreen']['watchNextEndScreenRenderer']['results'][rand]['endScreenVideoRenderer']['title']['simpleText']
       link_id=all_j['playerOverlays']['playerOverlayRenderer']['endScreen']['watchNextEndScreenRenderer']['results'][rand]['endScreenVideoRenderer']['videoId']
       link='plugin://plugin.video.kids_new/?mode=5&description={0}&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D{1}&iconimage=&fanart=&video_info={2}&mode=5&id=&name={3}'.format('next',link_id,'',title)
       listItem = xbmcgui.ListItem(title, path=link) 
       playlist.add(url=link,listitem=listItem)

params=get_params()


selected_scrapers='All'
url=None
name=''
o_name=''
mode=None
iconimage=None
fanart=None
description=None
data=None
original_title=None
read_data2=''
id='0'
dates='0'
season='0'
episode='0'
show_original_year='0'
nextup='true'
dd=''
video_data={}
get_sources_nextup='false'
all_w={}
use_filter='true'
use_rejected='true'
heb_name=''
tmdbid=''
has_alldd='false'
prev_name=''
search_db=''
video_info={}
try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass
try:        
        data=(params["data"])
except:
        pass
try:        
        original_title=unque(params["original_title"])
except:
        pass
        
try:        
        id=(params["id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass
try:        
        show_original_year=(params["show_original_year"])
except:
        pass
try:        
        dd=(params["dd"])
except:
        pass
try:        
        nextup=(params["nextup"])
except:
        pass
try:        
        dates=(params["dates"])
except:
        pass
try:        
        video_data=unque(params["video_data"])
except:
        pass
try:        
        get_sources_nextup=(params["get_sources_nextup"])
except:
        pass
        
try:        
        all_w=unque(params["all_w"])
except:
        pass
        
try:        
        use_filter=(params["use_filter"])
except:
        pass
        
try:        
        use_rejected=(params["use_rejected"])
except:
        pass
try:        
        heb_name=unque(params["heb_name"])
except:
        pass
        
try:        
        tmdbid=str(params["tmdbid"])
except:
        pass
try:        
        has_alldd=str(params["has_alldd"])
except:
        pass
prev_name=name
try:        
        prev_name=unque(params["prev_name"])
except:
        pass
try:        
        search_db=unque(params["search_db"])
except:
        pass

try:        
        from_seek=(params["from_seek"])=='True'
except:
        pass

try:
    url=url.replace(' ','%20')  
except:
    pass
try:
    video_info=unque(params["video_info"])
except:
        pass
try:
    o_name=unque(params["o_name"])
except:
        pass
            
#html=cache.get(cfscrape_version,24, table='posters')
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)

public.pre_mode=mode
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time+777)

    
if mode==None :
       elapsed_time = time.time() - start_time_start
       time_data.append(elapsed_time+555)
       time_data= main_menu(time_data)
        

elif mode==2:
    movie_world()
elif mode==3:
    tv_show_menu()
elif mode==5:
    
    from resources.modules.tmdb import get_movies
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = que(keyboard.getText().replace("'",""))
    if search_entered=='':
     sys.exit()
    if len(Addon.getSetting("firebase"))>0:
        from default import write_search
        thread=[]
        table_name='search_mando'
        free=''
        thread.append(Thread(write_search,unque(search_entered.replace("'","%27")),free,table_name))

        thread[0].start()
    from default import search_tvdb
    thread=[]
    thread.append(Thread(search_tvdb,search_entered))
   
    thread[0].start()
    try:
        dialog = xbmcgui.DialogBusy()
        dialog.create()
    except:
       xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32024), id,27,False,fanart=' ', iconimage=' ',plot=' ')
    get_movies('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&append_to_response=origin_country&page=1'.format(search_entered,lang),global_s=True)
    
    addNolink( '[COLOR blue][I]%s[/I][/COLOR]'%Addon.getLocalizedString(32099), id,27,False,fanart=' ', iconimage=' ',plot=' ')
    get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(search_entered,lang),global_s=True)
    addNolink( '[COLOR blue][I]TVDB[/I][/COLOR]', id,27,False,fanart=' ', iconimage=' ',plot=' ')
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT ,""free TEXT);" % ('search'))

    dbcur.execute("SELECT * FROM search ")
    match_search = dbcur.fetchall()
    all_pre_search=[]
    for nm,fr in match_search:
        all_pre_search.append(nm)
    if unque(search_entered) not in all_pre_search :
         
         dbcur.execute("INSERT INTO search Values ('%s','%s')"%(unque(search_entered.replace("'","%27")),' '))
         dbcon.commit()
         dbcon.close()

    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),tvdb_results,len(tvdb_results))
elif mode==6:
    from default import play_link
    play_link(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year,dd,heb_name,prev_name=prev_name,has_alldd=has_alldd,nextup=nextup,video_data_exp=video_data,get_sources_nextup=get_sources_nextup,all_w=all_w,tvdb_id=tmdbid)
elif mode==14:
   
    from resources.modules.tmdb import get_movies
    
    log.warning('url:'+str(url))
    if '/search/tv' in url and 'page=1' in url :
        if '%' in url:
            search_entered=''
            keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש')
            keyboard.doModal()
            if keyboard.isConfirmed() :
                   search_entered = que(keyboard.getText().replace("'",""))
                   if search_entered=='':
                    sys.exit()
            
        else:
            
            regex='&query=(.+?)&'
            search_entered=re.compile(regex).findall(url.replace(' ','%20'))[0]
        from default import search_tvdb
        thread=[]
        thread.append(Thread(search_tvdb,search_entered))
   
        thread[0].start()
    
        
            
        get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(search_entered,lang),global_s=True)
        addNolink( '[COLOR blue][I]TVDB[/I][/COLOR]', id,27,False,fanart=' ', iconimage=' ',plot=' ')
        while(1):
            num_live=0
            still_alive=0
            if not thread[0].is_alive():
                  num_live=num_live+1
                  
            else:
                    still_alive=1
            if still_alive==0:
                break
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),tvdb_results,len(tvdb_results))
    else:
        get_movies(url.replace(' ','%20'))
elif mode==15:
    from default import get_sources

    # original_title=original_title.replace('&','and').replace('?','')
    get_sources(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year,heb_name,video_data_exp=video_data,all_w=all_w,use_filter=use_filter,use_rejected=use_rejected,tvdb_id=tmdbid)
elif mode==16:
    from  resources.modules.client import get_html
    if 'tvdb' in id :
        url2='https://'+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=tvdb_id&language=%s'%(id.replace('tvdb',''),lang)
        pre_id=get_html(url2).json()['tv_results']
        
        if len(pre_id)>0:
            id=str(pre_id[0]['id'])
    elif 'imdb' in id:
        url2='https://'+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=%s'%(id.replace('imdb',''),lang)
       
        pre_id=get_html(url2).json()['tv_results']
        
        if len(pre_id)>0:
            id=str(pre_id[0]['id'])
    from resources.modules.tmdb import get_seasons
    
    get_seasons(name,url,iconimage,fanart,description,data,original_title,id,heb_name)
elif mode==18:
    from default import get_genere
    get_genere(url)
elif mode==19:
    
    from resources.modules.tmdb import get_episode
    get_episode(name,url,iconimage,fanart,description,data,original_title,id,season,tmdbid,show_original_year,heb_name)
elif mode==20:
    from default import get_tv_maze
    get_tv_maze(url,iconimage)
elif mode==21:
    trakt_world()
elif mode==25:
    from default import play_trailer
    play_trailer(id,url,description)
elif mode==34:
    from default import remove_from_trace
    remove_from_trace(name,original_title,id,season,episode)
elif mode==35:
    from default import ClearCache
    ClearCache()
elif mode==65:
    from default import add_remove_trakt
    add_remove_trakt(name,original_title,id,season,episode)
elif mode==72: 
    from default import by_actor
    by_actor(url,iconimage,fanart)
elif mode==73: 
    from default import actor_m
    actor_m(url,description)
elif mode==74: 
    from default import search_actor
    search_actor()
elif mode==101:
    tv_neworks()
elif mode==112:
    movie_prodiction()

elif mode==114:
    main_trakt()
elif mode==115:
    from resources.modules.trakt import progress_trakt
    progress_trakt(url)
elif mode==116:
    from resources.modules.trakt import get_trakt
    get_trakt(url)
elif mode==117:
    from resources.modules.trakt import get_trk_data
    get_trk_data(url)
elif mode==118:
    from resources.modules.trakt import trakt_liked
    trakt_liked(url,iconimage,fanart)
elif mode==119:
    from resources.modules.trakt import get_simple_trakt
    get_simple_trakt(url)
elif mode==137:
    from default import clear_rd
    clear_rd()
elif mode==138:
    from default import re_enable_rd
    re_enable_rd()
elif mode==139:
    from default import clear_pr
    clear_pr()
elif mode==140:
    from default import re_enable_pr
    re_enable_pr()
elif mode==141:
    from default import clear_all_d
    clear_all_d()
elif mode==142:
    from default import re_enable_all_d
    re_enable_all_d()
elif mode==143:
    # from default import search_history
    search_history(url,iconimage,fanart)
elif mode==144:
   from default import last_played
   last_played()
elif mode==145:
   #read_data2,enc_data,all_folders,url_o=last_viewed(url)
   from default import last_viewed
   read_data2,enc_data,all_folders,url_o=cache.get(last_viewed,24,url, table='last_view')
   aa=[]
   if len(all_folders)>0:
        for name, url,mode, icon,added_res_trakt,all_w,heb_name,fanart,data_ep,plot,original_title,id,season,episode,eng_name,watched,show_original_year,dates,dd in all_folders:
            aa.append(addNolink(name, url,mode,False, iconimage=icon,all_w_trk=added_res_trakt,all_w=all_w,heb_name=heb_name,fanart=fanart,data=data_ep,plot=plot,original_title=original_title,id=id,season=season,episode=episode,eng_name=eng_name,watched=watched,show_original_year=show_original_year,dates=dates,dd=dd,dont_place=True))
            
        if Addon.getSetting("trakt_access_token")!='' and url_o=='tv':
            aa.append(addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32114), id,157,False,fanart='https://bestdroidplayer.com/wp-content/uploads/2019/06/trakt-what-is-how-use-on-kodi.png', iconimage=BASE_LOGO+'trakt.png',plot=' ',dont_place=True))
            
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))
elif mode==146:
    from default import s_tracker
    s_tracker(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year,dates,heb_name)
elif mode==147:
    from default import clear_trakt
    clear_trakt()
elif mode==148:
    from default import clear_search
    clear_search(url)
elif mode==149:
    from default import show_updates
    show_updates(force=True)
elif mode==150:
    from resources.modules.trakt import manager
   
    manager(name, url, data)
elif mode==151:
    Addon.openSettings()
elif mode==157:
    from default import sync_trk
    ok=xbmcgui.Dialog().yesno("Override",('%s (%s)'%(Addon.getLocalizedString(32150),Addon.getAddonInfo('name'))))
    remove_db=False
    show_msg=True
    
    if ok:
        remove_db=True
        show_msg=False
    sync_trk(removedb=False,show_msg=show_msg)
    if remove_db:
        show_msg=True
        sync_trk(removedb=True,show_msg=show_msg)
       
elif mode==158:
    from default import was_i
    was_i(url)
elif mode==159:
    from default import remove_was_i
    remove_was_i(name,id,season,episode)
elif mode==160:
    from resources.modules.trakt import remove_trk_resume
    remove_trk_resume(name,id,season,episode,data)
elif mode==162:
    from default import clear_was_i
    clear_was_i()
elif mode==163:
    from resources.modules import logupload
    logupload.start()
elif mode==164:
    from resources.modules.trakt import resume_episode_list
    resume_episode_list(url)
elif mode==166:
    from resources.modules.trakt import get_simple_trk_data
    get_simple_trk_data(url)
elif mode==167:
    from default import set_view_type
    set_view_type(str(url))
elif mode==168:
    from default import rd_history
    rd_history(url)
elif mode==169:
    from default import rd_history_torrents
    rd_history_torrents()
elif mode==170:
    from default import simple_play
    simple_play(name,url)
elif mode==171:
    from default import remove_rd_history
    remove_rd_history(name,id)
elif mode==172:
    from default import server_test
    server_test()
elif mode==173:
    from default import en_dis_scrapers
    en_dis_scrapers(name,url)
elif mode==174:
    from default import classic_movies
    classic_movies(url)
elif mode==175:
    if '.fullChan' in description:
        url=resolve_chan(url)
        episode='0'
        season='0'
    listItem = xbmcgui.ListItem(name, path=url) 
    listItem.setInfo(type='Video', infoLabels={'title':name})
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
elif mode==176:
    from default import westwern_movies
    westwern_movies(url)
elif mode==177:
    from default import get_cast
    get_cast(url,id,season,episode)
elif mode==178:
    from default import get_3d
    get_3d(url)
elif mode==179:
    from default import collection_detials
    collection_detials(id)
elif mode==180:
      try:
        path=xbmc_tranlate_path('special://home/addons/script.module.resolveurl/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.six/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.kodi-six/libs')
        sys.path.append( path)
        import resolveurl
        resolveurl.display_settings()
      except:
        pass
elif mode==181:
    from default import all_test_menu
    all_test_menu(iconimage,fanart)
elif mode==182:
    from default import run_system_test
    run_system_test(url)
elif mode==183:
    from default import imdb_menu
    imdb_menu(iconimage,fanart)
elif mode==184:
    from default import get_imdb_lists
    get_imdb_lists(url,iconimage,fanart)
elif mode==185:
    from default import fill_imdb_list
    fill_imdb_list(url)
elif mode==186:
    xbmc.executebuiltin('Addon.OpenSettings(script.module.fenomscrapers)')
elif mode==187:
    from default import get_keywords_ab
    get_keywords_ab(iconimage,fanart)
elif mode==188:
    from default import get_keywords
    get_keywords(url,iconimage,fanart,dates)
elif mode==189:
    from default import check_subs
    check_subs()
elif mode==190:
    if Addon.getSetting("p_mod")=='false':
        idan_chan()
    else:
        idan_menu()
        #idan_chan2(fanart)
elif mode==191:
    from default import populate_playlist
    populate_playlist(url,iconimage,fanart,search_db)
elif mode==192:
    from default import search_jen_lists
    search_jen_lists(search_db)
elif mode==193:
    from default import master_addon
    master_addon(url,iconimage,fanart,heb_name,tmdbid,dates,description)
elif mode==194:
    from default import cat_select
    cat_select(iconimage,fanart,url)
elif mode==196:
    from default import play_youtube
    play_youtube(url,name )
elif mode==197:
    from default import cat_full_select
    cat_full_select(iconimage,fanart,url)
    
elif mode==198:
    from default import sync_firebase
    sync_firebase()

elif mode==199:
    
    from resources.modules.tmdb import get_movies

    addNolink( '[COLOR blue][I]---%s---[/I][/COLOR]'%Addon.getLocalizedString(32024), id,27,False,fanart=' ', iconimage=' ',plot=' ')
    url=url.replace('%20',' ')
    get_movies('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&append_to_response=origin_country&page=1'.format(que(url),lang),global_s=True)
    
    addNolink( '[COLOR blue][I]%s[/I][/COLOR]'%Addon.getLocalizedString(32099), id,27,False,fanart=' ', iconimage=' ',plot=' ')
    get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(que(url),lang),global_s=True)
    addNolink( '[COLOR blue][I]TVDB[/I][/COLOR]', id,27,False,fanart=' ', iconimage=' ',plot=' ')


    xbmcplugin .addDirectoryItems(int(sys.argv[1]),tvdb_results,len(tvdb_results))
elif mode==200:
    from default import database_auto

    database_auto()
elif mode==201:
    from default import sex
    sex()
elif mode==202:
    from default import populate_playlist
    populate_playlist(url,iconimage,fanart,search_db,search=True)
elif mode==203:
    movie_db_menu()
elif mode==204:
    # from default import heb_mov_dub
    heb_mov_dub(url,description)
elif mode==205:
    from default import heb_mov_letter
    heb_mov_letter(iconimage,fanart)
elif mode==206:
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = (keyboard.getText().replace("'","%27"))
           if search_entered!='':
              from default import search_result
              search_result(search_entered)
elif mode==207:
    # from default import play_link_db
    play_link_db(name,url,video_info,id,iconimage,fanart,description)
elif mode==208:
    from default import heb_mov_dub_letter
    heb_mov_dub_letter(name,url)
elif mode==209:
    # from default import heb_mov
    heb_mov(url,description)
elif mode==210:
    from default import il_mov_dub
    il_mov_dub(url,description)
elif mode==211:

    search_menu()
elif mode==212:
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = (keyboard.getText().replace("'","%27"))
           if search_entered!='':
              from default import search_result_movie
              search_result_movie(search_entered)
elif mode==213:
    from default import iptv
    iptv()
elif mode==215:
    play_pesek(o_name,url,iconimage,fanart,description,name)
elif mode==216:
    get_fchan()
elif mode==217:
    Satellite1()#pesek
# elif mode==218:
    # Satellite2(fanart)
elif mode==219:
    idan()
elif mode==220:
    Satellite_3()
elif mode==221:
    Satellite_4()
elif mode==222:
    Satellite_1()
elif mode==223:
    Satellite_2()
elif mode==224:
    tv_all()
elif mode==225:
    sport_1()
elif mode==226:
    Satellite_5()
elif mode==227:
    music_ip()
elif mode==228:
    from default import remove_all_from_trace
    remove_all_from_trace(name,original_title,id,season,episode)
elif mode==229:
    from resources.modules.kar import karaoke_menu
    karaoke_menu()
elif mode==230:
    from resources.modules.kar import kar_search
    kar_search()
elif mode==231:
    from resources.modules.kar import category
    category(url,iconimage,fanart)
elif mode==232:
    from resources.modules.kar import play_link_kar
    play_link_kar(name,url)

match=[]
elapsed_time = time.time() - start_time_start
time_data.append(elapsed_time)
if Addon.getSetting("display_lock")=='true':
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""mode TEXT,""name TEXT, ""id TEXT, ""type TEXT, ""free TEXT,""free2 TEXT);"%'views')
    try:
        dbcur.execute("SELECT * FROM views where (mode='%s' or free='global')"%(str(mode)))


                
        match = dbcur.fetchall()
    except:
        match=[]
    dbcur.close()
    dbcon.close()
all_modes=[]


type='%s default'%Addon.getAddonInfo('name')
for mode,name,id,type,free1,free2 in match:
        all_modes.append(mode)

if mode=='global':
    type='%s default'%Addon.getAddonInfo('name')
# log.warning('type:'+type)
if type=='files' or type=='movies' or type=='tvshows' or type=='episodes':
    #log.warning('setContent:'+type)
    xbmcplugin.setContent(int(sys.argv[1]), type)
else:
    if mode==2 or mode==3 or mode==114 or mode==112 or mode==101:
        xbmcplugin.setContent(int(sys.argv[1]), 'files')
    elif mode==16 :
       xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    elif mode==19 or mode==20 or sort_by_episode:
       xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    else:
        # log.warning('Set Type:movies')
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')

if len(all_modes)>0:
    
    #log.warning('Container.SetViewMode(%d)' % int(id))
    xbmc.executebuiltin('Container.SetViewMode(%d)' % int(id))

xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)

    

