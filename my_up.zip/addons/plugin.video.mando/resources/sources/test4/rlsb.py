# -*- coding: utf-8 -*-
import re,xbmc,logging
import time
from  resources.modules.client import get_html
global global_var,stop_all#global
global_var=[]
stop_all=0

 
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,base_header
from  resources.modules import cache
try:
    from resources.modules.general import Addon
except:
  import Addon
type=['movie','api']

import urllib,base64,json

def get_links(tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
        search_url=clean_name(original_title,1).replace(' ','%20')
    else:
        search_url=clean_name(original_title,1).replace(' ','%20')+'%20s{0}e{1}'.format(season_n,episode_n)
    # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', original_title)))
        
      
    
      
    
    
    all_links=[]
    
    all_l=[]
    
    if 1:
      
        
            
        x=get_html('http://search.rlsbb.ru/?s=%s'%(search_url),headers=base_header,timeout=10,verify=False).content()
        
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', x)))
        regex='<tr class="text-center">(.+?)</tr>'
        m_pre=re.compile(regex,re.DOTALL).findall(x)
        
        for item in m_pre:
            # regex='flaticon-.+?a href="(.+?)">(.+?)<.+?"coll-4 size mob-user">(.+?)<'
            regex='weight:bold;"> <a href="(.+?)">'
            m=re.compile(regex,re.DOTALL).findall(item)
            
            for lk in m:
                
                # ,nm,size
                y=get_html(lk,headers=base_header,timeout=10,verify=False).content()
                logging.warning('fro332:  '+str(y))
                
                size='1000'
                regex='href="(.+?)"'
                # m2=re.compile(regex,re.DOTALL).findall(y)
                # logging.warning('fro9999:  '+str(m2))
                title='luca'
                m2='https://uploadgig.com/file/download/dda0529cFc7b48fE/F.a.F.F9.The.Fast.Saga.2021.DC.WEBRip.x264.ION10.75277.mp4'
                
                res_c=title
                if '4k' in res_c:
                      res='2160'
                elif '2160' in res_c:
                      res='2160'
                elif '1080' in res_c:
                      res='1080'
                elif '720' in res_c:
                      res='720'
                elif '480' in res_c:
                      res='480'
                elif '360' in res_c:
                      res='360'
                else:
                      res='HD'
                try:
                     o_size=size#.decode('utf8','ignore')
                     
                     size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                     if 'MB' in o_size:
                       size=size/1000
                except Exception as e:
                    
                    size=1000
            
    
    
                          
                res='2160'
                max_size=int(Addon.getSetting("size_limit"))
           
                # if size<max_size:
                   
                all_links.append((title,'Direct_link$$$resolveurl'+m2+'resolveurl2',str(size),res))
           
                global_var=all_links
                         
    
    return global_var
        
    