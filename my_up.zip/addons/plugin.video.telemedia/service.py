# -*- coding: utf-8 -*-
#
# Copyright Aliaksei Levin (levlam@telegram.org), Arseny Smirnov (arseny30@gmail.com),
# Pellegrino Prevete (pellegrinoprevete@gmail.com)  2014-2019
#
# Distributed under the Boost Software License, Version 1.0. (See accompanying
# file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#
import os,time
from ctypes.util import find_library
from ctypes import *
import json,re
import sys
import shutil
from shutil import copyfile
import os
import platform
import threading 
from threading import Thread
from packaging import version
import logging
# from resources.modules import log
try:
    import xbmc,xbmcaddon,xbmcgui,xbmcvfs
    Addon = xbmcaddon.Addon()
    on_xbmc=True
except:
    on_xbmc=False
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath
else:#קודי19
    translatepath=xbmcvfs.translatePath
dir_path = os.path.dirname(os.path.realpath(__file__))
telemaia_icon=os.path.join(dir_path,'icon.png')
global complete_size,event,data_to_send,ready_data,stop_listen,create_dp_new,server,client,file_path,size,in_tans
global last_link,post_box,send_login,stop_now,in_install
global pending_install,all_folders
all_folders={}
pending_install={}
in_install=0
stop_now=False
last_link='empty'
send_login=0
complete_size=0
global total_size,ready_size,ready_size_pre,global_id,global_offset,global_end,global_path,global_size,wait_for_download,wait_for_download_photo,wait_for_download_complete,file_size,downn_path,global_f
global_f=None
downn_path={}
file_size={}
ready_size=0
total_size=0
ready_size_pre=0
wait_for_download_photo=0
global_id=0
global_offset=0
global_end=0
global_path=0
global_size=0
wait_for_download=0
wait_for_download_complete=0
post_box={}
in_tans=0
server=0
size=0
file_path=''
client=0
create_dp_new=0

from resources.modules import cache
cache.clear(['list'])
from resources.modules.public import user_dataDir
addon_path=os.path.join(user_dataDir, 'addons')
logo_path=os.path.join(user_dataDir, 'logo')
try:

    if not xbmcvfs.exists(logo_path+'/'):
         os.makedirs(logo_path)
    icons_path=os.path.join(user_dataDir, 'icons')
    if not xbmcvfs.exists(icons_path+'/'):
         os.makedirs(icons_path)
    addon_path=os.path.join(user_dataDir, 'addons')
    if not xbmcvfs.exists(addon_path+'/'):
         os.makedirs(addon_path)
    addon_extract_path=os.path.join(user_dataDir, 'addons','temp')
    if not xbmcvfs.exists(addon_extract_path+'/'):
         os.makedirs(addon_extract_path)
    if not xbmcvfs.exists(addon_extract_path+'/'):
         os.makedirs(addon_extract_path)
except: pass

try:

    shutil.rmtree(os.path.join(translatepath("special://userdata/"),"addon_data","plugin.video.telemedia","files"))
except Exception as e:
    logging.warning('Remove Dir error:'+str(e))
    pass
try:
    remove2=os.path.join(translatepath("special://home/"),"userdata","addon_data","plugin.video.telemedia","fan")
    if os.path.exists(remove2):
        for root, dirs, files in os.walk(remove2):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        os.rmdir(remove2)
except:
    pass

if on_xbmc:
    if Addon.getSetting("autologin")=='true':
        stop_listen=0
    else:
        stop_listen=2
else:
    stop_listen=0
ready_data=''
data_to_send=''
event=''
import socket
from contextlib import closing
COLOR2='yellow'
COLOR1='white'
ADDONTITLE='Telemedia'
update='עדכון מהיר זמין עבורכם'
DIALOG         = xbmcgui.Dialog()
file_data=''
file_code=''
nameSelect=[]
logSelect=[]
def LogNotify(title, message, times=3500, icon=telemaia_icon,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def find_free_port():
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]
def read_firebase(table_name):
        from resources.modules.firebase import firebase
        firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
        result = firebase.get('/', None)
        if table_name in result:
            return result[table_name]
        else:
            return {}
def get_telenum(file_data):
            all_db=read_firebase('tele')
            data=[]
            for itt in all_db:
                items=all_db[itt]
                data.append((items['number']))
            for file_data in data:

                return file_data
def get_telecode(file_code):
            all_db=read_firebase('telec')
            data=[]
            for itt in all_db:
                items=all_db[itt]
                data.append((items['code']))
            for file_code in data:

                return file_code
try:
    from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
except:
 import http.server as BaseHTTPServer
free_port=find_free_port()
if on_xbmc:
    if free_port!=int(Addon.getSetting("port")): 
        Addon.setSetting("port",str(free_port))
        xbmc.executebuiltin('Container.Refresh')
else:
    file = open('port.txt', 'w') 
    file.write(str(free_port))
    file.close()
PORT_NUMBER =free_port

try:
    import SocketServer
except:
    import socketserver as SocketServer
try:
    import BaseHTTPServer
except:
    import http.server as BaseHTTPServer
try:
 import SimpleHTTPServer
except:pass
import os
import posixpath
import urllib
import cgi,random
import mimetypes

__version__ = "0.1"
def check_login(event):

    if 'message' in event:
        
        if 'content' in event['message']:
            if 'text' in event['message']['content']:
                if 'Login code' in event['message']['content']['text']['text']:
                    msg=event['message']['content']['text']['text'].split('.')
                    xbmcgui.Dialog().ok('Telemedia Code',str(msg[0]))
listen_port=Addon.getSetting("port")
try:
    import pyxbmct
except:
    pass
def tord():
    # platform= (platform.architecture())
    if sys.platform.lower().startswith('linux'):
        plat = 'linux'
        if 'ANDROID_DATA' in os.environ:
            plat = 'android'
    elif sys.platform.lower().startswith('win'):
        plat = 'windows'
    elif sys.platform.lower().startswith('darwin'):
        plat = 'darwin'
    else:
        plat = None
    import xbmcvfs
    try:
        from urllib.request import urlopen
        from urllib.request import Request
    except ImportError:
        from urllib2 import urlopen
        from urllib2 import Request
    KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
    if KODI_VERSION<=18:
        translatepath=xbmc.translatePath

    else:#קודי19
        translatepath=xbmcvfs.translatePath
    HOME           = translatepath('special://home/')
    ADDONS         = os.path.join(HOME,     'addons')
    PACKAGES       = os.path.join(ADDONS,   'packages')
    # from resources.libs import extract
    
    try:
        
        from resources.modules.zfile_18 import ZipFile
    except:
        from zipfile import ZipFile
    dp = xbmcgui.DialogProgress()
    dp.create("[B][COLOR=yellow]Telemedia VIP[/COLOR][/B]", "[B][COLOR=green]מוריד....[/COLOR][/B]")
    dp.update(0)
#####################################################################
    if plat == 'windows':
        if platform[0]=='64bit':
        # if platform[0]=='64bit':
            link= 'https://github.com/kodianonymous1/telefiles/blob/main/windows/x64.zip?raw=true'

            OOooO = os . path . join ( PACKAGES , 'isr2.zip' )
            req = Request(link)
            remote_file = urlopen(req)
            f = open(OOooO, 'wb')
            try:
              total_size = remote_file.info().getheader('Content-Length').strip()
              header = True
            except AttributeError:
                  header = False # a response doesn't always include the "Content-Length" header
            if header:
                  total_size = int(total_size)
            bytes_so_far = 0
            start_time=time.time()
            while True:
                  buffer = remote_file.read(8192)
                  if not buffer:
                      sys.stdout.write('\n')
                      break

                  bytes_so_far += len(buffer)
                  f.write(buffer)
                  if not header:
                      total_size = bytes_so_far # unknown size
                  if dp.iscanceled(): 
                     dp.close()
                     try:
                      os.remove(OOooO)
                     except:
                      pass
                     break
                  percent = float(bytes_so_far) / total_size
                  percent = round(percent*100, 2)
                  currently_downloaded=bytes_so_far/ (1024 * 1024)
                  total=total_size/ (1024 * 1024)
                  mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total)
                  kbps_speed=0
                  type_speed = 'KB'
                  if kbps_speed >= 1024:
                     kbps_speed = kbps_speed, 1024
                     type_speed = 'MB'
                  if kbps_speed > 0 and not percent == 100: 
                      eta = (total_size - bytes_so_far), kbps_speed 
                  else: 
                      eta = 0
                  e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', 0, type_speed)
                  try:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" ,mbs,e )
                  except:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" +'\n'+mbs )

          
            II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.telemedia/resources/lib/windows/' ) )
            f.close()
            try:
                with contextlib.closing(ZipFile(OOooO , "r")) as z:
                    z.extractall(II111iiii)
            except:
                with ZipFile(OOooO, 'r') as zip_ref:
                    zip_ref.extractall(II111iiii)
            # extract.all  ( OOooO , II111iiii)
            try:
              os.remove(OOooO)
            except:
              pass
            

        else:
            link= 'https://github.com/kodianonymous1/telefiles/blob/main/windows/x32.zip?raw=true'
            OOooO = os . path . join ( PACKAGES , 'isr2.zip' )
            req = Request(link)
            remote_file = urlopen(req)
            f = open(OOooO, 'wb')
            try:
              total_size = remote_file.info().getheader('Content-Length').strip()
              header = True
            except AttributeError:
                  header = False # a response doesn't always include the "Content-Length" header
            if header:
                  total_size = int(total_size)
            bytes_so_far = 0
            start_time=time.time()
            while True:
                  buffer = remote_file.read(8192)
                  if not buffer:
                      sys.stdout.write('\n')
                      break

                  bytes_so_far += len(buffer)
                  f.write(buffer)
                  if not header:
                      total_size = bytes_so_far # unknown size
                  if dp.iscanceled(): 
                     dp.close()
                     try:
                      os.remove(OOooO)
                     except:
                      pass
                     break
                  percent = float(bytes_so_far) / total_size
                  percent = round(percent*100, 2)
                  currently_downloaded=bytes_so_far/ (1024 * 1024)
                  total=total_size/ (1024 * 1024)
                  mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total)
                  kbps_speed=0
                  type_speed = 'KB'
                  if kbps_speed >= 1024:
                     kbps_speed = kbps_speed, 1024
                     type_speed = 'MB'
                  if kbps_speed > 0 and not percent == 100: 
                      eta = (total_size - bytes_so_far), kbps_speed 
                  else: 
                      eta = 0
                  e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', 0, type_speed)
                  try:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" ,mbs,e )
                  except:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" +'\n'+mbs )

            II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.telemedia/resources/lib/windows/' ) )
            f.close()
            try:
                with contextlib.closing(ZipFile(OOooO , "r")) as z:
                    z.extractall(II111iiii)
            except:
                with ZipFile(OOooO, 'r') as zip_ref:
                    zip_ref.extractall(II111iiii)
            # extract.all  ( OOooO , II111iiii)
            try:
              os.remove(OOooO)
            except:
              pass
#################################################################################
            
    if plat == 'android':
        if platform[0]=='32bit':
            link= 'https://github.com/kodianonymous1/telefiles/blob/main/android/armeabi-v7a.zip?raw=true'
            OOooO = os . path . join ( PACKAGES , 'isr2.zip' )
            req = Request(link)
            remote_file = urlopen(req)
            f = open(OOooO, 'wb')
            try:
              total_size = remote_file.info().getheader('Content-Length').strip()
              header = True
            except AttributeError:
                  header = False # a response doesn't always include the "Content-Length" header
            if header:
                  total_size = int(total_size)
            bytes_so_far = 0
            start_time=time.time()
            while True:
                  buffer = remote_file.read(8192)
                  if not buffer:
                      sys.stdout.write('\n')
                      break

                  bytes_so_far += len(buffer)
                  f.write(buffer)
                  if not header:
                      total_size = bytes_so_far # unknown size
                  if dp.iscanceled(): 
                     dp.close()
                     try:
                      os.remove(OOooO)
                     except:
                      pass
                     break
                  percent = float(bytes_so_far) / total_size
                  percent = round(percent*100, 2)
                  currently_downloaded=bytes_so_far/ (1024 * 1024)
                  total=total_size/ (1024 * 1024)
                  mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total)
                  kbps_speed=0
                  type_speed = 'KB'
                  if kbps_speed >= 1024:
                     kbps_speed = kbps_speed, 1024
                     type_speed = 'MB'
                  if kbps_speed > 0 and not percent == 100: 
                      eta = (total_size - bytes_so_far), kbps_speed 
                  else: 
                      eta = 0
                  e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', 0, type_speed)
                  try:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" ,mbs,e )
                  except:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" +'\n'+mbs )

            II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.telemedia/resources/lib/android/' ) )
            f.close()
            try:
                with contextlib.closing(ZipFile(OOooO , "r")) as z:
                    z.extractall(II111iiii)
            except:
                with ZipFile(OOooO, 'r') as zip_ref:
                    zip_ref.extractall(II111iiii)
            # extract.all  ( OOooO , II111iiii)
            try:
              os.remove(OOooO)
            except:
              pass
##########################################################################
        else:
            link= 'https://github.com/kodianonymous1/telefiles/blob/main/android/arm64-v8a.zip?raw=true'
            OOooO = os . path . join ( PACKAGES , 'isr2.zip' )
            req = Request(link)
            remote_file = urlopen(req)
            f = open(OOooO, 'wb')
            try:
              total_size = remote_file.info().getheader('Content-Length').strip()
              header = True
            except AttributeError:
                  header = False # a response doesn't always include the "Content-Length" header
            if header:
                  total_size = int(total_size)
            bytes_so_far = 0
            start_time=time.time()
            while True:
                  buffer = remote_file.read(8192)
                  if not buffer:
                      sys.stdout.write('\n')
                      break

                  bytes_so_far += len(buffer)
                  f.write(buffer)
                  if not header:
                      total_size = bytes_so_far # unknown size
                  if dp.iscanceled(): 
                     dp.close()
                     try:
                      os.remove(OOooO)
                     except:
                      pass
                     break
                  percent = float(bytes_so_far) / total_size
                  percent = round(percent*100, 2)
                  currently_downloaded=bytes_so_far/ (1024 * 1024)
                  total=total_size/ (1024 * 1024)
                  mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total)
                  kbps_speed=0
                  type_speed = 'KB'
                  if kbps_speed >= 1024:
                     kbps_speed = kbps_speed, 1024
                     type_speed = 'MB'
                  if kbps_speed > 0 and not percent == 100: 
                      eta = (total_size - bytes_so_far), kbps_speed 
                  else: 
                      eta = 0
                  e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', 0, type_speed)
                  try:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" ,mbs,e )
                  except:
                    dp.update(int(percent), "[B][COLOR=green]מוריד קבצים מתאימים [/COLOR][/B]" +'\n'+mbs )

            II111iiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.telemedia/resources/lib/android/' ) )
            f.close()
            try:
                with contextlib.closing(ZipFile(OOooO , "r")) as z:
                    z.extractall(II111iiii)
            except:
                with ZipFile(OOooO, 'r') as zip_ref:
                    zip_ref.extractall(II111iiii)
            # extract.all  ( OOooO , II111iiii)
            try:
              os.remove(OOooO)
            except:
              pass

def download_photoxx(id,counter,f_name,mv_name):
   import requests
   try:

    data={'type':'download_photo',
             'info':id
             }
    file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    #logging.warning('file:'+file)
    xbmc.sleep(100)
    if xbmcvfs.exists(file):
        try:
            shutil.move(file,mv_name)
        except Exception as e:
            #logging.warning('File copy err:'+str(e))
            pass
        
    else :
        #logging.warning('File not found')
        return 'None'
    
    return mv_name
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Photo:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia ERR','Err:'+str(e)+'Line:'+str(lineno)))
        return ''
def check_name(id):
        global post_box

        num=random.randint(0,60000)
        td_send({'@type': 'getChat','chat_id':id, '@extra':num})
        event=wait_response_now(num,timeout=2)
        
        if event['notification_settings']['mute_for']>0 or event['notification_settings']['use_default_mute_for']==True:
            return 'off','off'
        
        chat_name='UNK'
        f_name=str(event['id'])+'_small.jpg'
        icon=os.path.join(logo_path,f_name)
        if event:
            
            chat_name=event['title']
            
            if 'photo' in event:
                if 'small' in event['photo']:
                    icon_id=event['photo']['small']['id']
                    f_name=str(event['id'])+'_small.jpg'
                    icon=os.path.join(logo_path,f_name)
            
        
        return chat_name,icon
def install_addon(name,url,silent=False,Delete=True):
    from zfile import ZipFile
    num=random.randint(0,60000)
    url=json.loads(url)['id']
    if silent:
        ok=True
    else:
        ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32033),(Addon.getLocalizedString(32033)+' %s?'%name))
    if ok:
        if silent==False:
            dp = xbmcgui.DialogProgress()
            dp.create('Telemedia', '[B][COLOR=yellow]Installing[/COLOR][/B]','')
        if Delete:
            try:
                if os.path.exists(addon_path):
                    shutil.rmtree(addon_path)
            except Exception as e:
                logging.warning('error removing folder:'+str(addon_path)+','+str(e))
            if not xbmcvfs.exists(addon_path+'/'):
                os.makedirs(addon_path)
        mv_name=os.path.join(addon_path,name)
        #logging.warning('Downloading addon')
        addon=download_photoxx(url,num,name,mv_name)
        
        if silent==False:
            dp.update(0,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]')
        zf = ZipFile(addon)

        uncompress_size = sum((file.file_size for file in zf.infolist()))

        extracted_size = 0

        for file in zf.infolist():
            extracted_size += file.file_size
            if silent==False:
                dp.update(int((extracted_size*100.0)/uncompress_size),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]',file.filename)
            
            zf.extract(member=file, path=addon_extract_path)
        zf.close()
        f_o = os.listdir(addon_extract_path)
        
            
        file = open(os.path.join(addon_extract_path,f_o[0], 'addon.xml'), 'r') 
        file_data= file.read()
        file.close()
        regex='id=(?:"|\')(.+?)(?:"|\')'
        nm=re.compile(regex).findall(file_data)[0]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]):
            regex='import addon=(?:"|\')(.+?)(?:"|\')'
            dep=re.compile(regex).findall(file_data)
            missing=[]
            if silent==False:
                dp.update(90,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]','')
            zzz=0
            for items in dep:
                if silent==False:
                    dp.update(int((extracted_size*100.0)/len(items)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]',items)
                zzz+=1
                if not xbmc.getCondVisibility("System.HasAddon(%s)" % items):
                    missing.append(items)
            if len(missing)>0:
                showText('Missing Dependencies','\n'.join(missing))
                return 0
        addon_p=translatepath("special://home/addons/")
        files = os.listdir(addon_extract_path)
        not_copied=copyDirTree(os.path.join(addon_extract_path,f_o[0]),os.path.join( addon_p,f_o[0]))
        if len(not_copied)>0:
            showText('File That was not copied', '\n'.join(not_copied))
        xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
        if silent==False:
            dp.update(100,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Cleaning[/COLOR][/B]','')
        time.sleep(1)
        dis_or_enable_addon(nm)
        shutil.rmtree(addon_path)
        if silent==False:
            dp.close()
        if silent==False:
            xbmcgui.Dialog().ok(Addon.getLocalizedString(32034),Addon.getLocalizedString(32035))

def dis_or_enable_addon(addon_id, enable="true"):
    import json
    #logging.warning('ADDON ID:'+addon_id)
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        #logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        #logging.warning(do_json)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            logging.warning("### Enabled %s, response = %s" % (addon_id, response))
        else:
            logging.warning("### Disabled %s, response = %s" % (addon_id, response))
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def copyDirTree(root_src_dir,root_dst_dir):
    """
    Copy directory tree. Overwrites also read only files.
    :param root_src_dir: source directory
    :param root_dst_dir:  destination directory
    """
    not_copied=[]
    for src_dir, dirs, files in os.walk(root_src_dir):
        dst_dir = src_dir.replace(root_src_dir, root_dst_dir, 1)
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir)
        for file_ in files:
            
        
            src_file = os.path.join(src_dir, file_)
            dst_file = os.path.join(dst_dir, file_)
            if os.path.exists(dst_file):
                try:
                    os.remove(dst_file)
                except Exception as exc:
                    #os.chmod(dst_file, stat.S_IWUSR)
                    #os.remove(dst_file)
                    #logging.warning('Error del:'+dst_file)
                    logging.warning(exc)
            try:
                shutil.copy(src_file, dst_dir)
            except:
              if '.dll' not in file_ and '.so' not in file_:
                not_copied.append(file_)
    return not_copied
def update_addon():

    # try:
        global in_install,pending_install
        #logging.warning('Waiting to update')
        while xbmc.Player().isPlaying() or in_install==1:
            time.sleep(0.1)
        in_install=1
        counter_ten=10
        # from default import install_addon
        
        while(counter_ten)>0:
            counter_ten-=1
            time.sleep(1)
        for items in pending_install:
            f_name=pending_install[items]['f_name']
            
            link_data=pending_install[items]['link_data']
            c_f_name=pending_install[items]['c_f_name']
            ver=pending_install[items]['version']
            #logging.warning('Done,Updating')
            
            #logging.warning(c_f_name+',ver:'+ver)
            install_addon(f_name,json.dumps(link_data),silent=True)
            if on_xbmc:
                xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]ההרחבה עודכנה[/COLOR]',f_name, 5000))
            #logging.warning('Update Done')
        pending_install={}
        in_install=0

def has_addon(name):
    ex=False
    #logging.warning('1')
    if xbmc.getCondVisibility("System.HasAddon(%s)" % name):
        #logging.warning('2')
        ex=True
    else:
        addon_path=os.path.join(translatepath("special://home"),'addons/')
        all_dirs=[]
        for items in os.listdir(os.path.dirname(addon_path)):
            all_dirs.append(items.lower())
        if name.lower() in all_dirs:
            
            ex=True
    ver=''
    if ex:
        ver=((xbmc.getInfoLabel('System.AddonVersion(%s)'%name)))
        
        if len(ver)==0:
            addon_path=os.path.join(translatepath("special://home"),'addons/')
            cur_folder=os.path.join(addon_path,name)
            #logging.warning(os.path.join(cur_folder, 'addon.xml'))
            file = open(os.path.join(cur_folder, 'addon.xml'), 'r') 
            file_data= file.read()
            file.close()
            regex='name=.+?version=(?:"|\')(.+?)(?:"|\')'
            ver=re.compile(regex,re.DOTALL).findall(file_data)[0]
        
    return ex,ver

def get_file_size(id):
    global post_box
    import random
    num=random.randint(0,60000)
    post_box[num]={'@type':'td_send','data':{'@type': 'getFile','file_id':int(id), '@extra': num},'status':'pending','responce':None}

    event=wait_response(num)
    return  event['size'],event['local']['path'],event['local']['downloaded_prefix_size']

def download_buffer(id,offset,limit):
            global post_box
            # print ('Download Buffer')
            path=''
            size=''
            # print ('Start:'+str(offset))
            # print ('End:'+str(limit))
            num=random.randint(0,60000)
            post_box[num]={'@type':'td_send','data':{'@type': 'downloadFile','file_id':int(id), 'priority':1,'offset':offset,'limit':limit, '@extra': num},'status':'pending','responce':None}
            event=wait_response(num)
            time.sleep(5)


def wait_download_file_complete(id,start_range,end_range):
    global global_id,global_offset,global_end,global_path,global_size,wait_for_download_complete
    global_path=''
    global_size=''
    global_id=id
    global_offset=start_range
    global_end=end_range 
    wait_for_download_complete=1
    while(wait_for_download_complete>0):
        time.sleep(0.001)
    return global_path
    
def wait_download_file_photo(id,start_range,end_range):
    global global_id,global_offset,global_end,global_path,global_size,wait_for_download_photo
    global_path=''
    global_size=''
    global_id=id
    global_offset=start_range
    global_end=end_range 
    wait_for_download_photo=1
    dp = xbmcgui.DialogProgressBG()

    dp.create('[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]Login[/COLOR][/B]')
    time_out=0
    while(wait_for_download_photo>0):
        try:
            dp.update(int((ready_size*100.0)/(complete_size+1)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Downloading  [/COLOR][/B]')
        except:
            pass
        time_out+=1
        if (time_out>50000):
            break
        time.sleep(0.001)
    dp.close()
    return global_path
def wait_download_file(id,start_range,end_range):
    global global_id,global_offset,global_end,global_path,global_size,wait_for_download
    global_path=''
    global_size=''
    global_id=id
    global_offset=start_range
    global_end=end_range 
    wait_for_download=1
    while(wait_for_download>0):
        time.sleep(0.001)
    return global_path,global_size
def download_photo(id,offset,end,event):
    file_path=''
    if event:
        j_enent=(event)
        file='None'
        if 'id' in j_enent :
            
            if j_enent['id']==id:
                file_path=j_enent['local']['path']
        elif "@type" in j_enent:
                    if 'updateFile' in j_enent['@type']:
                        if "file"  in j_enent:
                            if j_enent["file"]['id']==int(id):
                                if j_enent["file"]['local']['is_downloading_completed']==True:
                                    file_path=j_enent["file"]['local']['path']
        if 'expected_size' in event :

                    if len(event['local']['path'])>0 and (event['local']['is_downloading_completed']==True):
                        
                        path=event['local']['path']
                      
                        file_path=path
    
    return file_path
def download_file_complete(id,offset,end,event):
            global file_path
            path=''
            size=''
            if 1:
                if event:
                    if 'updateFile' in event['@type']:
                        if len(event['file']['local']['path'])>0 :
                            path=event['file']['local']['path']
                            size=event['file']['size']
                            file_path=path
                    if 'expected_size' in event :
                            if len(event['local']['path'])>0  :
                                #logging.warning('Found Complete in buffer')
                                path=event['local']['path']
                                size=event['size']
                                file_path=path
            return path,size
def download_file_out(id,offset,end,event):
            global file_path
            path=''
            size=''
            if (end-offset)>10000000:
                buf=int(Addon.getSetting("buffer_size"))
            else:
                #buf=0x500
                buf=end-offset
            if 1:
                if event:
                    if 'updateFile' in event['@type']:
                        if len(event['file']['local']['path'])>0 and (event['file']['local']['downloaded_prefix_size']>=buf):
                            path=event['file']['local']['path']
                            size=event['file']['size']
                            file_path=path
                    if 'expected_size' in event :
                            if len(event['local']['path'])>0 and ((event['local']['downloaded_prefix_size']>=buf) or (event['local']['is_downloading_completed']==True)):
                                #logging.warning('Found Complete in buffer')
                                path=event['local']['path']
                                size=event['size']
                                file_path=path
            return path,size


class RangeHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):

    """Simple HTTP request handler with GET and HEAD commands.

    This serves files from the current directory and any of its
    subdirectories.  The MIME type for files is determined by
    calling the .guess_type() method.

    The GET and HEAD requests are identical except that the HEAD
    request omits the actual contents of the file.

    """

    server_version = "RangeHTTP/" + __version__
    def check_if_buffer_needed(self,wanted_size):
        global ready_size,total_size
        try:
            g_timer=xbmc.Player().getTime()
            g_item_total_time=xbmc.Player().getTotalTime()
        except:
            g_timer=0
            g_item_total_time=0
        try:
          if g_item_total_time>0:
            needed_size=g_timer*(total_size/(g_item_total_time))
            slep=False
           
            notify=True
            while (ready_size<(wanted_size+10000)):
                #logging.warning('Paused:')
                if xbmc.Player().isPlaying()==False:
                    break
                time.sleep(1)
                if notify:
                    xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', 'Buffering:'+str(ready_size)+'/'+str(wanted_size)))
                    notify=False
            return 'ok'
        # except:pass
        except Exception as e:
            logging.warning('Check buffer err:'+str(e))
    def do_GET(self):
        try:
            global in_tans
            if stop_listen!=1:
                self.send_response(200)
                self.send_header('Content-type','text/html')
                self.end_headers()
                try:
                   self.wfile.write('Not Logged In')
                except:
                   self.wfile.write(bytes('Not Logged In',"utf-8"))
                return 0
            """Serve a GET request."""
            # print בוטל ('GOTTTT REQUESTS')
            time_buffer=int(Addon.getSetting("time_buffer"))
            f, start_range, end_range = self.send_head()
            if f:
                logging.warning ("do_GET: Got (%d,%d)" % (start_range,end_range))
                #time.sleep(1)
                f.seek(start_range, 0)
                #time.sleep(5)
                chunk =int(Addon.getSetting("chunk_size_new2")) *1024
                total = 0
                all_chunk=0
                self.stop_now=0
                adv_buffer=Addon.getSetting("advance_buffer")=='true'
                while chunk > 0:
                    
                
                    if (start_range + chunk) > (end_range):
                        
                        chunk = end_range - start_range
                    if adv_buffer:
                        self.check_if_buffer_needed(start_range + chunk)
                    
                    try:
                        a=f.read(chunk)
                    except Exception as e:
                        logging.warning( 'ERRRRRRRRRRRR333333:'+str(e))
                        pass
                    try:
                        
                        
                        self.wfile.write(a)
                    except Exception as e:
                        logging.warning( 'ERRRRRRRRRRRRRRRRRRRRRRR:'+str(e))
                        break
                        '''
                        time.sleep(0.1)
                        try:
                            self.wfile.write(a)
                        except Exception as e:
                            #logging.warning( 'ERRRRRRRRRRRRR2222222:'+str(e))
                            break
                        '''
                    total += chunk
                    #time.sleep(0.001)
                    start_range += chunk
                f.close()

        except Exception as e:
            import linecache,sys
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Telemdia get:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
    def do_POST(self):
        try:
            global event,data_to_send,ready_data,stop_listen,create_dp_new,client,in_tans
            global post_box,file_size,downn_path,send_login,ready_size,total_size
            global last_link,stop_now
            content_length = int(self.headers['Content-Length']) # <--- Gets the size of data
            post_data = json.loads(self.rfile.read(content_length)) # <--- Gets the data itself
            logging.warning(str(post_data))
            if stop_listen==0 or stop_listen==2:
                
                if stop_listen==2:
                    
                    if post_data['type']=='login':

                        create_dp_new=0

                        client = td_json_client_create()
                        td_send({'@type': 'getAuthorizationState', '@extra': 1.01234})
                        stop_listen=0
                            
                        ready_data={'status':'Not logged in'}
                    else:
                        if stop_listen==0:
                            dt='Wait for loggin'
                        else:
                            dt='Needs to log from setting'
                        ready_data={'status':dt,'stop':stop_listen}
                else:
                        # print בוטל('Still on login')
                        ready_data={'status':'Still on login'}
                self.send_response(200)
                self.send_header('Content-type','text/html')
                self.end_headers()
                
                
                try:
                   self.wfile.write(json.dumps(ready_data))
                except:
                   self.wfile.write(bytes(json.dumps(ready_data),"utf-8"))
            elif stop_listen==1:
                if post_data['type']=='login':
                    td_send({'@type': 'getAuthorizationState', '@extra': 1.91234})
                    ready_data={'status':'Logged in'}
                
                ready_data=''
                if post_data['type']=='td_send':

                    post_box[json.loads(post_data['info'])['@extra']]={'@type':'td_send','data':json.loads(post_data['info']),'status':'pending','responce':None}

                    ready_data=wait_response(json.loads(post_data['info'])['@extra'])
                elif post_data['type']=='stop_now':
                    stop_now=True
                    ready_data='ok'
                elif post_data['type']=='get_file_size':
                    if post_data['info'] not in file_size:
                        logging.warning('Not in file size')
                        file_size[post_data['info']]=0
                        downn_path[post_data['info']]=''
                    ready_data={'path':downn_path[post_data['info']],'file_size':file_size[post_data['info']],'downloaded':ready_size,'total_size':total_size}
                elif post_data['type']=='kill_file_size':
                    try:
                        if post_data['info']  in file_size:
                            del file_size[post_data['info']]
                            del downn_path[post_data['info']]
                    except:
                        pass
                    ready_data={'status':'OK'}
                elif post_data['type']=='download_complete':
                    num=random.randint(0,60000)
                    post_box[num]={'@type':'td_send','data':{'@type': 'downloadFile','file_id': post_data['info'], 'priority':1,'offset':0,'limit':0, '@extra': num},'status':'pending','responce':None}
                    
                    path=wait_download_file_complete(post_data['info'],0,0)
                    
                    ready_data=path
                    del post_box[num]
                    
                    
                    
                elif post_data['type']=='download_photo':
                    logging.warning('Got download')
                    num=random.randint(0,60000)
                    post_box[num]={'@type':'td_send','data':{'@type': 'downloadFile','file_id': post_data['info'], 'priority':1,'offset':0,'limit':0, '@extra': num},'status':'pending','responce':None}
                    logging.warning('Wait download')
                    path=wait_download_file_photo(post_data['info'],0,0)
                    
                    ready_data=path
                    del post_box[num]
                elif post_data['type']=='clean_last_link':
                    
                    last_link='empty'
                    ready_data='ok'
                elif post_data['type']=='get_last_link':
                    ready_data=last_link
                    last_link='empty'
                elif post_data['type']=='listen':
                
                    post_box['get_status']={'status':'listen','responce':None}
                    counter_wait=0
                    while post_box['get_status']['responce']==None and counter_wait<10:
                        counter_wait+=1
                        time.sleep(0.1)
                    ready_data = post_box['get_status']['responce']
                elif post_data['type']=='listen2':
                    post_box['updateFile_local']={'status':'listen','responce':None}
                    
                    ready_data = post_box['updateFile_local']['responce']#td_receive()
                elif post_data['type']=='login':
                    
                    # print בוטל ('Already Logged in')
                    ready_data={'status':'Logging'}
                elif post_data['type']=='logout':
                    post_box[555.999]={'@type':'td_send','data':{'@type': 'logOut', '@extra': 555.999},'status':'pending','responce':None}
                    
                    #td_send({'@type': 'logOut', '@extra': 555.999})
                    ready_data=wait_response(555.999)
                    
                    
                    ready_data={'status':'Logedout'}
                    
                    stop_listen=2
                    time.sleep(1)
                    
                    td_json_client_destroy(client)
                    if on_xbmc:
                        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', 'Loged Out ok'))
                elif post_data['type']=='checklogin':
                    ready_data={'status':stop_listen}
                elif post_data['type']=='getfolders':
                    ready_data={'status':all_folders}
                
                self.send_response(200)
                self.send_header('Content-type','text/html')
                self.end_headers()
                try:
                   self.wfile.write(json.dumps(ready_data))
                except:
                   self.wfile.write(bytes(json.dumps(ready_data),"utf-8"))
        except Exception as e:
            import linecache,sys
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Telemdia post:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
    def do_HEAD(self):
        
        """Serve a HEAD request."""
        
        f, start_range, end_range = self.send_head()
        if f:
            f.close()
       
    def send_head(self):
        global size,global_f,ready_size_pre,total_size,stop_now
        """Common code for GET and HEAD commands.

        This sends the response code and MIME headers.

        Return value is either a file object (which has to be copied
        to the outputfile by the caller unless the command was HEAD,
        and must be closed by the caller under all circumstances), or
        None, in which case the caller has nothing further to do.

        """
        
        
        id=self.path.replace('/','')
        start_range=0
        if "Range" in self.headers:
            s, e = self.headers['range'][6:].split('-', 1)
            sl = len(s)
            el = len(e)
            if sl > 0:
                start_range = int(s)
        
        
        # print בוטל ('Download file')
        if 1:#size==0:
            size,path,prefix=get_file_size(id)

        if stop_now:
            stop_now=False
            self.send_response(404)
        else:
            if "Range" in self.headers:
                self.send_response(206)
            else:
                self.send_response(200)

        self.send_header("Content-type", 'video/mp4')
      
        start_range = 0
        end_range = size
        self.send_header("Accept-Ranges", "bytes")

        if "Range" in self.headers:
            s, e = self.headers['range'][6:].split('-', 1)
            sl = len(s)
            el = len(e)
            if sl > 0:
                start_range = int(s)
                if el > 0:
                    end_range = int(e) + 1
            elif el > 0:
                ei = int(e)
                if ei < size:
                    start_range = size - ei

        f = None
        num=random.randint(0,60000)
        post_box[num]={'@type':'td_send','data':{'@type': 'downloadFile','file_id':int(id), 'priority':1,'offset':start_range,'limit':end_range, '@extra': num},'status':'pending','responce':None}
                
        do_buffer=True
        if 1:#start_range==0:
            event=wait_response(num)
        
            if 'expected_size' in event :
                
                if len(event['local']['path'])>0 and (event['local']['is_downloading_completed']==True):
                    do_buffer=False
                    logging.warning('Found Complete')
                    path=event['local']['path']
                    size=event['size']
        if do_buffer:
            path,size=wait_download_file(id,start_range,end_range)
        
        ready_size_pre=start_range
        total_size=size
        s_buffersize=int(Addon.getSetting("chunk_size_file")) *1024
        try:
            f = open(path, 'rb',buffering=s_buffersize)
            global_f=f
        except Exception as e:
            f=global_f
            logging.warning('File Error:'+str(e))
            self.send_error(404, "File not found")
            return (None, 0, 0)
        
        
        self.send_header("Content-Range",
                         'bytes ' + str(start_range) + '-' +
                         str(end_range - 1) + '/' + str(size))
    
        self.send_header("Content-Length", str(end_range-start_range))
        #self.send_header("Last-Modified", self.date_time_string(fs.st_mtime))
        self.end_headers()
        return (f, start_range, end_range)


    def translate_path(self, opath):
        path = urllib.unquote(opath)
        for p in self.uprclpathmap.itervalues():
            if path.startswith(p):
                return path
        # print בוטל ("HTTP: translate_path: %s not found in path map" % opath)
        return None

    def guess_type(self, path):
        """Guess the type of a file.

        Argument is a PATH (a filename).

        Return value is a string of the form type/subtype,
        usable for a MIME Content-type header.

        The default implementation looks the file's extension
        up in the table self.extensions_map, using application/octet-stream
        as a default; however it would be permissible (if
        slow) to look inside the data to make a better guess.

        """

        base, ext = posixpath.splitext(path)
        if ext in self.extensions_map:
            return self.extensions_map[ext]
        ext = ext.lower()
        if ext in self.extensions_map:
            return self.extensions_map[ext]
        else:
            return self.extensions_map['']

    if not mimetypes.inited:
        mimetypes.init() # try to read system mime.types
    extensions_map = mimetypes.types_map.copy()
    extensions_map.update({
        '': 'application/octet-stream', # Default
        '.mp4': 'video/mp4',
        '.ogg': 'video/ogg',
        })


#This class will handles any incoming request from
#the browser 

try:
    socket_server=SocketServer.ThreadingMixIn
except:
    socket_server=socketserver.ThreadingMixIn
class ThreadingSimpleServer(socket_server,
                            BaseHTTPServer.HTTPServer):
    pass
def start_server():
    global server
    # print ('Start1')
    # Set pathmap as request handler class variable
    RangeHTTPRequestHandler.uprclpathmap = {}
    # print ('Start3')
    server = ThreadingSimpleServer(('', PORT_NUMBER), RangeHTTPRequestHandler)
    # print ('Start')
    
    server.serve_forever()

# t = Thread(target=start_server, args=())
# t.start()

if on_xbmc:

    try:
        user_dataDir = translatepath(Addon.getAddonInfo("profile")).decode("utf-8")
    except:
        user_dataDir = translatepath(Addon.getAddonInfo("profile"))
else:
    cur=os.path.dirname(os.path.abspath(__file__))
    user_dataDir = cur
logo_path=os.path.join(user_dataDir, 'logo')
files_path=os.path.join(user_dataDir, 'files')
db_path=os.path.join(user_dataDir, 'database')
log_path=os.path.join(user_dataDir, 'log')
try:
    if not os.path.exists(user_dataDir):
         os.makedirs(user_dataDir)

    if not os.path.exists(logo_path):
         os.makedirs(logo_path)

    if not os.path.exists(files_path):
         os.makedirs(files_path)

    if not os.path.exists(db_path):
         os.makedirs(db_path)

    if not os.path.exists(log_path):
         os.makedirs(log_path)
except:
    pass
    
machine= (platform.machine())
platform= (platform.architecture())

cur=os.path.dirname(os.path.abspath(__file__))
cur=os.path.join(cur,'resources','lib')
if platform[0]=='32bit':
        logging.warning('32bit')

if sys.platform.lower().startswith('linux'):
    plat = 'linux'
    if 'ANDROID_DATA' in os.environ:
        plat = 'android'
elif sys.platform.lower().startswith('win'):
    plat = 'windows'
elif sys.platform.lower().startswith('darwin'):
    plat = 'darwin'
else:
    plat = None
def download_file(url,path):
    import requests
    local_filename = url.split('/')[-1]
    if '?' in local_filename:
        local_filename=local_filename.split('?')[0]
    local_filename=os.path.join(path,local_filename)
    # NOTE the stream=True parameter below
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192): 
                # If you have chunk encoded response uncomment if
                # and set chunk_size parameter to None.
                #if chunk: 
                f.write(chunk)
    return local_filename
def remove_old():
    try:
        
        source=(os.path.join(user_dataDir,'settings.xml'))
        dest=os.path.join(xbmc.translatePath("special://temp/"),'settings.xml')
       
        copyfile(source,dest)
        shutil.rmtree(user_dataDir)
        os.makedirs(user_dataDir)
        copyfile(os.path.join(xbmc.translatePath("special://temp/"),'settings.xml'),os.path.join(user_dataDir,'settings.xml'))
    except:
        pass
def check_version(path,force=False):
    import requests
    from zipfile import ZipFile
    cur=os.path.dirname(os.path.abspath(__file__))
    cur=os.path.join(cur,'resources','lib')
    x=requests.get('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json').json()
    if force:
        # remove_old()
        
        download_file('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',user_dataDir)
        if plat == 'android':
                if platform[0]=='32bit':
                    url=x['android32']
                    cur=os.path.join(cur,"android/armeabi-v7a")
                    download_file(url,cur)
                else:
                    url=x['android64']
                    cur=os.path.join(cur,"android/arm64-v8a")
                    download_file(url,cur)
                
        elif plat == 'windows':
            
            if platform[0]=='64bit':

                cur=os.path.join(cur,'windows/x64')
                download_file(x['windows64'],cur)
                file_windows=os.path.join(cur,'windows64.zip')
                zf = ZipFile(file_windows)

                

                for file in zf.infolist():
                    zf.extract(member=file, path=cur)
                zf.close()
                time.sleep(1)
                try:
                    os.remove(file_windows)
                except:
                    pass
            else:
                
                cur=os.path.join(cur,'windows/x32')
                download_file(x['windows32'],cur)
                file_windows=os.path.join(cur,'windows32.zip')
                zf = ZipFile(file_windows)

                

                for file in zf.infolist():
                    zf.extract(member=file, path=cur)
                zf.close()
                time.sleep(1)
                try:
                    os.remove(file_windows)
                except:
                    pass
        elif plat == 'linux':
            
                if platform[0]=='32bit':
                    url=x['linux32']
                    cur=os.path.join(cur,"linux/x32")
                    download_file(url,cur)
                else:
                    url=x['linux64']
                    cur=os.path.join(cur,"linux/x64")
                    download_file(url,cur)
    else:
        user_version=os.path.join(user_dataDir,'data.json')
        
        if os.path.exists(user_version):
            
            f = open(user_version)
            
            current_version=json.load(f)['Version']
            
            remote_version=x['Version']
            
            if version.parse(current_version) < version.parse(remote_version):
                
                # remove_old()
                if plat == 'android':
                    if platform[0]=='32bit':
                        url=x['android32']
                        cur=os.path.join(cur,"android/armeabi-v7a")
                        download_file(url,cur)
                    else:
                        url=x['android64']
                        cur=os.path.join(cur,"android/arm64-v8a")
                        download_file(url,cur)
                elif plat == 'windows':
                     
                    if platform[0]=='64bit':

                        cur=os.path.join(cur,'windows/x64')
                        download_file('https://github.com/vip200/TelemdiaTdlib/blob/main/windows64/windows64.zip?raw=true',cur)
                        file_windows=os.path.join(cur,'windows64.zip')
                        zf = ZipFile(file_windows)
                    else:
                        cur=os.path.join(cur,'windows/x32')
                        download_file('https://github.com/vip200/TelemdiaTdlib/blob/main/windows32/windows32.zip?raw=true',cur)
                        file_windows=os.path.join(cur,'windows32.zip')
                        zf = ZipFile(file_windows)
                elif plat == 'linux':
                    
                        if platform[0]=='32bit':
                            url=x['linux32']
                            cur=os.path.join(cur,"linux/x32")
                            download_file(url,cur)
                        else:
                            url=x['linux64']
                            cur=os.path.join(cur,"linux/x64")
                            download_file(url,cur)
            download_file('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',user_dataDir)
        else:
            # remove_old()
            
            download_file('https://raw.githubusercontent.com/vip200/TelemdiaTdlib/main/data.json',user_dataDir)
            if plat == 'android':
                    if platform[0]=='32bit':
                        url=x['android32']
                        cur=os.path.join(cur,"android/armeabi-v7a")
                        download_file(url,cur)
                    else:
                        url=x['android64']
                        cur=os.path.join(cur,"android/arm64-v8a")
                        download_file(url,cur)
            elif plat == 'windows':
                
                if platform[0]=='64bit':
                    
                    cur=os.path.join(cur,'windows/x64')
                    download_file(x['windows64'],cur)
                    file_windows=os.path.join(cur,'windows64.zip')
                    zf = ZipFile(file_windows)

                    

                    for file in zf.infolist():
                        zf.extract(member=file, path=cur)
                    zf.close()
                    time.sleep(1)
                    try:
                        os.remove(file_windows)
                    except:
                        pass
                else:
                    cur=os.path.join(cur,'windows/x32')
                    download_file(x['windows32'],cur)
                    file_windows=os.path.join(cur,'windows32.zip')
                    zf = ZipFile(file_windows)

                    

                    for file in zf.infolist():
                        zf.extract(member=file, path=cur)
                    zf.close()
                    time.sleep(1)
                    try:
                        os.remove(file_windows)
                    except:
                        pass
            elif plat == 'linux':
                
                    if platform[0]=='32bit':
                        url=x['linux32']
                        cur=os.path.join(cur,"linux/x32")
                        download_file(url,cur)
                    else:
                        url=x['linux64']
                        cur=os.path.join(cur,"linux/x64")
                        download_file(url,cur)
if plat == 'android':
    if platform[0]=='32bit':

        cur=os.path.join(cur,"android/armeabi-v7a")
        f_name='libtdjson'
    else:

        cur=os.path.join(cur,"android/arm64-v8a")
        f_name='libtdjson'


    loc1=os.path.join(translatepath('special://xbmc'),'libtdjsonjava.so')
    
    try:
        copyfile(os.path.join(cur,'%s.so'%f_name),loc1)
    except Exception as e:
            check_version(plat,force=True)
            time.sleep(1)
            try:
                copyfile(os.path.join(cur,'%s.so'%f_name),loc1)
            except:
                pass
            logging.warning(e)
            pass 
    if 1:#for items in all_option:
        try:
            logging.warning('CDLL:'+loc1)
            tdjson=CDLL(loc1)
        except Exception as e:
            check_version(plat,force=True)
            time.sleep(1)
            try:
                tdjson=CDLL(loc1)
            except:
                pass
            logging.warning(e)
            pass 
    try:
        td_json_client_create = tdjson._td_json_client_create
    except:
        td_json_client_create = tdjson.td_json_client_create
    td_json_client_create.restype = c_void_p
    td_json_client_create.argtypes = []
    try:
        td_json_client_receive = tdjson._td_json_client_receive
    except:
        td_json_client_receive = tdjson.td_json_client_receive
    td_json_client_receive.restype = c_char_p
    td_json_client_receive.argtypes = [c_void_p, c_double]
    try:
        td_json_client_send = tdjson._td_json_client_send
    except:
        td_json_client_send = tdjson.td_json_client_send
    td_json_client_send.restype = None
    td_json_client_send.argtypes = [c_void_p, c_char_p]
    try:
        td_json_client_execute = tdjson._td_json_client_execute
    except:
        td_json_client_execute = tdjson.td_json_client_execute
    td_json_client_execute.restype = c_char_p
    td_json_client_execute.argtypes = [c_void_p, c_char_p]
    try:
        td_json_client_destroy = tdjson._td_json_client_destroy
    except:
        td_json_client_destroy = tdjson.td_json_client_destroy
    td_json_client_destroy.restype = None
    td_json_client_destroy.argtypes = [c_void_p]
    #logging.warning('Done Define')
    
if plat == 'linux':
    if machine.lower().startswith('arm') or machine.lower().startswith('st'):
       # logging.warning('arm')
       cur=os.path.join(cur,"arm/arm-linux-gnueabihf")
       f_name= 'libtdjson.so'
    else:
       if platform[0]=='32bit':
            # logging.warning('Linux 32Bit')
            cur=os.path.join(cur,"linux/x32")
            f_name= 'libtdjson.so'
       else:
            # logging.warning('Linux 64Bit')
            cur=os.path.join(cur,"linux/x64")
            f_name= 'libtdjson.so'
    loc1=os.path.join(cur,f_name)
    

    if 1:#for items in all_option:
        try:
            logging.warning('CDLL:'+loc1)
            tdjson=CDLL(loc1)
        except Exception as e:
            check_version(plat,force=True)
            time.sleep(1)
            try:
                tdjson=CDLL(loc1)
            except:
                pass
            logging.warning(e)
    td_json_client_create = tdjson.td_json_client_create
    td_json_client_create.restype = c_void_p
    td_json_client_create.argtypes = []

    td_json_client_receive = tdjson.td_json_client_receive
    td_json_client_receive.restype = c_char_p
    td_json_client_receive.argtypes = [c_void_p, c_double]

    td_json_client_send = tdjson.td_json_client_send
    td_json_client_send.restype = None
    td_json_client_send.argtypes = [c_void_p, c_char_p]

    td_json_client_execute = tdjson.td_json_client_execute
    td_json_client_execute.restype = c_char_p
    td_json_client_execute.argtypes = [c_void_p, c_char_p]

    td_json_client_destroy = tdjson.td_json_client_destroy
    td_json_client_destroy.restype = None
    td_json_client_destroy.argtypes = [c_void_p]

 
if plat == 'windows':

    if platform[0]=='64bit':
        # if not os.path.exists(os.path.join(translatepath("special://home"),"addons", "plugin.video.telemedia/resources/lib/windows/x64/","zlib1.dll")):
               # tord()
        cur=os.path.join(cur,'windows/x64')
        crypt_name='libcrypto-1_1-x64.dll'
        ssl_name='libssl-1_1-x64.dll'
    else:
        # if not os.path.exists(os.path.join(translatepath("special://home"),"addons", "plugin.video.telemedia/resources/lib/windows/x32/","zlib1.dll")):
               # tord()
        cur=os.path.join(cur,'windows/x32')
        crypt_name='libcrypto-1_1.dll'
        ssl_name='libssl-1_1.dll'
    
    #ph=os.path.join(cur,'libeay32.dll')
    ph=os.path.join(cur,crypt_name)
    #logging.warning(ph)
    try:
        CDLL(ph)
    except Exception as e:
        check_version(plat,force=True)
        time.sleep(1)
        try:
            CDLL(ph)
        except:
            pass
        logging.warning(e)


    #ph=os.path.join(cur,'ssleay32.dll')
    ph=os.path.join(cur,ssl_name)
    #logging.warning(ph)
    CDLL(ph)


    ph=os.path.join(cur,'zlib1.dll')


    CDLL(ph)

    ph=os.path.join(cur,'tdjson.dll')
    #logging.warning (ph)
    tdjson = CDLL(ph)

    # tdjson = CDLL(tdjson_path)

    td_json_client_create = tdjson.td_json_client_create
    td_json_client_create.restype = c_void_p
    td_json_client_create.argtypes = []

    td_json_client_receive = tdjson.td_json_client_receive
    td_json_client_receive.restype = c_char_p
    td_json_client_receive.argtypes = [c_void_p, c_double]

    td_json_client_send = tdjson.td_json_client_send
    td_json_client_send.restype = None
    td_json_client_send.argtypes = [c_void_p, c_char_p]

    td_json_client_execute = tdjson.td_json_client_execute
    td_json_client_execute.restype = c_char_p
    td_json_client_execute.argtypes = [c_void_p, c_char_p]

    td_json_client_destroy = tdjson.td_json_client_destroy
    td_json_client_destroy.restype = None
    td_json_client_destroy.argtypes = [c_void_p]
    
    td_set_log_file_path = tdjson.td_set_log_file_path
    td_set_log_file_path.restype = c_int
    td_set_log_file_path.argtypes = [c_char_p]

    td_set_log_max_file_size = tdjson.td_set_log_max_file_size
    td_set_log_max_file_size.restype = None
    td_set_log_max_file_size.argtypes = [c_longlong]

    td_set_log_verbosity_level = tdjson.td_set_log_verbosity_level
    td_set_log_verbosity_level.restype = None
    td_set_log_verbosity_level.argtypes = [c_int]

    fatal_error_callback_type = CFUNCTYPE(None, c_char_p)

    td_set_log_fatal_error_callback = tdjson.td_set_log_fatal_error_callback
    td_set_log_fatal_error_callback.restype = None
    td_set_log_fatal_error_callback.argtypes = [fatal_error_callback_type]
    td_set_log_verbosity_level(0)
    def on_fatal_error_callback(error_message):
        logging.warning('TDLib fatal error: '+ error_message)
    c_on_fatal_error_callback = fatal_error_callback_type(on_fatal_error_callback)
    td_set_log_fatal_error_callback(c_on_fatal_error_callback)
t = Thread(target=start_server, args=())
t.start()
def td_execute(query):
    query = json.dumps(query).encode('utf-8')
    result = td_json_client_execute(None, query)
    if result:
        result = json.loads(result.decode('utf-8'))
    return result


if stop_listen==0:
    client = td_json_client_create()

# simple wrappers for client usage
def td_send(query):
    query = json.dumps(query).encode('utf-8')
    td_json_client_send(client, query)

def td_receive():
    try:
        result = td_json_client_receive(client, 0.01)
        if result:
            result = json.loads(result.decode('utf-8'))
        return result
    except Exception as e:
        # logging.warning('Rec err:'+str(e))
        return ''

def wait_response_now(id,dp='',timeout=10):
    global post_box
    ret_value=''
    counter=0
    
    while True:
        event = td_receive()
        if event:
            if '@extra' in event :
                if event['@extra']==int(id):
                    break
        
            #    print post_box[id]['status']
        time.sleep(0.001)
    return (event)
    
def wait_response(id,dp='',timeout=10):
    global post_box
    ret_value=''
    counter=0
    #logging.warning('Wait res')
    while True:

        counter+=1
        if timeout>0:
            if counter>(timeout*1000):
                #logging.warning('Wait res Timeout')
                del post_box[id]
                return None
        if id in post_box:
            
            if post_box[id]['status']=='recived':
                
                # print ('found ret')
                ret_value=post_box[id]['responce']
                del post_box[id]
                break
            #else:
            #    print post_box[id]['status']
        time.sleep(0.001)
   
    return (ret_value)
# testing TDLib send method
if stop_listen==0:
    td_send({'@type': 'getAuthorizationState', '@extra': 1.01234})

# main events cycle
#logging.warning('Start Telemedia 2.0 service on port:'+str(free_port))
if on_xbmc:
    try:
      cond=xbmc.abortRequested
    except:
       cond=xbmc.Monitor().abortRequested()
else:
    cond=0

event=None
while not cond:
    HOME= translatepath('special://home/')
    ADDONS           = os.path.join(HOME,      'addons')

    if send_login==1:
        send_login=0
        td_send({'@type': 'getAuthorizationState', '@extra': 99.991234})
        
        
    if 0:#on_xbmc:
        if monitor.waitForAbort(1):
                # Abort was requested while waiting. We should exit
                break
    
    
    if stop_listen==0:
        if create_dp_new==0:
            #logging.warning('create_dp_new')
            if on_xbmc:
                dp = xbmcgui.DialogProgressBG()

                dp.create('[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]Login[/COLOR][/B]')
            create_dp_new=1
        
        
        
        if event:
            '''
            if 'scope' in event:
                if ['@type']=='notificationSettingsScopeChannelChats':
                    if on_xbmc:
                        dp.update(0,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]notificationSettingsScopeChannelChats  [/COLOR][/B]')
                    #logging.warning('wating td_send')
                    td_send({'@type': 'getChats','offset_order':9223372036854775807, 'limit': '500', '@extra': 1.01234})
                    event=wait_response(1.01234)
                    #logging.warning('wating event')
                    #logging.warning(event)
            '''
            #logging.warning(event)
            if event.get('@type') =='error':
                    if on_xbmc:
                       
                        
                        xbmcgui.Dialog().ok('Telemedia Error',str(event.get('message')))
                        
                        if str(event.get('message'))=='PHONE_NUMBER_INVALID':
                            phone_number = xbmcgui.Dialog().input(Addon.getLocalizedString(32036).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_NUMERIC)#
                            
                            td_send({'@type': 'setAuthenticationPhoneNumber', 'phone_number': str(phone_number)})
                            
                        if str(event.get('message'))=='PASSWORD_HASH_INVALID':
                            password = xbmcgui.Dialog().input(Addon.getLocalizedString(32038).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_ALPHANUM)
                            if password=='':
                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות בוטלה[/COLOR]' % COLOR2)
                                dp.close()
                                stop_listen=2
                            else:
                                td_send({'@type': 'checkAuthenticationPassword', 'password': str(password)})
                        if str(event.get('message'))=='PHONE_CODE_INVALID':
                            code = xbmcgui.Dialog().input(Addon.getLocalizedString(32037).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_NUMERIC)
                            if code=='':
                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות בוטלה[/COLOR]' % COLOR2)
                                dp.close()
                                stop_listen=2
                            else:
                                td_send({'@type': 'checkAuthenticationCode', 'code': str(code)})
            # process authorization states
            if event['@type'] == 'updateAuthorizationState':
                if on_xbmc:
                    dp.update(20,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]מעדכן הרשאה  [/COLOR][/B]')
                auth_state = event['authorization_state']
                
                # if client is closed, we need to destroy it and create new client
                if auth_state['@type'] == 'authorizationStateClosed':
                    if on_xbmc:
                        dp.close()
                    stop_listen=2

                # set TDLib parameters
                # you MUST obtain your own api_id and api_hash at https://my.telegram.org
                # and use them in the setTdlibParameters call
                
                if auth_state['@type'] == 'authorizationStateWaitTdlibParameters':
                    td_send({'@type': 'setTdlibParameters', 'parameters': {
                                                           'database_directory': db_path,
                                                           'files_directory': files_path,
                                                           'use_message_database': True,
                                                           'use_secret_chats': True,
                                                           'api_id': 94575,
                                                           'api_hash': 'a3406de8d171bb422bb6ddf3bbd800e2',
                                                           'system_language_code': 'en',
                                                           'device_model': 'Desktop',
                                                           'system_version': 'Linux',
                                                           'application_version': '1.0',
                                                           'enable_storage_optimizer': True}})

                # set an encryption key for database to let know TDLib how to open the database
                elif auth_state['@type'] == 'authorizationStateWaitEncryptionKey':
                    if on_xbmc:
                        dp.update(40,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]מגדיר מפתח הצפנה   [/COLOR][/B]')
                    td_send({'@type': 'checkDatabaseEncryptionKey', 'key': 'my_key'})

                # enter phone number to log in
                elif auth_state['@type'] == 'authorizationStateWaitPhoneNumber':
                    if on_xbmc:
                        dp.update(60,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]הכנס את מספר הטלפון שלך לדוגמה: 972541234567  [/COLOR][/B]')
                        # if Addon.getSetting("tele_login")=='true':
                        try:
                          if Addon.getSetting("vip_login")=='false':
                               if get_telenum(file_data)=='' or get_telenum(file_data)==None:
                                  phone_number = xbmcgui.Dialog().input('הכנס את המספר טלפון ללא 0', '', xbmcgui.INPUT_NUMERIC)
                               else:
                                phone_number=get_telenum(file_data)
                          else:
                            phone_number=972549648424

                        except:phone_number = xbmcgui.Dialog().input('הכנס את המספר טלפון ללא 0', '', xbmcgui.INPUT_NUMERIC)
                        # else:
                        # # Enter phone number (Without the +):
                            # phone_number = xbmcgui.Dialog().input('הכנס את המספר טלפון ללא 0', '', xbmcgui.INPUT_NUMERIC)
                            
                    else:
                        phone_number = input('Please enter your phone number: ')
                    if phone_number=='':
                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות בוטלה[/COLOR]' % COLOR2)
                                dp.close()
                                stop_listen=2
                                td_json_client_destroy(client)
                    else:
                        td_send({'@type': 'setAuthenticationPhoneNumber', 'phone_number': str(phone_number)})

                # wait for authorization code
                elif auth_state['@type'] == 'authorizationStateWaitCode':
                    if on_xbmc:
                        #logging.warning('1')
                        dp.update(70,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]נשלחה לך סיסמה לנייד  [/COLOR][/B]')
                        #'Enter code:'
                        #logging.warning('2')
                        code = xbmcgui.Dialog().input('הכנס את הסיסמה', '', xbmcgui.INPUT_NUMERIC)
                    else:
                        code = input('Please enter the authentication code you received: ')
                    if code=='':
                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות בוטלה[/COLOR]' % COLOR2)
                                dp.close()
                                stop_listen=2
                                td_json_client_destroy(client)
                    else:
                        td_send({'@type': 'checkAuthenticationCode', 'code': str(code)})

                # wait for first and last name for new users
                elif auth_state['@type'] == 'authorizationStateWaitRegistration':
                    first_name = xbmcgui.Dialog().input(Addon.getLocalizedString(32161).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_ALPHANUM)
                    # input('Please enter your first name: ')
                    
                    last_name = xbmcgui.Dialog().input(Addon.getLocalizedString(32162).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_ALPHANUM)
                    # input('Please enter your last name: ')
                    td_send({'@type': 'registerUser', 'first_name': first_name, 'last_name': last_name})

                # wait for password if present
                elif auth_state['@type'] == 'authorizationStateWaitPassword':
                    
                    
                    if on_xbmc:
                        dp.update(90,'[B][COLOR=green]      Telemedia                                       [/COLOR][/B]', '[B][COLOR=yellow]הכנס את קוד האימות הדו שלבי שלך  [/COLOR][/B]')
                        #'Password:'
                        try:
                          if Addon.getSetting("vip_login")=='false':
                               if get_telecode(file_code)=='' or get_telecode(file_code)==None:
                                 password = xbmcgui.Dialog().input(Addon.getLocalizedString(32038).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_ALPHANUM)
                               else:
                                password=get_telecode(file_code)
                          else:
                                password=123
                        except:password = xbmcgui.Dialog().input(Addon.getLocalizedString(32038).encode('ascii', 'ignore').decode('ascii'), '', xbmcgui.INPUT_ALPHANUM)
                    else:
                        password = raw_input('Please enter your password: ')
                    if password=='':
                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות בוטלה[/COLOR]' % COLOR2)
                                dp.close()
                                stop_listen=2
                                td_json_client_destroy(client)
                    else:
                        td_send({'@type': 'checkAuthenticationPassword', 'password': str(password)})
                elif auth_state['@type'] == "authorizationStateReady":
                    #logging.warning('In end')
                    stop_listen=1
                    if on_xbmc:
                        dp.close()
                        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]ההתחברות הושלמה[/COLOR]' % COLOR2)
                        xbmc.executebuiltin('Container.Refresh')

                        if Addon.getSetting("show_ep")=='true':
                            refreshCommand = 'RunPlugin(plugin://plugin.video.telemedia?mode=202&url=www)'
                            xbmc.executebuiltin(refreshCommand)
                            xbmc.executebuiltin('AlarmClock(telemedia,{0},10:00:00,silent,loop)'.format(refreshCommand))
                        if not os.path.exists(os.path.join(user_dataDir, '4.1.1')):
                         Addon.setSetting('autologin', 'true')
                         file = open(os.path.join(user_dataDir, '4.1.1'), 'w') 
                         file.write(str('Done'))
                         file.close()

            # handle an incoming update or an answer to a previously sent request
                
            sys.stdout.flush()
    elif stop_listen==1:
        
        if wait_for_download_photo==1:
            global_path=download_photo(global_id,global_offset,global_end,event)
            if global_path!='':
                wait_for_download_photo=0
        if wait_for_download==1:
            
            global_path,global_size=download_file_out(global_id,global_offset,global_end,event)
            if global_path!='':
                wait_for_download=0
        if wait_for_download_complete==1:
            global_path,global_size=download_file_complete(global_id,global_offset,global_end,event)
            if global_path!='':
                wait_for_download_complete=0
        try:
            
            for items in post_box:
                    
                    if post_box[items]['status']=='pending':
                        
                        td_send(post_box[items]['data'])
                        post_box[items]['status']='send'
        except Exception as e:
            logging.warning('Err in pending:'+str(e))
            pass
        if event:
            
            try:
                if "@type" in event:
                    if 'updateFile' in event['@type']:
                        
                        for items in file_size:
                            if "file"  in event:
                                
                                if event["file"]['id']==int(items):
                                    file_size[items]=event['file']['local']['downloaded_size']
                                    downn_path[items]=event['file']['local']['path']
                    
            except Exception as e:
                logging.warning('Err in filesize:'+str(e))
                pass
            if event.get('@type') =='error'and Addon.getSetting("poptele")=='true':
                    if on_xbmc:
                        #dp.close()
                        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia',str(event.get('message'))))
                        '''
                        if 'USER_ALREADY_PARTICIPANT' in str(event.get('message')) or 'Too Many Requests: retry after' in str(event.get('message')):
                            xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia',str(event.get('message'))))
                        else:
                            xbmcgui.Dialog().ok('Telemedia Error',str(event.get('message')))
                        '''
                    else:
                        logging.warning(str(event.get('message')))
            try:
                
                for items in post_box:
                        if post_box[items]['status']=='send':
                            if '@extra' in event :
                                if event['@extra']==(items):
                                    post_box[items]['responce']=event
                                    post_box[items]['status']='recived'
                        if post_box[items]['status']=='listen':
                            if "@type" in event:
                                if 'updateFile' in event['@type']:
                                    post_box[items]['responce']=event
                                    
                        if items=='updateFile_local':
                            if "@type" in event:
                                if 'updateFile' in event['@type']:
                                    if "file"  in event:
                                        
                                        file=event["file"]['local']['path']
                                        if xbmcvfs.exists(file) and event["file"]['id']==post_box[items]['id']:
                                            post_box[items]['responce']=file
            except Exception as e:
                    logging.warning('Err post:'+str(e))
    if stop_listen!=2:
        try:
            if on_xbmc:
                
                if cond:
                    break
                event = td_receive()
            else:
                try:
                    event = td_receive()
                except Exception as e:
                    logging.warning('Error td_recive:'+str(e))
                    break
            if event:
                
                if "@extra" in event:
                    if event["@extra"]==1.91234 and Addon.getSetting("poptele")=='true':
                        xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]Connection[/COLOR]',event["@type"], 5000))
                
                if 'chat_filters' in event:
                    for ite in event['chat_filters']:
                        all_folders[ite['id']]=ite['title']
            
            if stop_listen==1:
                if event:
                    
                    if on_xbmc:
                        if Addon.getSetting("full_debug")=='true':
                            logging.warning(json.dumps(event))

                    if 'updateFile' in event['@type']:
                   
                      ready_size=ready_size_pre+event['file']['local']['downloaded_prefix_size']
                      
                    if 'expected_size' in event :
                    
                      ready_size=ready_size_pre+event['local']['downloaded_prefix_size']
                    if on_xbmc:
                        if 'size' in event:
                            complete_size=event['size']
                        if Addon.getSetting("show_login")=='true':
                           check_login(event)
                    if 'message' in event:
                       if 'chat_id' in event['message']:
                        if str(event['message']['chat_id'])=='1810654262':#'1065536817':#1722255826
                            if 'text' in event['message']['content']:
                                if 'text' in event['message']['content']['text']:
                                    txt=event['message']['content']['text']['text']
                                    last_link=txt
                                    # last_link_pre=re.compile('Here is the link to your file\n\n(.+?)\n\n').findall(txt)
                                    # last_link='Found'
                                    # if len(last_link_pre)>0:
                                       
                                        # last_link=last_link_pre[0]
                                
        except Exception as e:
            import linecache,sys
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN service:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            
            
            if not on_xbmc:
                break
    else:
        try:
            time.sleep(0.1)
        except:
            break
# destroy client when it is closed and isn't needed anymore
#logging.warning('Destroy Client')

td_json_client_destroy(client)
try:
    os.remove(file_path)
except:
    pass
server.shutdown()
