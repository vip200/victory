# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,re,xbmcplugin,sys,logging,json
import requests,threading,base64,xbmcvfs
from resources.module import log
from resources.module import cache
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
Addon = xbmcaddon.Addon()
user_dataDir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
if os.path.exists(os.path.join(__cwd__,'resources','data','accounts.db')):
    jdata_file=os.path.join(__cwd__,'resources','data','accounts.db')
    # jdata_file2=os.path.join(__cwd__,'resources','data','accounts2.db')
else:
    jdata_file=os.path.join(__cwd__,'resources','data','accounts.cfg')
names={'01377831245698351686':'סדרות',
       '03795292767349703669': 'סרטים',
       '07544211567429109729':'סדרות 2'}
icons={'01377831245698351686':'https://img.utdstc.com/icons/turkish-live-tv-android.png:225',
       '03795292767349703669':'http://img.freeflagicons.com/thumb/white_movie_icon/turkey/turkey_640.png',
       '07544211567429109729':'https://cdn.smehost.net/dailyrindblogcom-orchardprod/wp-content/uploads/2016/12/Turkey_TV_AdobeStock.jpeg'}
fans={'01377831245698351686':'https://lh3.googleusercontent.com/EptRQzLFvgbplw06pxQzRWqaNiP8NfGM_otuqr_zY-9ZE3hpnV8eQ-CYwFedEMtE53A',
       '03795292767349703669':'https://acenews.pk/wp-content/uploads/2020/03/First-Turkish-Movie-to-Rele.jpg',
       '07544211567429109729':'https://www.conexioconsulting.com/wp-content/uploads/2019/04/TURKISH-TV-SERIES-IN-ISRAEL.jpg'}
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:#kodi18
    if Addon.getSetting('debug')=='false':
        reload (sys )#line:61
        sys .setdefaultencoding ('utf8')#line:62
else:#kodi19
    import importlib
    importlib.reload (sys )#line:61
    
if KODI_VERSION<=18:
    que=urllib.quote_plus
    url_encode=urllib.urlencode
    unque_n=urllib.unquote
else:
    que=urllib.parse.quote_plus
    url_encode=urllib.parse.urlencode
    unque_n=urllib.parse.unquote
if KODI_VERSION<=18:
    unque=urllib.unquote_plus
else:
    unque=urllib.parse.unquote_plus
if KODI_VERSION>18:
    
    class Thread (threading.Thread):
       def __init__(self, target, *args):
        super().__init__(target=target, args=args)
       def run(self, *args):
          
          self._target(*self._args)
          return 0
else:
   
    class Thread(threading.Thread):
        def __init__(self, target, *args):
           
            self._target = target
            self._args = args
            
            
            threading.Thread.__init__(self)
            
        def run(self):
            self._target(*self._args)
if not os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'plugin.program.Anonymous') or not os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'repository.gaia.2') or not os.path.exists(xbmcvfs.translatePath("special://home/addons/") + 'skin.Premium.mod'):
    sys.exit()
def refresh_token():
    
    if os.path.exists(os.path.join(__cwd__,'resources','data','accounts.db')):
        data={}
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
            
        dbcon =database .connect (jdata_file )#line:226
        dbcur =dbcon .cursor ()#line:227
        dbcur .execute ("SELECT * FROM store")#line:2995
        
        match =dbcur .fetchall ()#line:2997
        
        # dbcon2 =database .connect (jdata_file2 )#line:226
        # dbcur2 =dbcon2 .cursor ()#line:227
        # dbcur2 .execute ("SELECT * FROM store")#line:2995
        
        # match2 =dbcur2 .fetchall ()#line:2997

        # ssss=[match]
        # for i in ssss:


        for key,value in match:
            
            data[key]=json.loads(value.replace("u'","'").replace("'",'"'))
        dbcur .close ()#line:3761
        dbcon .close ()#line:3762
      
    else:
        with open(jdata_file) as json_file:
            data = json.load(json_file)
    
    dr_data={}
    counter=0
    for keys in data:
 
        dr_data[keys]={}
        dr_data[keys]['name']=data[keys]['name']
        dr_data[keys]['icon']=data[keys].get('icon','')
        dr_data[keys]['fan']=data[keys].get('fanart','')
        dr_data[keys]['drivers_id']=keys
        dr_data[keys]['token']=data[keys]['access_tokens']['refresh_token']
 
        headers = {
            'Connection': 'Keep-Alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0; Redmi Note 4X MIUI/V10.2.1.0.MBFMIXM)'
        }
        progress='requests Herok'
        url='https://drive-login.herokuapp.com/refresh'
        body='refresh_token=%s&provider=googledrive'%dr_data[keys]['token']
        headers={'addon': 'plugin.noone 1.0.2/1.0.2'}
        x=requests.post(url,headers=headers,params=body).json()
        
        dr_data[keys]['auth']=u'Bearer %s'%x['access_token']
        
        
        counter+=1
        
    return dr_data
def get_params_options():
    OOOOO000OO00OO000,new_num  =u_list ('urg')#line:1994
    if OOOOO000OO00OO000 =='aa':#line:1995
       search_entered=''
       
       jump=0
       keyboard = xbmc.Keyboard(search_entered, 'קוד החומרה הוא: '+str(new_num ))
       keyboard.doModal()
       if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               Addon .setSetting ("pass",search_entered)
               OOOOO000OO00OO000,new_num  =u_list ('urg')#line:1994
               if OOOOO000OO00OO000 =='aa':#line:1995
                  jump=0
                  worng ='16HXmdeh157XkCDXqdeS15XXmdeU'
                  head='15TXp9eV15Mg16nXnNea'
                  if KODI_VERSION<19:
                        worng2=base64 .urlsafe_b64decode(worng)
                  else:
                        worng2=base64 .urlsafe_b64decode(worng).decode("utf-8")
                  if KODI_VERSION<19:
                        head2=base64 .urlsafe_b64decode(head)
                  else:
                        head2=base64 .urlsafe_b64decode(head).decode("utf-8")
                    
                  xbmcgui .Dialog ().ok (head2,worng2)
                  sys.exit()
               else:
                jump=1
                
       if jump==0:
            return False
       else:
           return True
    else:
        return True
def get_params():
        param={}
        if len(sys.argv)>=2 :
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        mode2=0
        try:        
                mode2=int(param["mode"])
        except:
                pass
        if mode2!=99:
            check_f=os.path.join(user_dataDir,'check.txt')
            if 1:
                param_r=True
            else:
                param_r=get_params_options()
                if param_r:
                    file = open(check_f, 'w') 
                    file.write('1')
                    file.close()
            logging.warning('param_r:'+str(param_r))
            if param_r==False:
                param={}
                param["mode"]=100
                param["url"]='www'
                return param
            
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": unque_n( name)   })

          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,fid='root',ct_date=''):
        u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)+"&iconimage="+que(iconimage)+"&fanart="+que(fanart)+"&description="+que(description)+'&fid='+fid
        ok=True
        menu_items=[]
        menu_items.append(('[I]Set view type[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=167')%(sys.argv[0])))
        try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description,'date':ct_date } )
        liz.setProperty( "Fanart_Image", fanart )
        liz.addContextMenuItems(menu_items, replaceItems=False)
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink( name, url,mode, iconimage,fanart,description,fid=' ',ct_date='',pre_data='',all_w={}):

          u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+(name)+"&fid="+str(fid)+"&description="+(description)+"&pre_data="+pre_data
 

          
          menu_items=[]
          menu_items.append(('[I]Set view type[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=167')%(sys.argv[0])))
          
          #u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)
          try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
          except:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
          liz.addContextMenuItems(menu_items, replaceItems=False)
          liz.setInfo(type="Video", infoLabels={ "Title": unque_n( name), "Plot": description,'date':ct_date   })
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
         
          if name in all_w:
              
              liz.setProperty('ResumeTime', all_w[name]['seek_time'])
              liz.setProperty('TotalTime', all_w[name]['total_time'])
              
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=False)




def main_menu():
    
    dr_data=cache.get(refresh_token,24, table='pages')
    all_l=[]
    for items in dr_data:
        if str(dr_data[items]['drivers_id']) in names:
            name=names[str(dr_data[items]['drivers_id'])]
        else:
            name=dr_data[items]['name'].encode('utf-8')
        url=items
        mode=2
       
        if items in icons:
            iconimage=icons[items]
        else:
            iconimage=dr_data[items]['icon']#icons[items]
        if items in fans:
            fanart=fans[items]
        else:
            fanart=dr_data[items]['fan']#fans[items]
       
        all_f,all_img=get_folder(name,url,'root')
        place_links(all_f,all_img,all_l)
        description=name
        #addDir3(name,url,mode,iconimage,fanart,description,fid='root')
    
    
    addDir3('מה חדש','www',4,'http://ngarba.xyz/adds/yos/a1a221.png','http://s1.picswalls.com/wallpapers/2014/01/29/dragon-hd-wallpaper_063723920_21.jpg',' ',fid='root')
    addDir3('חפש','www',5,'http://ngarba.xyz/adds/yos/a1a220.png','http://ngarba.xyz/adds/yos/aa117.jpg',' ',fid='root')
    return 0
def get_result(url,provider,dont_show=True):
    dr_data=cache.get(refresh_token,24, table='pages')
    auth=dr_data[provider]['auth']
    y=requests.get(url,headers= {'authorization': auth}).json()
    if 'error' in y:
        
        if y['error']['message']=='Invalid Credentials':
            dr_data=cache.get(refresh_token,0, table='pages')
            auth=dr_data[provider]['auth']
            y=requests.get(url,headers= {'authorization': auth}).json()
        elif y['error']['code']==401:
            dr_data=cache.get(refresh_token,0, table='pages')
            auth=dr_data[provider]['auth']
            y=requests.get(url,headers= {'authorization': auth}).json()
        else:
            if not dont_show:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('Error', y['error']['message'])))
             
            return []
    return y
def get_folder(name,url,fid,page_token='',all_d=[],search=False,whats_new=False,pre_date='',collect_icons={}):
    o_fid=fid

    
    if not search and not whats_new:
        if page_token!='':
            y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false&pageToken={1}".format(fid,que(page_token)),url)
            
            
        else:
            y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(fid),url)
    
    if whats_new:
        
        if page_token!='':
            y=get_result("https://www.googleapis.com/drive/v3/files?q=modifiedTime%3E'{0}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false&pageToken={1}".format(pre_date,que(page_token)),url)
        else:
            y=get_result("https://www.googleapis.com/drive/v3/files?q=modifiedTime%3E'{0}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(pre_date),url)
        
        
    if search:
        u="https://www.googleapis.com/drive/v3/files?q=fullText contains '%s' or fullText contains '%s'&spaces=drive&includeTeamDriveItems=true&prettyPrint=false&fields=files(id,name,modifiedTime,size,mimeType,description,hasThumbnail,thumbnailLink,owners(permissionId),parents,trashed,imageMediaMetadata(width),videoMediaMetadata)&corpora=teamDrive&supportsTeamDrives=true"%(fid,fid)
        y=get_result("https://www.googleapis.com/drive/v3/files?q=fullText%20contains%20'{0}'%20or%20fullText%20contains%20'{1}'&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format(fid,fid),url)
       
    if y==[]:
        return []
    general_icon=None
    
    for items in y['files']:
        t_name=items['name']
        if '.ICON.GENERAL'  in t_name:
            
            general_icon=items['thumbnailLink'].replace('.ICON.GENERAL','')
        if 'ICON' in t_name:
            b=base64.b64encode(t_name.replace('.ICON','').encode("utf-8")).decode("utf-8") 
            collect_icons[b]=items['thumbnailLink']
    if whats_new or search:
        general_icon=None

    vid_types=['.mp4','.mkv','.avi']
    import datetime,time
    
    for items in y['files']:
        # logging.warning('343422 '+str(items))
        t_name=items['name']
        ct_date=''
        if 'modifiedTime' in items:
            ct_date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(items['modifiedTime'], "%Y-%m-%dT%H:%M:%S.%fZ"))).strftime("%d.%m.%Y")
            #try:
            #    ct_date = datetime.datetime.fromtimestamp(time.mktime(time.strptime(order_date, "%Y-%m-%dT%H:%M:%S.000Z"))).strftime("%d.%m.%Y")
            #except:
            #    ct_date=''
        if whats_new or search:
            if 'parents' in items:
             fid=items['parents'][0]
        if 'ICON' not in t_name:
            media_type=False
            if 'video' in items['mimeType']:
                media_type=True
            for t in vid_types:
                t_name=t_name.replace(t,'')
            iconimage=' '
            fanart=' '
            description=' '
            b=base64.b64encode(t_name.encode("utf-8")).decode("utf-8") 
            if b in collect_icons:
                iconimage=collect_icons[b]
                if 'thumbnailLink' in items:
                    fanart=items['thumbnailLink']
                else:
                    fanart=iconimage
            elif 'thumbnailLink' in items:
                iconimage=items['thumbnailLink']
                fanart=iconimage
            if general_icon:
                iconimage=general_icon
                if 'thumbnailLink' in items:
                    fanart=items['thumbnailLink']
                else:
                    fanart=iconimage
            pre_data=''
            if 'folder' in items['mimeType']:
                mode=2
                
                #addDir3(t_name,url,mode,iconimage,fanart,ct_date+'\n'+description,fid=items['id'],ct_date=ct_date)
            else:
                mode=3
                
                
                pre_data=json.dumps([fid,url])
                #if '.srt' not in t_name and media_type:
                #    addLink(t_name,url,mode,iconimage,fanart,ct_date+'\n'+description,fid=items['id'],ct_date=ct_date,pre_data=pre_data)

            if t_name=='סדרות':
                iconimage='http://ngarba.xyz/adds/yos/a1a223.png'
                fanart='http://ngarba.xyz/adds/yos/aa117.jpg'
            elif t_name=='סרטים':
                iconimage='http://ngarba.xyz/adds/yos/a1a222.png'
                fanart='http://ngarba.xyz/adds/yos/aa117.jpg'
            all_d.append((t_name,url,mode,items['id'],name,iconimage,fanart,ct_date,pre_data,media_type))
    if 'nextPageToken' in y:
        get_folder(name,url,o_fid,page_token=y['nextPageToken'],collect_icons=collect_icons,whats_new=whats_new,search=search,pre_date=pre_date)
    return all_d,collect_icons
def read_firebase(table_name):
    from resources.module.firebase import firebase

    firebase = firebase.FirebaseApplication('https://%s.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = firebase.get('/', None)
    if table_name in result:
        
        return result[table_name]
    else:
        return {}
def write_firebase(name,url,fid,pre_data,table_name,seek_time,total_time):
    from resources.module.firebase import firebase
    
    fb_app = firebase.FirebaseApplication('https://%s.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'name':name,'url':url,'fid':fid,'pre_data':pre_data,'seek_time':seek_time,'total_time':total_time})

    return 'OK'
def delete_firebase(table_name,record):
    from resources.module.firebase import firebase
   
    fb_app = firebase.FirebaseApplication('https://%s.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = fb_app.delete(table_name, record)
   
    return 'OK'
def jump_seek(name,url,fid,pre_data):
    table_name='Dream'
    global break_jump
    break_jump=1
    timeout=0
    try:
        ab_req=xbmc.abortRequested()
    except:
        monit = xbmc.Monitor()
        ab_req=monit.abortRequested()

    while timeout<200 and ab_req:
        timeout+=1
        if break_jump==0:
            break
        if xbmc.Player().isPlaying():
            break
        xbmc.sleep(100)
    mark_once=0
    counter_stop=0
    g_timer=0
    while xbmc.Player().isPlaying():
        
        if break_jump==0:
            break
        try:
        
            vidtime = xbmc.Player().getTime()
        except Exception as e:
            vidtime=0
            pass
       
        
        if vidtime>0.2:
            try:
               g_timer=xbmc.Player().getTime()
               
                
                
               g_item_total_time=xbmc.Player().getTotalTime()
               time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
               
            except:
                pass

    all_record=read_firebase(table_name+'_seek_time')

    
    
    f_name=name
    
    for itt in all_record:

        
        if all_record[itt]['name']==f_name:
                
                delete_firebase(table_name+'_seek_time',itt)
  
    if g_timer>30:
        write_firebase(name,url,fid,pre_data,table_name+'_seek_time',str(g_timer),str(g_item_total_time))

    return 0
def is_hebrew(input_str):    
       try:
        import unicodedata
        input_str=input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ','')
        nfkd_form = unicodedata.normalize('NFKD', input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ',''))
        a=False
        for cha in input_str:
            
            a='HEBREW' in unicodedata.name(cha.strip())
            if a:
                break
        return a
       except:
            return True
def play(name,url,fid,pre_data): 
    if is_hebrew(name):
      name=name[::-1]
    try:
        if not KODI_VERSION<=18:
            res = ''.join([i for i in name.replace(')','').replace('(','') if not i.isdigit()])
            res=res[::-1]
            regex='.*([1-3][0-9]{3})'
            year_pre=re.compile(regex).findall(name)
            year=0
            if len(year_pre)>0:
                year=year_pre[0]
             
                name=name.replace(year,'')
            pre_year='('+year+')'
            name=res+pre_year
    except:pass

    y=get_result("https://www.googleapis.com/drive/v3/files?q=%27{0}%27+in+parents+and+not+trashed&fields=files%28id%2Cname%2CmodifiedTime%2Csize%2CmimeType%2Cdescription%2ChasThumbnail%2CthumbnailLink%2Cowners%28permissionId%29%2Cparents%2Ctrashed%2CimageMediaMetadata%28width%29%2CvideoMediaMetadata%29%2Ckind%2CnextPageToken&spaces=drive&prettyPrint=false".format('zzzzzzzzzzzzzzzz'),url,dont_show=True)
    dr_data=cache.get(refresh_token,24, table='pages')
    auth=dr_data[url]['auth']
    url='https://www.googleapis.com/drive/v3/files/%s?alt=media'%(fid)

    head=url_encode({'authorization': auth})
    ff_link=url+"|"+head




    listItem = xbmcgui.ListItem(name, path=ff_link) 
        
    
    listItem.setInfo(type='Video', infoLabels={'title':name,'mpaa':('heb')})
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    fid,url=json.loads(pre_data)


    
    all_f,all_img=get_folder(name,url,fid)
  
    subs=None
    for t_name,url,mode,fid,parent,iconimage,fanart,ct_date,pre_data,media_type in all_f:
        
        if t_name==name+'.srt':
           
            
            subs='https://www.googleapis.com/drive/v3/files/%s?alt=media'%(fid)
    if subs:
        
        x=0
        while not xbmc.Player().isPlaying() and x<1000:
                xbmc.sleep(10) #wait until video is being played
                x+=1
        xbmc.sleep(500)
        
        temp_sub=os.path.join(user_dataDir,'temp_sub.srt')
        if  KODI_VERSION>18:
            import chardet
            try:
                from urllib.request import Request, urlopen  # Python 3
            except ImportError:
                from urllib2 import Request, urlopen  # Python 2

            req = Request(subs)
            req.add_header('authorization', auth)
            
            x = urlopen(req).read()
            encoding=chardet.detect(x)['encoding']
            x=str(x.decode(encoding))
            log.warning('Encoding:'+encoding)
            file = open(temp_sub, 'w', encoding="utf-8") 
            
            
            
        else:
            x=requests.get(subs,headers={'authorization': auth}).text
            file = open(temp_sub, 'w') 
        
        file.write(x)
        file.close()
        while  xbmc.Player().isPlaying():
            vidtime = xbmc.Player().getTime()
            if vidtime>0.5:
                break
        
        xbmc.Player().setSubtitles(temp_sub)
    thread=[]

    thread.append(Thread(jump_seek,name,url,fid,pre_data))
        
    
    thread[0].start()
def search():
    dr_data=cache.get(refresh_token,24, table='pages')
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = que(keyboard.getText())
           if search_entered!='':
            all_l=[]
            for items in dr_data:
                all_f,all_img=get_folder('Search',items,search_entered,search=True)
                all_l=place_links(all_f,all_img,all_l)
def what_new():
    import datetime
    import _strptime
    data_back=xbmcgui.Dialog().numeric(0, 'כמה ימים אחורה') 
    from datetime import date, timedelta

    current_date = date.today().isoformat()   
    days_before = (date.today()-timedelta(days=int(data_back))).isoformat()
    dr_data=cache.get(refresh_token,24, table='pages')
    all_l=[]
    for items in dr_data:
        
        all_f,all_img=get_folder('Search',items,'root',whats_new=True,pre_date=str(days_before))
        all_l=place_links(all_f,all_img,all_l)

def set_view_type():
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    preserve_viewid = window.getFocusId()
    view_type=xbmc.getInfoLabel('Container.Viewmode' )
    listlabel = xbmc.getInfoLabel("ListItem.Tag")
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""mode TEXT,""name TEXT, ""id TEXT, ""type TEXT, ""free TEXT,""free2 TEXT);"%'views')
    
    #ok=xbmcgui.Dialog().yesno(("Global lock"),('lock all displays of the addon?'))
    if 1:
        dbcur.execute("SELECT * FROM views  where free='global'")

        match = dbcur.fetchall()
       
        if len(match)>0:
            dbcur.execute("UPDATE views SET name='%s',id='%s' where free='global'"%(view_type,str(preserve_viewid)))
        else:
            dbcur.execute("INSERT INTO views Values ('%s','%s','%s','%s','%s','%s')"%('pre_mode',view_type,str(preserve_viewid),' ','global',' '))
        dbcon.commit()
        a= str('Updated to '+(view_type))
        xbmcgui.Dialog().ok('Ok',a)
    
   
    dbcur.close()
    dbcon.close()
def place_links(all_f,all_img,all_l):
    all_w={}
    if len(Addon.getSetting("firebase"))>0:
            all_db=read_firebase('Dream_seek_time')
        
            for itt in all_db:
                
                items=all_db[itt]
                all_w[items['name']]={}
                all_w[items['name']]['seek_time']=items['seek_time']
                all_w[items['name']]['total_time']=items['total_time']

    for t_name,url,mode,fid,parent,iconimage,fanart,ct_date,pre_data,media_type in all_f:
        
        if fid in all_l:
            continue
        all_l.append(fid)
        
        b=base64.b64encode(t_name.encode("utf-8")).decode("utf-8") 
        if KODI_VERSION<19:
            t_name=t_name.encode('utf-8')
        if b in all_img:
            iconimage=all_img[b]
            
        if len(fanart)<4:
            fanart=iconimage
            
        if mode==2:
            
            
            addDir3(t_name,url,mode,iconimage,fanart,ct_date,fid=fid,ct_date=ct_date)
        else:
            
            
            
      
            if '.srt' not in t_name and media_type:
                
                addLink(t_name,url,mode,iconimage,fanart,ct_date,fid=fid,ct_date=ct_date,pre_data=pre_data,all_w=all_w)
    return all_l
def ClearCache():

    cache.clear(['cookies', 'pages','posters'])
    xbmc.executebuiltin((u'Notification(%s,%s)' % (Addon.getAddonInfo('name'),  'נוקה')))
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)

def u_list(pasf):#חומרה
    input= (Addon.getSetting("pass")).replace(' ','')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

        
    from math import sqrt
    my_tmdb=tmdb_list(TMDB_NEW_API)

    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=int(num[1]+num[2]+num[5]+num[7])
    new_num2=(str( round(sqrt((new_num*380)+40)+40,4))[-4:]).replace('.','')

    if '.' in new_num2:
     new_num2=(str( round(sqrt((new_num*380)+40)+40,4))[-5:]).replace('.','')

    if input==new_num2:
      xbmc.executebuiltin((u'Notification(%s,%s)' % (Addon.getAddonInfo('name'),  'הרשאה נפתחה!')))
      list=pasf
      return list,new_num 
    # else:
       # worng ='16HXmdeh157XkCDXqdeS15XXmdeU'
       # head='15TXp9eV15Mg16nXnNea'
       # if KODI_VERSION<19:
            # worng2=base64 .urlsafe_b64decode(worng)
       # else:
            # worng2=base64 .urlsafe_b64decode(worng).decode("utf-8")
       # if KODI_VERSION<19:
            # head2=base64 .urlsafe_b64decode(head)
       # else:
            # head2=base64 .urlsafe_b64decode(head).decode("utf-8")
        
       # xbmcgui .Dialog ().ok (head2,worng2)
       
    return 'aa',new_num
    

TMDB_NEW_API ='aG9qaw=='#line:57
def disply_hwr ():

    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (Addon .getSetting ("action"))
    wiz.setS('action', str(new_num))


def disply_hwr2 ():#line:1931
    my_tmdb=tmdb_list(TMDB_NEW_API)
    num=str((getHwAddr('eth0'))*my_tmdb)
    new_num=(num[1]+num[2]+num[5]+num[7])
    input= (ADDON.getSetting("action"))
    xbmcgui.Dialog().ok("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",new_num)

def getHwAddr (ifname ):
   import subprocess ,time 
   system_type ='windows'
   if xbmc .getCondVisibility ('system.platform.android'):
       system_type ='android'
   if xbmc .getCondVisibility ('system.platform.android'):
     Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
     mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
     n =0 
     for match in mac :
      if mac !='00:00:00:00:00:00':
          mac_address =match
          n =n +int (mac_address .replace (':',''),16 )
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
   else :
       x =0 
       n =0 
       while (1 ):
         mac_address =xbmc .getInfoLabel ("network.macaddress")
         logging .warning (mac_address )
         if mac_address !="Busy"and mac_address !=' עסוק':
            break 
         else :
           x =x +1 
           time .sleep (1 )
           if x >30 :
            break 
       n =n +int (mac_address .replace (':',''),16 )
       logging .warning ('n:'+str (n ))
   try:
    return n
   except: pass
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

fid=None

try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass
try:        
        fid=(params["fid"])
except:
        pass
try:        
        pre_data=(params["pre_data"])
except:
        pass

dr_data=cache.get(refresh_token,3, table='pages')

log.warning(mode)
log.warning(url)
        

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
    all_l=[]
    all_f,all_img=get_folder(name,url,fid)

    place_links(all_f,all_img,all_l)
    
elif mode==3:
    play(name,url,fid,pre_data=pre_data)
elif mode==4:
    what_new()
    
elif mode==5:
    search()
elif mode==167:
    set_view_type()
elif mode==6:
    ClearCache()
elif mode==99:
    disply_hwr2 ()
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')




try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
cacheFile=os.path.join(user_dataDir,'database.db')
dbcon = database.connect(cacheFile)
dbcur = dbcon.cursor()
dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""mode TEXT,""name TEXT, ""id TEXT, ""type TEXT, ""free TEXT,""free2 TEXT);"%'views')

dbcur.execute("SELECT * FROM views where (mode='%s' or free='global')"%(str(mode)))


        
match = dbcur.fetchall()

dbcur.close()
dbcon.close()
all_modes=[]
for mode,name,id,type,free1,free2 in match:
        all_modes.append(mode)
if len(all_modes)>0:

    xbmc.executebuiltin('Container.SetViewMode(%d)' % int(id))
xbmcplugin.endOfDirectory(int(sys.argv[1]))